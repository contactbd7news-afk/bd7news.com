import React, { useState } from 'react';
import {
  LayoutDashboard,
  FilePlus,
  FileText,
  FileEdit,
  CalendarClock,
  Flame,
  FolderTree,
  Layers,
  Users,
  Image as ImageIcon,
  Camera,
  Video,
  Award,
  TrendingUp,
  Megaphone,
  Sliders,
  Menu as MenuIcon,
  Globe,
  Bell,
  MessageSquare,
  UserCheck,
  Shield,
  Settings,
  BarChart3,
  DatabaseBackup,
  LogOut,
  Plus,
  Trash2,
  Eye,
  CheckCircle2,
  ArrowUp,
  ArrowDown,
  GripVertical,
  ExternalLink,
  Search,
  Lock,
  FileCode,
  Download,
} from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';
import { AdPlacementSlot, AdType, AdminUser } from '../types/news';
import { BD_DIVISIONS } from '../data/bdLocations';
import { LogoUploadManager } from './LogoUploadManager';
import { WordPressThemeExporter } from './WordPressThemeExporter';
import { PhotocardGeneratorModal } from './PhotocardGeneratorModal';

export const AdminDashboard: React.FC<{ initialTab?: string }> = ({
  initialTab = 'dashboard',
}) => {
  const {
    articles,
    publishedArticles,
    breakingHeadlines,
    categories,
    photoGalleries,
    ads,
    homepageSections,
    comments,
    reporters,
    adminUsers,
    pushNotifications,
    siteSettings,
    currentAdminUser,
    loginAdmin,
    logoutAdmin,
    addArticle,
    updateArticle,
    deleteArticle,
    setHeroArticle,
    toggleBreakingNewsBar,
    addBreakingHeadline,
    updateBreakingHeadline,
    deleteBreakingHeadline,
    addCategory,
    updateCategory,
    addSubcategory,
    removeSubcategory,
    updateHomepageSection,
    reorderHomepageSections,
    updateMostReadRank,
    toggleAdSlot,
    updateAdItem,
    addAdItem,
    deleteAdItem,
    updateCommentStatus,
    deleteComment,
    addReporter,
    addAdminUser,
    sendPushNotification,
    addPhotoGallery,
    updateSiteSettings,
    resetAllDataToDefault,
    navigateTo,
  } = useNews();

  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Login Form State (when logged out)
  const [loginEmail, setLoginEmail] = useState('contactbd7news@gmail.com');
  const [loginPassword, setLoginPassword] = useState('••••••••••••');
  const [loginRole, setLoginRole] = useState<AdminUser['role']>('Super Admin');

  // Add News Form State (All 23 required fields)
  const [enHeadline, setEnHeadline] = useState('');
  const [bnHeadline, setBnHeadline] = useState('');
  const [shortDesc, setShortDesc] = useState('');
  const [fullBody, setFullBody] = useState('');
  const [pullQuoteText, setPullQuoteText] = useState('');
  const [selCategory, setSelCategory] = useState('national');
  const [selSubcategory, setSelSubcategory] = useState('রাজধানী');
  const [selDivision, setSelDivision] = useState('');
  const [selDistrict, setSelDistrict] = useState('');
  const [selUpazila, setSelUpazila] = useState('');
  const [featImage, setFeatImage] = useState(
    'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=1200&q=80'
  );
  const [imgCaption, setImgCaption] = useState('ছবি: bd7news.com');
  const [reporterName, setReporterName] = useState('নিজস্ব প্রতিবেদক, ঢাকা');
  const [tagsInput, setTagsInput] = useState('জাতীয়, বাংলাদেশ, সর্বশেষ');
  const [seoTitleInput, setSeoTitleInput] = useState('');
  const [metaDescInput, setMetaDescInput] = useState('');
  const [focusKeywordInput, setFocusKeywordInput] = useState('');
  const [urlSlugInput, setUrlSlugInput] = useState('');
  const [pubDateInput, setPubDateInput] = useState('2026-09-26');
  const [pubTimeInput, setPubTimeInput] = useState('17:00');
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [isBreakingInput, setIsBreakingInput] = useState(false);
  const [isFeaturedInput, setIsFeaturedInput] = useState(true);
  const [videoUrlInput, setVideoUrlInput] = useState('');
  const [galleryUrlsInput, setGalleryUrlsInput] = useState('');
  const [adPlacementInput, setAdPlacementInput] = useState('in-content');
  const [previewModalOpen, setPreviewModalOpen] = useState(false);

  // Breaking News Input State
  const [newBreakingText, setNewBreakingText] = useState('');
  const [newBreakingArtId, setNewBreakingArtId] = useState('');

  // Category / Subcategory Input State
  const [newCatBn, setNewCatBn] = useState('');
  const [newCatEn, setNewCatEn] = useState('');
  const [newCatSlug, setNewCatSlug] = useState('');
  const [selectedCatForSub, setSelectedCatForSub] = useState(
    categories[0]?.id || 'cat-national'
  );
  const [newSubName, setNewSubName] = useState('');

  // Reporter Input State
  const [repName, setRepName] = useState('');
  const [repRole, setRepRole] = useState('নিজস্ব প্রতিবেদক');
  const [repBeat, setRepBeat] = useState('জাতীয় ও রাজনীতি');
  const [repEmail, setRepEmail] = useState('');

  // Push Notification State
  const [pushTitle, setPushTitle] = useState('');
  const [pushBody, setPushBody] = useState('');
  const [pushCat, setPushCat] = useState('জাতীয়');

  // New Ad State
  const [editingAdId, setEditingAdId] = useState<string | null>(null);
  const [newAdName, setNewAdName] = useState('');
  const [newAdSlot, setNewAdSlot] = useState<AdPlacementSlot>('homepage-banner');
  const [newAdType, setNewAdType] = useState<AdType>('Banner');
  const [newAdDevice, setNewAdDevice] = useState<'all' | 'desktop' | 'mobile'>('all');
  const [newAdBrand, setNewAdBrand] = useState('');
  const [newAdHeadline, setNewAdHeadline] = useState('');
  const [newAdCode, setNewAdCode] = useState('');
  const [newAdStart, setNewAdStart] = useState('2026-09-26');
  const [newAdEnd, setNewAdEnd] = useState('2026-12-31');
  const [newAdPriority, setNewAdPriority] = useState(1);

  // Drag and Drop state for Homepage Control
  const [draggedSectionIdx, setDraggedSectionIdx] = useState<number | null>(null);

  // Filter for All News
  const [newsSearch, setNewsSearch] = useState('');
  const [newsCatFilter, setNewsCatFilter] = useState('ALL');

  // New User State
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState<AdminUser['role']>('Sub-Editor');

  // New Gallery State
  const [galTitle, setGalTitle] = useState('');
  const [galCategory, setGalCategory] = useState('জাতীয়');
  const [galCover, setGalCover] = useState(
    'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1000&q=80'
  );
  const [galCaption, setGalCaption] = useState('');

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3200);
  };

  // All 26 Required Dashboard Menu Items
  const menuItems = [
    { id: 'dashboard', label: '1. Dashboard', labelBn: 'ড্যাশবোর্ড', icon: LayoutDashboard },
    { id: 'add-news', label: '2. Add News', labelBn: 'নতুন সংবাদ যোগ', icon: FilePlus },
    { id: 'all-news', label: '3. All News', labelBn: 'সকল সংবাদ', icon: FileText },
    { id: 'draft-news', label: '4. Draft News', labelBn: 'খসড়া সংবাদ', icon: FileEdit },
    { id: 'scheduled-news', label: '5. Scheduled News', labelBn: 'নির্ধারিত সংবাদ', icon: CalendarClock },
    { id: 'breaking-news', label: '6. Breaking News', labelBn: 'ব্রেকিং নিউজ', icon: Flame },
    { id: 'categories', label: '7. Categories', labelBn: 'বিভাগসমূহ', icon: FolderTree },
    { id: 'subcategories', label: '8. Subcategories', labelBn: 'উপ-বিভাগসমূহ', icon: Layers },
    { id: 'reporters', label: '9. Authors/Reporters', labelBn: 'প্রতিবেদক ও লেখক', icon: Users },
    { id: 'media-library', label: '10. Media Library', labelBn: 'মিডিয়া লাইব্রেরি', icon: ImageIcon },
    { id: 'photo-gallery', label: '11. Photo Gallery', labelBn: 'ফটো গ্যালারি', icon: Camera },
    { id: 'video-news', label: '12. Video News', labelBn: 'ভিডিও সংবাদ', icon: Video },
    { id: 'most-read', label: '13. Most Read', labelBn: 'সর্বাধিক পঠিত', icon: Award },
    { id: 'trending-news', label: '14. Trending News', labelBn: 'আলোচিত সংবাদ', icon: TrendingUp },
    { id: 'advertisements', label: '15. Advertisements', labelBn: 'বিজ্ঞাপন ব্যবস্থাপনা', icon: Megaphone },
    { id: 'homepage-control', label: '16. Homepage Control', labelBn: 'হোমপেজ নিয়ন্ত্রণ', icon: Sliders },
    { id: 'menu-management', label: '17. Menu Management', labelBn: 'মেনু ব্যবস্থাপনা', icon: MenuIcon },
    { id: 'seo-settings', label: '18. SEO Settings', labelBn: 'এসইও সেটিংস', icon: Globe },
    { id: 'push-notifications', label: '19. Push Notifications', labelBn: 'পুশ নোটিফিকেশন', icon: Bell },
    { id: 'comments', label: '20. Comments', labelBn: 'মন্তব্য ব্যবস্থাপনা', icon: MessageSquare },
    { id: 'users', label: '21. Users', labelBn: 'ব্যবহারকারী', icon: UserCheck },
    { id: 'roles', label: '22. Roles & Permissions', labelBn: 'রোল ও পারমিশন', icon: Shield },
    { id: 'site-settings', label: '23. Site Settings', labelBn: 'সাইট সেটিংস', icon: Settings },
    { id: 'analytics', label: '24. Analytics', labelBn: 'অ্যানালিটিক্স', icon: BarChart3 },
    { id: 'backup', label: '25. Backup', labelBn: 'ব্যাকআপ ও রিস্টোর', icon: DatabaseBackup },
    { id: 'wordpress-theme', label: '26. WordPress Theme', labelBn: 'ওয়ার্ডপ্রেস থিম (.ZIP)', icon: FileCode },
    { id: 'logout', label: '27. Logout', labelBn: 'লগআউট', icon: LogOut },
  ];

  // If not logged in, render role-based CMS Login Screen
  if (!currentAdminUser) {
    return (
      <div className="min-h-[80vh] bg-[#F3F4F6] flex items-center justify-center p-4">
        <div className="bg-white border-2 border-[#111827] max-w-md w-full p-6 sm:p-8 shadow-xl">
          <div className="text-center pb-5 mb-6 border-b border-[#E5E7EB]">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-[#111827] text-white mb-3">
              <Lock className="w-6 h-6 text-[#D32F2F]" />
            </div>
            <h1 className="font-editorial font-extrabold text-2xl text-[#111827]">
              bd<span className="text-[#D32F2F]">7</span>news.com CMS
            </h1>
            <p className="text-xs text-[#6B7280] mt-1">
              নিউজরুম কন্টেন্ট ম্যানেজমেন্ট ও অ্যাডমিন প্যানেল লগইন
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              loginAdmin(loginEmail, loginRole);
              showToast('সফলভাবে অ্যাডমিন প্যানেলে লগইন সম্পন্ন হয়েছে');
            }}
            className="space-y-4"
          >
            <div>
              <label className="block text-xs font-bold text-[#111827] mb-1">
                ইমেইল অ্যাড্রেস
              </label>
              <input
                type="email"
                required
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full border border-[#D1D5DB] px-3.5 py-2 text-sm outline-none focus:border-[#111827]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#111827] mb-1">
                পাসওয়ার্ড
              </label>
              <input
                type="password"
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full border border-[#D1D5DB] px-3.5 py-2 text-sm outline-none focus:border-[#111827]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#111827] mb-1">
                অ্যাক্সেস রোল (Role-Based Access)
              </label>
              <select
                value={loginRole}
                onChange={(e) => setLoginRole(e.target.value as any)}
                className="w-full border border-[#D1D5DB] px-3.5 py-2 text-sm outline-none bg-white"
              >
                <option value="Super Admin">Super Admin (পূর্ণ নিয়ন্ত্রণ)</option>
                <option value="Chief Editor">Chief Editor (প্রধান সম্পাদক)</option>
                <option value="News Editor">News Editor (বার্তা সম্পাদক)</option>
                <option value="Sub-Editor">Sub-Editor (সহ-সম্পাদক)</option>
                <option value="Reporter">Reporter (প্রতিবেদক)</option>
                <option value="Ad Manager">Ad Manager (বিজ্ঞাপন ব্যবস্থাপক)</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full bg-[#D32F2F] hover:bg-[#B71C1C] text-white font-bold text-sm py-3 transition-colors cursor-pointer"
            >
              ড্যাশবোর্ডে প্রবেশ করুন
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Handle Add News Submission (Save Draft or Publish or Schedule)
  const handleSaveArticle = (targetStatus: 'published' | 'draft' | 'scheduled') => {
    if (!bnHeadline.trim()) {
      showToast('অনুগ্রহ করে বাংলা শিরোনাম প্রদান করুন');
      return;
    }

    const catObj = categories.find((c) => c.slug === selCategory);
    const paragraphs = fullBody
      .split('\n')
      .map((p) => p.trim())
      .filter(Boolean);

    const created = addArticle({
      slug:
        urlSlugInput.trim() ||
        `bd7news-${Date.now()}`,
      headline: bnHeadline.trim(),
      englishHeadline: enHeadline.trim() || undefined,
      subtitle: shortDesc.trim(),
      summary: shortDesc.trim() || paragraphs[0] || bnHeadline.trim(),
      content:
        paragraphs.length > 0
          ? paragraphs
          : [shortDesc.trim() || bnHeadline.trim()],
      pullQuote: pullQuoteText.trim() || undefined,
      category: selCategory,
      categoryNameBn: catObj?.nameBn || 'জাতীয়',
      subcategory: selSubcategory,
      division: selDivision || undefined,
      district: selDistrict || undefined,
      upazila: selUpazila || undefined,
      featuredImage: featImage,
      imageCaption: imgCaption,
      reporter: reporterName,
      publishedAt:
        targetStatus === 'scheduled'
          ? `${pubDateInput} (${pubTimeInput})`
          : 'এইমাত্র প্রকাশিত',
      timeAgoBn:
        targetStatus === 'published'
          ? 'এইমাত্র'
          : targetStatus === 'draft'
          ? 'খসড়া'
          : 'নির্ধারিত',
      isoDate: pubDateInput,
      scheduledDate: pubDateInput,
      scheduledTime: pubTimeInput,
      status: scheduleEnabled ? 'scheduled' : targetStatus,
      isBreaking: isBreakingInput,
      isFeatured: isFeaturedInput,
      isHero: false,
      isTrending: isFeaturedInput,
      tags: tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
      seoTitle: seoTitleInput || bnHeadline.trim(),
      metaDescription: metaDescInput || shortDesc.trim(),
      focusKeyword: focusKeywordInput,
      videoUrl: videoUrlInput || undefined,
      videoDuration: videoUrlInput ? '০৫:৩০' : undefined,
      adPlacement: adPlacementInput,
    });

    showToast(
      targetStatus === 'draft'
        ? 'সংবাদটি খসড়া (Draft) হিসেবে সংরক্ষিত হয়েছে!'
        : scheduleEnabled || targetStatus === 'scheduled'
        ? 'সংবাদটি নির্ধারিত সময়ে প্রকাশের জন্য শিডিউল করা হয়েছে!'
        : 'সংবাদটি সফলভাবে bd7news.com-এ প্রকাশিত হয়েছে!'
    );

    // Clear form
    setBnHeadline('');
    setEnHeadline('');
    setShortDesc('');
    setFullBody('');
    setPullQuoteText('');
    setUrlSlugInput('');

    if (targetStatus === 'published' && !scheduleEnabled) {
      setActiveTab('all-news');
    } else if (targetStatus === 'draft') {
      setActiveTab('draft-news');
    } else {
      setActiveTab('scheduled-news');
    }
    return created;
  };

  const draftArticles = articles.filter((a) => a.status === 'draft');
  const scheduledArticles = articles.filter((a) => a.status === 'scheduled');
  const totalViews = articles.reduce((acc, a) => acc + a.views, 0);

  return (
    <div className="min-h-screen bg-[#F3F4F6] text-[#111827]">
      {/* Top CMS Bar */}
      <div className="bg-[#111827] text-white px-4 sm:px-6 h-14 flex items-center justify-between sticky top-0 z-40 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <span className="font-editorial font-extrabold text-xl tracking-tight">
            bd<span className="text-[#D32F2F]">7</span>news.com
          </span>
          <span className="bg-[#D32F2F] text-white text-[11px] font-bold px-2 py-0.5 uppercase">
            CMS STUDIO
          </span>
          <span className="hidden md:inline text-xs text-gray-400">
            | লগইন: {currentAdminUser.name} ({currentAdminUser.role})
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => navigateTo({ type: 'home' })}
            className="inline-flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold px-3 py-1.5 transition-colors cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" /> মূল ওয়েবসাইট দেখুন
          </button>
          <button
            onClick={logoutAdmin}
            className="inline-flex items-center gap-1 bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold px-3 py-1.5 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" /> লগআউট
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#111827] text-white border-l-4 border-[#10B981] px-5 py-3 shadow-2xl flex items-center gap-2.5 text-sm font-semibold">
          <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
          <span>{toastMsg}</span>
        </div>
      )}

      <div className="max-w-[1440px] mx-auto grid grid-cols-1 lg:grid-cols-12">
        {/* LEFT SIDEBAR MENU (All 26 Menu Items) */}
        <aside className="lg:col-span-3 xl:col-span-2 bg-white border-r border-[#E5E7EB] lg:min-h-[calc(100vh-3.5rem)] p-3">
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#6B7280] px-3 py-2 border-b border-[#E5E7EB] mb-2">
            CMS নেভিগেশন (২৬ মডিউল)
          </div>
          <nav className="space-y-0.5 max-h-[45vh] lg:max-h-none overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    if (item.id === 'logout') {
                      logoutAdmin();
                    } else {
                      setActiveTab(item.id);
                    }
                  }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold transition-colors text-left cursor-pointer ${
                    isActive
                      ? 'bg-[#111827] text-white'
                      : 'text-[#374151] hover:bg-[#F3F4F6] hover:text-[#D32F2F]'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-[#D32F2F]' : 'text-[#6B7280]'
                    }`}
                  />
                  <div className="truncate">
                    <div className="truncate">{item.label}</div>
                    <div
                      className={`text-[10px] ${
                        isActive ? 'text-gray-300' : 'text-[#9CA3AF]'
                      }`}
                    >
                      {item.labelBn}
                    </div>
                  </div>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* MAIN CMS WORKSPACE */}
        <main className="lg:col-span-9 xl:col-span-10 p-4 sm:p-6">
          {/* ============================================================== */}
          {/* 1. DASHBOARD OVERVIEW */}
          {/* ============================================================== */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#E5E7EB] p-5">
                <div>
                  <h1 className="font-editorial font-extrabold text-2xl text-[#111827]">
                    নিউজরুম কমান্ড সেন্টার — bd7news.com
                  </h1>
                  <p className="text-xs text-[#6B7280] mt-1">
                    সত্য সংবাদ সবসময় • লাইভ পোর্টাল স্ট্যাটাস, ব্রেকিং টিকার এবং বিজ্ঞাপন নিয়ন্ত্রণ
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={() => setActiveTab('add-news')}
                    className="bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold px-4 py-2.5 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" /> নতুন সংবাদ প্রকাশ করুন
                  </button>
                  <button
                    onClick={() => setActiveTab('advertisements')}
                    className="bg-[#111827] text-white text-xs font-bold px-4 py-2.5 cursor-pointer"
                  >
                    বিজ্ঞাপন স্লট ({toBengaliNumber(ads.filter((a) => a.enabled).length)}/{toBengaliNumber(ads.length)})
                  </button>
                </div>
              </div>

              {/* Metrics Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-white border border-[#E5E7EB] p-4">
                  <span className="text-xs text-[#6B7280] font-semibold">
                    প্রকাশিত সংবাদ
                  </span>
                  <div className="font-mono-num font-extrabold text-2xl text-[#111827] mt-1">
                    {toBengaliNumber(publishedArticles.length)}
                  </div>
                  <span className="text-[11px] text-emerald-600 font-semibold">
                    ● লাইভ পোর্টালে সক্রিয়
                  </span>
                </div>
                <div className="bg-white border border-[#E5E7EB] p-4">
                  <span className="text-xs text-[#6B7280] font-semibold">
                    মোট পাঠক ভিউ
                  </span>
                  <div className="font-mono-num font-extrabold text-2xl text-[#D32F2F] mt-1">
                    {toBengaliNumber(totalViews.toLocaleString())}
                  </div>
                  <span className="text-[11px] text-[#6B7280]">
                    আজকের পাঠক প্রবৃদ্ধি +১৮.৪%
                  </span>
                </div>
                <div className="bg-white border border-[#E5E7EB] p-4">
                  <span className="text-xs text-[#6B7280] font-semibold">
                    সক্রিয় ব্রেকিং নিউজ
                  </span>
                  <div className="font-mono-num font-extrabold text-2xl text-[#111827] mt-1">
                    {toBengaliNumber(
                      breakingHeadlines.filter((b) => b.active).length
                    )}
                  </div>
                  <button
                    onClick={() =>
                      toggleBreakingNewsBar(!siteSettings.breakingNewsEnabled)
                    }
                    className={`mt-1 text-[11px] font-bold px-2 py-0.5 cursor-pointer ${
                      siteSettings.breakingNewsEnabled
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    টিকার: {siteSettings.breakingNewsEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                  </button>
                </div>
                <div className="bg-white border border-[#E5E7EB] p-4">
                  <span className="text-xs text-[#6B7280] font-semibold">
                    সক্রিয় বিজ্ঞাপন স্লট
                  </span>
                  <div className="font-mono-num font-extrabold text-2xl text-[#111827] mt-1">
                    {toBengaliNumber(ads.filter((a) => a.enabled).length)} /{' '}
                    {toBengaliNumber(ads.length)}
                  </div>
                  <span className="text-[11px] text-[#6B7280]">
                    খসড়া: {toBengaliNumber(draftArticles.length)} | শিডিউলড:{' '}
                    {toBengaliNumber(scheduledArticles.length)}
                  </span>
                </div>
              </div>

              {/* Quick Toggles & Recent Articles */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-8 bg-white border border-[#E5E7EB] p-5">
                  <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-3 mb-4">
                    <h3 className="font-editorial font-bold text-lg">
                      সাম্প্রতিক প্রকাশিত সংবাদসমূহ
                    </h3>
                    <button
                      onClick={() => setActiveTab('all-news')}
                      className="text-xs font-bold text-[#D32F2F] cursor-pointer"
                    >
                      সব দেখুন →
                    </button>
                  </div>
                  <div className="divide-y divide-[#E5E7EB]">
                    {publishedArticles.slice(0, 6).map((art) => (
                      <div
                        key={art.id}
                        className="py-3 flex items-center justify-between gap-4"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 text-[11px] text-[#6B7280]">
                            <span className="font-bold text-[#D32F2F]">
                              {art.categoryNameBn}
                            </span>
                            <span>•</span>
                            <span>{art.publishedAt}</span>
                            {art.isHero && (
                              <span className="bg-[#111827] text-white px-1.5 py-0.2 text-[10px] font-bold">
                                HERO STORY
                              </span>
                            )}
                          </div>
                          <p className="font-editorial font-bold text-sm text-[#111827] truncate mt-0.5">
                            {art.headline}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => {
                              setHeroArticle(art.id);
                              showToast('প্রধান সংবাদ (Hero Story) পরিবর্তন করা হয়েছে!');
                            }}
                            className={`px-2.5 py-1 text-[11px] font-bold border cursor-pointer ${
                              art.isHero
                                ? 'bg-[#111827] text-white border-[#111827]'
                                : 'bg-white text-[#111827] border-[#D1D5DB] hover:border-[#111827]'
                            }`}
                          >
                            {art.isHero ? 'প্রধান সংবাদ ✓' : 'প্রধান করুন'}
                          </button>
                          <button
                            onClick={() =>
                              navigateTo({ type: 'article', articleId: art.id })
                            }
                            className="p-1.5 border border-[#E5E7EB] hover:border-[#111827] cursor-pointer"
                            title="পাঠক ভিউ"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="lg:col-span-4 bg-white border border-[#E5E7EB] p-5 space-y-4">
                  <h3 className="font-editorial font-bold text-lg border-b border-[#E5E7EB] pb-3">
                    দ্রুত নিয়ন্ত্রণ প্যানেল
                  </h3>

                  <div className="p-3.5 bg-[#F9FAFB] border border-[#E5E7EB] flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-[#111827]">
                        ব্রেকিং নিউজ টিকার বার
                      </div>
                      <div className="text-[11px] text-[#6B7280]">
                        হেডারের নিচে লাল স্ক্রলিং বার
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        toggleBreakingNewsBar(!siteSettings.breakingNewsEnabled);
                        showToast('ব্রেকিং নিউজ বার আপডেট করা হয়েছে');
                      }}
                      className={`px-3 py-1.5 text-xs font-bold cursor-pointer ${
                        siteSettings.breakingNewsEnabled
                          ? 'bg-[#D32F2F] text-white'
                          : 'bg-gray-200 text-gray-700'
                      }`}
                    >
                      {siteSettings.breakingNewsEnabled ? 'ON (চালু)' : 'OFF (বন্ধ)'}
                    </button>
                  </div>

                  <div className="p-3.5 bg-[#F9FAFB] border border-[#E5E7EB] flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-[#111827]">
                        মাস্টার বিজ্ঞাপন সিস্টেম
                      </div>
                      <div className="text-[11px] text-[#6B7280]">
                        সকল বিজ্ঞাপন স্লট একসাথে নিয়ন্ত্রণ
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        updateSiteSettings({
                          adsMasterEnabled: !siteSettings.adsMasterEnabled,
                        });
                        showToast('মাস্টার বিজ্ঞাপন সেটিং আপডেট হয়েছে');
                      }}
                      className={`px-3 py-1.5 text-xs font-bold cursor-pointer ${
                        siteSettings.adsMasterEnabled
                          ? 'bg-emerald-700 text-white'
                          : 'bg-gray-200 text-gray-700'
                      }`}
                    >
                      {siteSettings.adsMasterEnabled ? 'ON (চালু)' : 'OFF (বন্ধ)'}
                    </button>
                  </div>

                  <div className="pt-2 space-y-2">
                    <button
                      onClick={() => setActiveTab('site-settings')}
                      className="w-full text-left px-3.5 py-2.5 bg-[#FEF2F2] hover:bg-[#D32F2F] text-[#D32F2F] hover:text-white border border-[#FECACA] text-xs font-bold transition-colors cursor-pointer"
                    >
                      → ওয়েবসাইটের লোগো ও ফেভিকন আপলোড করুন
                    </button>
                    <button
                      onClick={() => setActiveTab('homepage-control')}
                      className="w-full text-left px-3.5 py-2.5 bg-[#F9FAFB] hover:bg-[#111827] hover:text-white border border-[#E5E7EB] text-xs font-bold transition-colors cursor-pointer"
                    >
                      → হোমপেজ সেকশন ও ড্র্যাগ-অ্যান্ড-ড্রপ নিয়ন্ত্রণ
                    </button>
                    <button
                      onClick={() => setActiveTab('breaking-news')}
                      className="w-full text-left px-3.5 py-2.5 bg-[#F9FAFB] hover:bg-[#111827] hover:text-white border border-[#E5E7EB] text-xs font-bold transition-colors cursor-pointer"
                    >
                      → ব্রেকিং নিউজ শিরোনাম সংযোজন/বিয়োজন
                    </button>
                    <button
                      onClick={() => setActiveTab('advertisements')}
                      className="w-full text-left px-3.5 py-2.5 bg-[#F9FAFB] hover:bg-[#111827] hover:text-white border border-[#E5E7EB] text-xs font-bold transition-colors cursor-pointer"
                    >
                      → ১১টি বিজ্ঞাপন স্লট ও AdSense কোড ম্যানেজার
                    </button>
                  </div>
                </div>
              </div>

              {/* Direct Logo Upload Manager on Dashboard */}
              <LogoUploadManager onSuccess={showToast} />
            </div>
          )}

          {/* ============================================================== */}
          {/* 2. ADD NEWS PAGE (All 23 Required Fields + Save Draft / Preview / Publish) */}
          {/* ============================================================== */}
          {activeTab === 'add-news' && (
            <div className="bg-white border border-[#E5E7EB] p-5 sm:p-6">
              <div className="flex items-center justify-between border-b-2 border-[#111827] pb-3 mb-6">
                <div>
                  <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-[#111827]">
                    নতুন সংবাদ প্রকাশনা (Add News)
                  </h2>
                  <p className="text-xs text-[#6B7280]">
                    পূর্ণাঙ্গ বাংলা সংবাদ, এসইও মেটাডেটা, ছবি, ভিডিও ও প্রকাশনার সময়সূচি নির্ধারণ করুন
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Main Left Column (8 Cols) */}
                <div className="lg:col-span-8 space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-[#111827] mb-1">
                      বাংলা শিরোনাম (Bangla Headline) *
                    </label>
                    <input
                      type="text"
                      value={bnHeadline}
                      onChange={(e) => setBnHeadline(e.target.value)}
                      placeholder="এখানে মূল বাংলা শিরোনাম লিখুন..."
                      className="w-full border border-[#D1D5DB] focus:border-[#111827] px-3.5 py-2.5 text-base font-editorial font-bold outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#111827] mb-1">
                      ইংরেজি শিরোনাম / রেফারেন্স হেডলাইন (Headline)
                    </label>
                    <input
                      type="text"
                      value={enHeadline}
                      onChange={(e) => setEnHeadline(e.target.value)}
                      placeholder="English Headline (Optional for English switch & SEO)..."
                      className="w-full border border-[#D1D5DB] focus:border-[#111827] px-3.5 py-2 text-sm outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#111827] mb-1">
                      সংক্ষিপ্ত বিবরণ / উপ-শিরোনাম (Short Description) *
                    </label>
                    <textarea
                      rows={2}
                      value={shortDesc}
                      onChange={(e) => setShortDesc(e.target.value)}
                      placeholder="সংবাদের মূল সারাংশ ২-৩ বাক্যে লিখুন..."
                      className="w-full border border-[#D1D5DB] focus:border-[#111827] p-3 text-sm outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#111827] mb-1">
                      পূর্ণাঙ্গ সংবাদ এডিটর (Full Article Editor) *
                    </label>
                    <textarea
                      rows={9}
                      value={fullBody}
                      onChange={(e) => setFullBody(e.target.value)}
                      placeholder="পূর্ণাঙ্গ বাংলা প্রতিবেদন লিখুন (প্রতিটি অনুচ্ছেদ আলাদা লাইনে লিখুন)..."
                      className="w-full border border-[#D1D5DB] focus:border-[#111827] p-3.5 text-sm font-editorial leading-relaxed outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#111827] mb-1">
                      বিশেষ উদ্ধৃতি (Pull Quote — ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      value={pullQuoteText}
                      onChange={(e) => setPullQuoteText(e.target.value)}
                      placeholder="সংবাদের ভেতরে হাইলাইট করার মতো গুরুত্বপূর্ণ উদ্ধৃতি..."
                      className="w-full border border-[#D1D5DB] px-3.5 py-2 text-sm outline-none"
                    />
                  </div>

                  {/* SEO Section inside Add News */}
                  <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 space-y-3">
                    <h4 className="font-bold text-xs uppercase tracking-wider text-[#D32F2F]">
                      এসইও এবং মেটা কনফিগারেশন (SEO Settings)
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-[#111827] mb-1">
                          SEO Title
                        </label>
                        <input
                          type="text"
                          value={seoTitleInput}
                          onChange={(e) => setSeoTitleInput(e.target.value)}
                          placeholder="গুগল সার্চের জন্য এসইও টাইটেল"
                          className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-[#111827] mb-1">
                          Focus Keyword
                        </label>
                        <input
                          type="text"
                          value={focusKeywordInput}
                          onChange={(e) => setFocusKeywordInput(e.target.value)}
                          placeholder="যেমন: মেট্রোরেল, বাংলাদেশ ক্রিকেট"
                          className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        URL Slug
                      </label>
                      <input
                        type="text"
                        value={urlSlugInput}
                        onChange={(e) => setUrlSlugInput(e.target.value)}
                        placeholder="dhaka-metro-rail-update-2026"
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs font-mono-num outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        Meta Description
                      </label>
                      <textarea
                        rows={2}
                        value={metaDescInput}
                        onChange={(e) => setMetaDescInput(e.target.value)}
                        placeholder="সার্চ ইঞ্জিনের জন্য মেটা বিবরণ (১৫৫ ক্যারেক্টারের মধ্যে)..."
                        className="w-full bg-white border border-[#D1D5DB] p-2.5 text-xs outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Right Settings Column (4 Cols) */}
                <div className="lg:col-span-4 space-y-4">
                  {/* Category & Subcategory */}
                  <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 space-y-3">
                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        বিভাগ (Category) *
                      </label>
                      <select
                        value={selCategory}
                        onChange={(e) => {
                          setSelCategory(e.target.value);
                          const found = categories.find(
                            (c) => c.slug === e.target.value
                          );
                          if (found && found.subcategories[0]) {
                            setSelSubcategory(found.subcategories[0]);
                          }
                        }}
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-2 text-xs font-bold outline-none"
                      >
                        {categories.map((cat) => (
                          <option key={cat.id} value={cat.slug}>
                            {cat.nameBn} ({cat.nameEn})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        উপ-বিভাগ (Subcategory)
                      </label>
                      <select
                        value={selSubcategory}
                        onChange={(e) => setSelSubcategory(e.target.value)}
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-2 text-xs font-semibold outline-none"
                      >
                        {(
                          categories.find((c) => c.slug === selCategory)
                            ?.subcategories || ['সাধারণ']
                        ).map((sub) => (
                          <option key={sub} value={sub}>
                            {sub}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* সারাদেশ: বিভাগ • জেলা • উপজেলা নির্বাচন */}
                    <div className="pt-2 border-t border-[#E5E7EB] space-y-2.5">
                      <span className="block text-[11px] font-bold uppercase text-[#D32F2F]">
                        সারাদেশ লোকেশন (বিভাগ • জেলা • উপজেলা)
                      </span>
                      <div>
                        <label className="block text-[11px] font-bold text-[#111827] mb-1">
                          বিভাগ (Division)
                        </label>
                        <select
                          value={selDivision}
                          onChange={(e) => {
                            setSelDivision(e.target.value);
                            setSelDistrict('');
                            setSelUpazila('');
                          }}
                          className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs font-semibold outline-none"
                        >
                          <option value="">নির্বাচন করুন (ঐচ্ছিক)</option>
                          {BD_DIVISIONS.map((div) => (
                            <option key={div.id} value={div.nameBn}>
                              {div.nameBn} বিভাগ
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#111827] mb-1">
                          জেলা (District)
                        </label>
                        <select
                          value={selDistrict}
                          onChange={(e) => {
                            setSelDistrict(e.target.value);
                            setSelUpazila('');
                          }}
                          disabled={!selDivision}
                          className="w-full bg-white border border-[#D1D5DB] disabled:opacity-50 px-3 py-1.5 text-xs font-semibold outline-none"
                        >
                          <option value="">জেলা নির্বাচন করুন</option>
                          {(
                            BD_DIVISIONS.find((d) => d.nameBn === selDivision)
                              ?.districts || []
                          ).map((dist) => (
                            <option key={dist.nameBn} value={dist.nameBn}>
                              {dist.nameBn} জেলা
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#111827] mb-1">
                          উপজেলা (Upazila)
                        </label>
                        <select
                          value={selUpazila}
                          onChange={(e) => {
                            const val = e.target.value;
                            setSelUpazila(val);
                            if (val && selDivision && !selDistrict) {
                              const divObj = BD_DIVISIONS.find(
                                (d) => d.nameBn === selDivision
                              );
                              const foundDist = divObj?.districts.find((dt) =>
                                dt.upazilas.includes(val)
                              );
                              if (foundDist) {
                                setSelDistrict(foundDist.nameBn);
                              }
                            }
                          }}
                          disabled={!selDivision}
                          className="w-full bg-white border border-[#D1D5DB] disabled:opacity-50 px-3 py-1.5 text-xs font-semibold outline-none"
                        >
                          <option value="">উপজেলা নির্বাচন করুন</option>
                          {selDistrict
                            ? (
                                BD_DIVISIONS.find((d) => d.nameBn === selDivision)
                                  ?.districts.find((dt) => dt.nameBn === selDistrict)
                                  ?.upazilas || []
                              ).map((upz) => (
                                <option key={upz} value={upz}>
                                  {upz} উপজেলা
                                </option>
                              ))
                            : (
                                BD_DIVISIONS.find((d) => d.nameBn === selDivision)
                                  ?.districts || []
                              ).map((dt) => (
                                <optgroup
                                  key={dt.nameBn}
                                  label={`${dt.nameBn} জেলা (${dt.upazilas.length}টি উপজেলা)`}
                                >
                                  {dt.upazilas.map((upz) => (
                                    <option key={`${dt.nameBn}-${upz}`} value={upz}>
                                      {upz} উপজেলা ({dt.nameBn})
                                    </option>
                                  ))}
                                </optgroup>
                              ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        প্রতিবেদক (Reporter)
                      </label>
                      <input
                        type="text"
                        value={reporterName}
                        onChange={(e) => setReporterName(e.target.value)}
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        ট্যাগসমূহ (Tags — কমা দিয়ে আলাদা করুন)
                      </label>
                      <input
                        type="text"
                        value={tagsInput}
                        onChange={(e) => setTagsInput(e.target.value)}
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                      />
                    </div>
                  </div>

                  {/* Featured Image, Video & Gallery */}
                  <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 space-y-3">
                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        ফিচার্ড ছবির URL (Featured Image)
                      </label>
                      <input
                        type="text"
                        value={featImage}
                        onChange={(e) => setFeatImage(e.target.value)}
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                      />
                      {featImage && (
                        <img
                          src={featImage}
                          alt="Preview"
                          className="mt-2 w-full aspect-16/9 object-cover border border-[#E5E7EB]"
                        />
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        ছবির ক্যাপশন (Image Caption)
                      </label>
                      <input
                        type="text"
                        value={imgCaption}
                        onChange={(e) => setImgCaption(e.target.value)}
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        ভিডিও লিংক (Video URL)
                      </label>
                      <input
                        type="text"
                        value={videoUrlInput}
                        onChange={(e) => setVideoUrlInput(e.target.value)}
                        placeholder="https://youtube.com/embed/..."
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        গ্যালারি ছবির লিংকসমূহ (Gallery)
                      </label>
                      <input
                        type="text"
                        value={galleryUrlsInput}
                        onChange={(e) => setGalleryUrlsInput(e.target.value)}
                        placeholder="একাধিক ছবির URL কমা দিয়ে দিন..."
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                      />
                    </div>
                  </div>

                  {/* Publication Date, Time, Schedule, Breaking & Featured Toggles, Ad Placement */}
                  <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-[#111827] mb-1">
                          Publish Date
                        </label>
                        <input
                          type="date"
                          value={pubDateInput}
                          onChange={(e) => setPubDateInput(e.target.value)}
                          className="w-full bg-white border border-[#D1D5DB] px-2.5 py-1.5 text-xs outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-[#111827] mb-1">
                          Publish Time
                        </label>
                        <input
                          type="time"
                          value={pubTimeInput}
                          onChange={(e) => setPubTimeInput(e.target.value)}
                          className="w-full bg-white border border-[#D1D5DB] px-2.5 py-1.5 text-xs outline-none"
                        />
                      </div>
                    </div>

                    <label className="flex items-center justify-between py-1.5 border-t border-[#E5E7EB] cursor-pointer">
                      <span className="text-xs font-bold text-[#111827]">
                        Schedule Publication (নির্ধারিত সময়ে প্রকাশ)
                      </span>
                      <input
                        type="checkbox"
                        checked={scheduleEnabled}
                        onChange={(e) => setScheduleEnabled(e.target.checked)}
                        className="w-4 h-4 accent-[#D32F2F]"
                      />
                    </label>

                    <label className="flex items-center justify-between py-1.5 border-t border-[#E5E7EB] cursor-pointer">
                      <span className="text-xs font-bold text-[#D32F2F]">
                        Breaking News ON/OFF (ব্রেকিং নিউজ)
                      </span>
                      <input
                        type="checkbox"
                        checked={isBreakingInput}
                        onChange={(e) => setIsBreakingInput(e.target.checked)}
                        className="w-4 h-4 accent-[#D32F2F]"
                      />
                    </label>

                    <label className="flex items-center justify-between py-1.5 border-t border-[#E5E7EB] cursor-pointer">
                      <span className="text-xs font-bold text-[#111827]">
                        Featured News ON/OFF (ফিচার্ড সংবাদ)
                      </span>
                      <input
                        type="checkbox"
                        checked={isFeaturedInput}
                        onChange={(e) => setIsFeaturedInput(e.target.checked)}
                        className="w-4 h-4 accent-[#111827]"
                      />
                    </label>

                    <div className="pt-1.5 border-t border-[#E5E7EB]">
                      <label className="block text-xs font-bold text-[#111827] mb-1">
                        Advertisement Placement (বিজ্ঞাপন স্লট)
                      </label>
                      <select
                        value={adPlacementInput}
                        onChange={(e) => setAdPlacementInput(e.target.value)}
                        className="w-full bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none"
                      >
                        <option value="in-content">In-Content Ad (সংবাদের ভেতরে)</option>
                        <option value="sidebar-ad">Sidebar Ad (ডান সাইডবারে)</option>
                        <option value="none">বিজ্ঞাপন মুক্ত (No Ads)</option>
                      </select>
                    </div>
                  </div>

                  {/* Action Buttons: Save Draft | Preview | Publish */}
                  <div className="grid grid-cols-3 gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => handleSaveArticle('draft')}
                      className="bg-white hover:bg-[#F3F4F6] text-[#111827] border border-[#111827] font-bold text-xs py-3 cursor-pointer"
                    >
                      Save Draft
                    </button>
                    <button
                      type="button"
                      onClick={() => setPreviewModalOpen(true)}
                      className="bg-[#374151] hover:bg-[#111827] text-white font-bold text-xs py-3 cursor-pointer"
                    >
                      Preview
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSaveArticle('published')}
                      className="bg-[#D32F2F] hover:bg-[#B71C1C] text-white font-bold text-xs py-3 cursor-pointer"
                    >
                      Publish
                    </button>
                  </div>
                </div>
              </div>

              {/* Article Preview Modal */}
              {previewModalOpen && (
                <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
                  <div className="bg-white max-w-2xl w-full p-6 border-2 border-[#111827] max-h-[85vh] overflow-y-auto">
                    <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-3 mb-4">
                      <span className="text-xs font-bold uppercase text-[#D32F2F]">
                        প্রাক-প্রদর্শন (News Preview)
                      </span>
                      <button
                        onClick={() => setPreviewModalOpen(false)}
                        className="text-xs font-bold px-3 py-1 bg-[#111827] text-white cursor-pointer"
                      >
                        বন্ধ করুন
                      </button>
                    </div>
                    <h2 className="font-editorial font-bold text-2xl text-[#111827] mb-2">
                      {bnHeadline || 'শিরোনামহীন সংবাদ'}
                    </h2>
                    <p className="text-xs text-[#6B7280] mb-4">
                      প্রতিবেদক: {reporterName} | বিভাগ: {selCategory}
                    </p>
                    {featImage && (
                      <img
                        src={featImage}
                        alt=""
                        className="w-full aspect-16/9 object-cover mb-4"
                      />
                    )}
                    <p className="font-editorial font-semibold text-sm text-[#374151] mb-3">
                      {shortDesc}
                    </p>
                    <div className="font-editorial text-sm text-[#1F2937] space-y-3">
                      {fullBody.split('\n').map((p, i) => (
                        <p key={i}>{p}</p>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ============================================================== */}
          {/* 3. ALL NEWS */}
          {/* ============================================================== */}
          {activeTab === 'all-news' && (
            <div className="bg-white border border-[#E5E7EB] p-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E7EB] pb-4 mb-4">
                <h2 className="font-editorial font-extrabold text-xl text-[#111827]">
                  সকল সংবাদ ({toBengaliNumber(articles.length)})
                </h2>
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-[#6B7280] absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={newsSearch}
                      onChange={(e) => setNewsSearch(e.target.value)}
                      placeholder="শিরোনাম খুঁজুন..."
                      className="border border-[#D1D5DB] pl-8 pr-3 py-1.5 text-xs outline-none"
                    />
                  </div>
                  <select
                    value={newsCatFilter}
                    onChange={(e) => setNewsCatFilter(e.target.value)}
                    className="border border-[#D1D5DB] px-3 py-1.5 text-xs font-semibold outline-none bg-white"
                  >
                    <option value="ALL">সব বিভাগ</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.slug}>
                        {c.nameBn}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => setActiveTab('add-news')}
                    className="bg-[#D32F2F] text-white text-xs font-bold px-3.5 py-1.5 cursor-pointer"
                  >
                    + নতুন সংবাদ
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#F9FAFB] border-y border-[#E5E7EB] text-[#4B5563]">
                      <th className="py-2.5 px-3">শিরোনাম</th>
                      <th className="py-2.5 px-3">বিভাগ</th>
                      <th className="py-2.5 px-3">স্ট্যাটাস</th>
                      <th className="py-2.5 px-3">পাঠক ভিউ</th>
                      <th className="py-2.5 px-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E5E7EB]">
                    {articles
                      .filter(
                        (a) =>
                          (newsCatFilter === 'ALL' ||
                            a.category === newsCatFilter) &&
                          (!newsSearch.trim() ||
                            a.headline
                              .toLowerCase()
                              .includes(newsSearch.toLowerCase()))
                      )
                      .map((art) => (
                        <tr key={art.id} className="hover:bg-[#F9FAFB]">
                          <td className="py-3 px-3 max-w-md">
                            <div className="font-editorial font-bold text-sm text-[#111827] line-clamp-1">
                              {art.headline}
                            </div>
                            <div className="text-[11px] text-[#6B7280]">
                              {art.reporter} • {art.publishedAt}
                            </div>
                          </td>
                          <td className="py-3 px-3 font-bold text-[#D32F2F]">
                            {art.categoryNameBn}
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={`px-2 py-0.5 text-[10px] font-bold uppercase ${
                                art.status === 'published'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : art.status === 'draft'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {art.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-mono-num font-bold">
                            {toBengaliNumber(art.views)}
                          </td>
                          <td className="py-3 px-3 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => {
                                setHeroArticle(art.id);
                                showToast('Hero Story আপডেট হয়েছে');
                              }}
                              className={`px-2 py-1 border text-[11px] font-bold cursor-pointer ${
                                art.isHero
                                  ? 'bg-[#111827] text-white border-[#111827]'
                                  : 'bg-white text-[#111827] border-[#D1D5DB]'
                              }`}
                            >
                              {art.isHero ? 'Hero ✓' : 'Set Hero'}
                            </button>
                            <button
                              onClick={() =>
                                navigateTo({ type: 'article', articleId: art.id })
                              }
                              className="px-2 py-1 border border-[#D1D5DB] hover:border-[#111827] cursor-pointer"
                            >
                              দেখুন
                            </button>
                            <button
                              onClick={() => {
                                deleteArticle(art.id);
                                showToast('সংবাদটি মুছে ফেলা হয়েছে');
                              }}
                              className="px-2 py-1 bg-red-50 text-[#D32F2F] border border-red-200 hover:bg-[#D32F2F] hover:text-white cursor-pointer"
                            >
                              ডিলিট
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 4. DRAFT NEWS & 5. SCHEDULED NEWS */}
          {/* ============================================================== */}
          {(activeTab === 'draft-news' || activeTab === 'scheduled-news') && (
            <div className="bg-white border border-[#E5E7EB] p-5">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b border-[#E5E7EB] pb-3 mb-4">
                {activeTab === 'draft-news'
                  ? `খসড়া সংবাদ তালিকা (Draft News — ${toBengaliNumber(draftArticles.length)})`
                  : `নির্ধারিত সংবাদ তালিকা (Scheduled News — ${toBengaliNumber(scheduledArticles.length)})`}
              </h2>
              <div className="divide-y divide-[#E5E7EB]">
                {(activeTab === 'draft-news'
                  ? draftArticles
                  : scheduledArticles
                ).map((art) => (
                  <div
                    key={art.id}
                    className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div>
                      <span className="text-xs font-bold text-[#D32F2F]">
                        {art.categoryNameBn} • {art.publishedAt}
                      </span>
                      <h3 className="font-editorial font-bold text-base text-[#111827] mt-0.5">
                        {art.headline}
                      </h3>
                      <p className="text-xs text-[#6B7280] mt-1">{art.summary}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          updateArticle(art.id, {
                            status: 'published',
                            timeAgoBn: 'এইমাত্র',
                            publishedAt: 'এইমাত্র প্রকাশিত',
                          });
                          showToast('সংবাদটি এখন লাইভ পোর্টালে প্রকাশ করা হয়েছে!');
                        }}
                        className="bg-emerald-700 text-white text-xs font-bold px-4 py-2 cursor-pointer"
                      >
                        এখনই প্রকাশ করুন (Publish Now)
                      </button>
                      <button
                        onClick={() => deleteArticle(art.id)}
                        className="p-2 text-[#D32F2F] border border-red-200 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 6. BREAKING NEWS MANAGER */}
          {/* ============================================================== */}
          {activeTab === 'breaking-news' && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-2 border-[#111827] pb-4">
                <div>
                  <h2 className="font-editorial font-extrabold text-xl text-[#111827]">
                    ব্রেকিং নিউজ টিকার নিয়ন্ত্রণ (Breaking News Bar)
                  </h2>
                  <p className="text-xs text-[#6B7280]">
                    হেডারের নিচে ব্রেকিং নিউজ বার চালু/বন্ধ করুন এবং স্ক্রলিং শিরোনাম যোগ বা সম্পাদনা করুন
                  </p>
                </div>
                <button
                  onClick={() => {
                    toggleBreakingNewsBar(!siteSettings.breakingNewsEnabled);
                    showToast(
                      siteSettings.breakingNewsEnabled
                        ? 'ব্রেকিং নিউজ বার বন্ধ করা হয়েছে'
                        : 'ব্রেকিং নিউজ বার চালু করা হয়েছে'
                    );
                  }}
                  className={`px-5 py-2.5 text-xs font-bold cursor-pointer ${
                    siteSettings.breakingNewsEnabled
                      ? 'bg-[#D32F2F] text-white'
                      : 'bg-gray-200 text-gray-800'
                  }`}
                >
                  ব্রেকিং বার স্ট্যাটাস:{' '}
                  {siteSettings.breakingNewsEnabled ? 'চালু আছে (ON)' : 'বন্ধ আছে (OFF)'}
                </button>
              </div>

              {/* Add Breaking Headline Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newBreakingText.trim()) return;
                  addBreakingHeadline(
                    newBreakingText.trim(),
                    newBreakingArtId || undefined
                  );
                  setNewBreakingText('');
                  showToast('নতুন ব্রেকিং শিরোনাম যুক্ত করা হয়েছে!');
                }}
                className="bg-[#FEF2F2] border border-[#FECACA] p-4 flex flex-col sm:flex-row gap-3"
              >
                <input
                  type="text"
                  required
                  value={newBreakingText}
                  onChange={(e) => setNewBreakingText(e.target.value)}
                  placeholder="নতুন ব্রেকিং নিউজ শিরোনাম লিখুন..."
                  className="flex-1 bg-white border border-[#D1D5DB] px-3.5 py-2 text-sm outline-none"
                />
                <select
                  value={newBreakingArtId}
                  onChange={(e) => setNewBreakingArtId(e.target.value)}
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs max-w-xs outline-none"
                >
                  <option value="">সংবাদ লিংক (ঐচ্ছিক)</option>
                  {publishedArticles.slice(0, 10).map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.headline.slice(0, 45)}...
                    </option>
                  ))}
                </select>
                <button
                  type="submit"
                  className="bg-[#D32F2F] text-white font-bold text-xs px-6 py-2 cursor-pointer"
                >
                  + ব্রেকিং যোগ করুন
                </button>
              </form>

              {/* Breaking Headlines List */}
              <div className="divide-y divide-[#E5E7EB]">
                {breakingHeadlines.map((item) => (
                  <div
                    key={item.id}
                    className="py-3.5 flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <input
                        type="checkbox"
                        checked={item.active}
                        onChange={(e) =>
                          updateBreakingHeadline(item.id, {
                            active: e.target.checked,
                          })
                        }
                        className="w-4 h-4 accent-[#D32F2F]"
                      />
                      <input
                        type="text"
                        value={item.headline}
                        onChange={(e) =>
                          updateBreakingHeadline(item.id, {
                            headline: e.target.value,
                          })
                        }
                        className="flex-1 font-editorial font-bold text-sm text-[#111827] border-b border-transparent focus:border-[#111827] outline-none py-0.5"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-[#6B7280]">
                        {item.createdAtBn}
                      </span>
                      <button
                        onClick={() => {
                          deleteBreakingHeadline(item.id);
                          showToast('ব্রেকিং শিরোনাম মুছে ফেলা হয়েছে');
                        }}
                        className="p-1.5 text-[#D32F2F] hover:bg-red-50 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 7. CATEGORIES & 8. SUBCATEGORIES & 17. MENU MANAGEMENT */}
          {/* ============================================================== */}
          {(activeTab === 'categories' ||
            activeTab === 'subcategories' ||
            activeTab === 'menu-management') && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                বিভাগ, উপ-বিভাগ ও নেভিগেশন মেনু ব্যবস্থাপনা
              </h2>

              {/* Add New Category */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newCatBn.trim() || !newCatSlug.trim()) return;
                  addCategory(
                    newCatBn.trim(),
                    newCatEn.trim() || newCatBn.trim(),
                    newCatSlug.trim()
                  );
                  setNewCatBn('');
                  setNewCatEn('');
                  setNewCatSlug('');
                  showToast('নতুন বিভাগ সফলভাবে যুক্ত হয়েছে');
                }}
                className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 grid grid-cols-1 sm:grid-cols-4 gap-3"
              >
                <input
                  type="text"
                  value={newCatBn}
                  onChange={(e) => setNewCatBn(e.target.value)}
                  placeholder="বিভাগের বাংলা নাম (যেমন: শিক্ষা)"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                />
                <input
                  type="text"
                  value={newCatEn}
                  onChange={(e) => setNewCatEn(e.target.value)}
                  placeholder="ইংরেজি নাম (e.g. Education)"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                />
                <input
                  type="text"
                  value={newCatSlug}
                  onChange={(e) => setNewCatSlug(e.target.value)}
                  placeholder="Slug (e.g. education)"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                />
                <button
                  type="submit"
                  className="bg-[#111827] text-white font-bold text-xs py-2 cursor-pointer"
                >
                  + নতুন বিভাগ যোগ করুন
                </button>
              </form>

              {/* Add Subcategory */}
              <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 flex flex-col sm:flex-row gap-3">
                <select
                  value={selectedCatForSub}
                  onChange={(e) => setSelectedCatForSub(e.target.value)}
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs font-bold outline-none"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nameBn}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={newSubName}
                  onChange={(e) => setNewSubName(e.target.value)}
                  placeholder="নতুন উপ-বিভাগের নাম লিখুন..."
                  className="flex-1 bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!newSubName.trim()) return;
                    addSubcategory(selectedCatForSub, newSubName.trim());
                    setNewSubName('');
                    showToast('উপ-বিভাগ যুক্ত করা হয়েছে');
                  }}
                  className="bg-[#D32F2F] text-white font-bold text-xs px-5 py-2 cursor-pointer"
                >
                  + উপ-বিভাগ যোগ করুন
                </button>
              </div>

              {/* Categories Table */}
              <div className="divide-y divide-[#E5E7EB]">
                {categories.map((cat) => (
                  <div
                    key={cat.id}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-editorial font-bold text-base text-[#111827]">
                          {cat.nameBn}
                        </span>
                        <span className="text-xs text-[#6B7280]">
                          ({cat.nameEn} • /{cat.slug})
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1.5 mt-1.5">
                        {cat.subcategories.map((sub) => (
                          <span
                            key={sub}
                            className="inline-flex items-center gap-1 bg-[#F3F4F6] border border-[#E5E7EB] px-2 py-0.5 text-[11px]"
                          >
                            {sub}
                            <button
                              onClick={() => removeSubcategory(cat.id, sub)}
                              className="text-[#D32F2F] font-bold ml-1 cursor-pointer"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    </div>
                    <label className="flex items-center gap-2 text-xs font-bold cursor-pointer shrink-0">
                      <input
                        type="checkbox"
                        checked={cat.visibleInMenu}
                        onChange={(e) =>
                          updateCategory(cat.id, {
                            visibleInMenu: e.target.checked,
                          })
                        }
                        className="w-4 h-4 accent-[#111827]"
                      />
                      <span>মেনুতে প্রদর্শন</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 15. ADVERTISEMENT MANAGER (All 11 Ad Placements + AdSense Code Support) */}
          {/* ============================================================== */}
          {activeTab === 'advertisements' && (
            <div className="space-y-6">
              <div className="bg-white border border-[#E5E7EB] p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-2 border-[#111827] pb-4 mb-5">
                  <div>
                    <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-[#111827]">
                      বিজ্ঞাপন ব্যবস্থাপনা (Google AdSense & Ad Manager)
                    </h2>
                    <p className="text-xs text-[#6B7280]">
                      ১৬টি ডেডিকেটেড AdSense স্লট (প্রি-পোস্ট ভিনিয়েট, ইন-ফিড, মাল্টিপ্লেক্স, অ্যাঙ্কর, সাইড রিল, ব্যানার), ক্লিক ও বন্ধ করার সুবিধা নিয়ন্ত্রণ
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        updateSiteSettings({
                          prePostVignetteEnabled:
                            siteSettings.prePostVignetteEnabled === false
                              ? true
                              : false,
                        })
                      }
                      className={`px-3.5 py-2 text-xs font-bold cursor-pointer ${
                        siteSettings.prePostVignetteEnabled !== false
                          ? 'bg-[#1A73E8] text-white'
                          : 'bg-gray-200 text-gray-800'
                      }`}
                    >
                      পোস্টে ক্লিক করলে অ্যাড:{' '}
                      {siteSettings.prePostVignetteEnabled !== false
                        ? 'চালু (ON)'
                        : 'বন্ধ (OFF)'}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        updateSiteSettings({
                          adsMasterEnabled: !siteSettings.adsMasterEnabled,
                        })
                      }
                      className={`px-4 py-2 text-xs font-bold cursor-pointer ${
                        siteSettings.adsMasterEnabled
                          ? 'bg-emerald-700 text-white'
                          : 'bg-red-700 text-white'
                      }`}
                    >
                      গ্লোবাল অ্যাড সিস্টেম:{' '}
                      {siteSettings.adsMasterEnabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
                    </button>
                  </div>
                </div>

                {/* Add / Create New Ad Campaign Form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!newAdName.trim()) return;
                    addAdItem({
                      name: newAdName.trim(),
                      slot: newAdSlot,
                      adType: newAdType,
                      device: newAdDevice,
                      enabled: true,
                      priority: newAdPriority,
                      startDate: newAdStart,
                      endDate: newAdEnd,
                      adCode: newAdCode,
                      sponsorBrandBn: newAdBrand || 'বিডি৭ পার্টনার ব্র্যান্ড',
                      sponsorHeadlineBn:
                        newAdHeadline || 'বিশেষ কর্পোরেট বিজ্ঞাপন অফার',
                      sponsorSubtextBn: 'বিস্তারিত জানতে ক্লিক করুন',
                      sponsorCtaBn: 'বিস্তারিত দেখুন',
                      dimensionsLabel: 'Custom / AdSense',
                    });
                    setNewAdName('');
                    setNewAdBrand('');
                    setNewAdHeadline('');
                    setNewAdCode('');
                    showToast('নতুন বিজ্ঞাপন ক্যাম্পেইন যুক্ত করা হয়েছে!');
                  }}
                  className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 mb-6 space-y-3"
                >
                  <h4 className="text-xs font-bold uppercase text-[#D32F2F]">
                    + নতুন বিজ্ঞাপন বা Google AdSense স্লট যোগ করুন
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <input
                      type="text"
                      required
                      value={newAdName}
                      onChange={(e) => setNewAdName(e.target.value)}
                      placeholder="বিজ্ঞাপনের নাম (Ad Name) *"
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                    />
                    <select
                      value={newAdSlot}
                      onChange={(e) => setNewAdSlot(e.target.value as any)}
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs font-bold outline-none"
                    >
                      <option value="vignette-interstitial">Pre-Post Vignette / Interstitial ad</option>
                      <option value="in-feed">In-Feed Native ad</option>
                      <option value="multiplex-ad">Multiplex Sponsored Grid ad</option>
                      <option value="anchor-top">Top Anchor Sticky ad</option>
                      <option value="side-rail">Desktop Side Rail ad</option>
                      <option value="top-banner">Top banner ad</option>
                      <option value="header-ad">Header ad</option>
                      <option value="homepage-banner">Homepage banner ad</option>
                      <option value="in-content">In-content / In-Article ad</option>
                      <option value="sidebar-ad">Sidebar ad</option>
                      <option value="between-section">Between-news-section ad</option>
                      <option value="sticky-bottom">Sticky bottom anchor ad</option>
                      <option value="pop-under">Pop-under ad</option>
                      <option value="social-bar">Social bar ad</option>
                      <option value="mobile-banner">Mobile banner ad</option>
                      <option value="desktop-leaderboard">Desktop leaderboard ad</option>
                    </select>
                    <select
                      value={newAdType}
                      onChange={(e) => setNewAdType(e.target.value as any)}
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                    >
                      <option value="Vignette / Interstitial">Vignette / Interstitial</option>
                      <option value="In-Feed">In-Feed</option>
                      <option value="Multiplex">Multiplex</option>
                      <option value="Anchor">Anchor</option>
                      <option value="Side Rail">Side Rail</option>
                      <option value="Banner">Banner</option>
                      <option value="Leaderboard">Leaderboard</option>
                      <option value="Sidebar">Sidebar</option>
                      <option value="In-content">In-content</option>
                      <option value="Sticky">Sticky</option>
                      <option value="Pop-under">Pop-under</option>
                      <option value="Social bar">Social bar</option>
                    </select>
                    <select
                      value={newAdDevice}
                      onChange={(e) => setNewAdDevice(e.target.value as any)}
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                    >
                      <option value="all">সকল ডিভাইস (All Devices)</option>
                      <option value="desktop">ডেস্কটপ (Desktop Only)</option>
                      <option value="mobile">মোবাইল (Mobile Only)</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <input
                      type="text"
                      value={newAdBrand}
                      onChange={(e) => setNewAdBrand(e.target.value)}
                      placeholder="স্পন্সর ব্র্যান্ডের নাম"
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                    />
                    <input
                      type="text"
                      value={newAdHeadline}
                      onChange={(e) => setNewAdHeadline(e.target.value)}
                      placeholder="বিজ্ঞাপনের শিরোনাম / বার্তা"
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                    />
                    <input
                      type="date"
                      value={newAdStart}
                      onChange={(e) => setNewAdStart(e.target.value)}
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                    />
                    <input
                      type="date"
                      value={newAdEnd}
                      onChange={(e) => setNewAdEnd(e.target.value)}
                      className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs outline-none"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <textarea
                      rows={2}
                      value={newAdCode}
                      onChange={(e) => setNewAdCode(e.target.value)}
                      placeholder="Google AdSense Code / Custom HTML / JavaScript কোড এখানে পেস্ট করুন (ঐচ্ছিক)..."
                      className="flex-1 bg-white border border-[#D1D5DB] p-2.5 text-xs font-mono-num outline-none"
                    />
                    <div className="flex flex-col justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold">Priority:</span>
                        <input
                          type="number"
                          min={1}
                          max={10}
                          value={newAdPriority}
                          onChange={(e) =>
                            setNewAdPriority(Number(e.target.value))
                          }
                          className="w-16 bg-white border border-[#D1D5DB] px-2 py-1 text-xs"
                        />
                      </div>
                      <button
                        type="submit"
                        className="bg-[#D32F2F] text-white font-bold text-xs px-6 py-2.5 cursor-pointer"
                      >
                        বিজ্ঞাপন সংরক্ষণ করুন
                      </button>
                    </div>
                  </div>
                </form>

                {/* All Ad Slots List with ON/OFF & Code Editor */}
                <div className="space-y-3">
                  {ads.map((ad) => (
                    <div
                      key={ad.id}
                      className="border border-[#E5E7EB] p-4 bg-white hover:border-[#111827] transition-colors"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-editorial font-bold text-base text-[#111827]">
                              {ad.name}
                            </span>
                            <span className="bg-[#F3F4F6] border border-[#E5E7EB] px-2 py-0.5 text-[11px] font-mono-num font-bold text-[#D32F2F]">
                              Slot: {ad.slot}
                            </span>
                            <span className="bg-[#F3F4F6] px-2 py-0.5 text-[11px] font-semibold">
                              Type: {ad.adType}
                            </span>
                            <span className="bg-[#F3F4F6] px-2 py-0.5 text-[11px]">
                              Device: {ad.device}
                            </span>
                            <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 text-[11px] font-bold">
                              ক্লিক: {toBengaliNumber(ad.clicks || 120)}
                            </span>
                            <span className="text-[11px] text-[#6B7280]">
                              Priority: {ad.priority} | {ad.startDate} → {ad.endDate}
                            </span>
                          </div>
                          <p className="text-xs text-[#4B5563] mt-1">
                            <strong>{ad.sponsorBrandBn}:</strong> {ad.sponsorHeadlineBn}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() =>
                              setEditingAdId(
                                editingAdId === ad.id ? null : ad.id
                              )
                            }
                            className="px-3 py-1.5 border border-[#D1D5DB] text-xs font-semibold hover:border-[#111827] cursor-pointer"
                          >
                            AdSense / কোড এডিট
                          </button>

                          <button
                            onClick={() => {
                              toggleAdSlot(ad.id, !ad.enabled);
                              showToast(
                                `${ad.name} ${
                                  !ad.enabled ? 'চালু (ON)' : 'বন্ধ (OFF)'
                                } করা হয়েছে`
                              );
                            }}
                            className={`px-4 py-1.5 text-xs font-bold cursor-pointer ${
                              ad.enabled
                                ? 'bg-emerald-700 text-white'
                                : 'bg-gray-200 text-gray-700'
                            }`}
                          >
                            {ad.enabled ? 'ON (সক্রিয়)' : 'OFF (বন্ধ)'}
                          </button>

                          <button
                            onClick={() => deleteAdItem(ad.id)}
                            className="p-1.5 text-[#D32F2F] hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {editingAdId === ad.id && (
                        <div className="mt-4 pt-3 border-t border-[#E5E7EB] space-y-3 bg-[#F9FAFB] p-3">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[11px] font-bold mb-1">
                                ব্র্যান্ড নাম
                              </label>
                              <input
                                type="text"
                                value={ad.sponsorBrandBn}
                                onChange={(e) =>
                                  updateAdItem(ad.id, {
                                    sponsorBrandBn: e.target.value,
                                  })
                                }
                                className="w-full bg-white border border-[#D1D5DB] px-2.5 py-1.5 text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold mb-1">
                                বিজ্ঞাপন শিরোনাম
                              </label>
                              <input
                                type="text"
                                value={ad.sponsorHeadlineBn}
                                onChange={(e) =>
                                  updateAdItem(ad.id, {
                                    sponsorHeadlineBn: e.target.value,
                                  })
                                }
                                className="w-full bg-white border border-[#D1D5DB] px-2.5 py-1.5 text-xs"
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold mb-1">
                              Google AdSense / Custom HTML / JS Code
                            </label>
                            <textarea
                              rows={3}
                              value={ad.adCode}
                              onChange={(e) =>
                                updateAdItem(ad.id, { adCode: e.target.value })
                              }
                              placeholder="<ins class='adsbygoogle' ...></ins>"
                              className="w-full bg-white border border-[#D1D5DB] p-2 text-xs font-mono-num"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 16. HOMEPAGE CONTROL (Hero Selection + Drag-and-Drop Reorder + Section Toggles) */}
          {/* ============================================================== */}
          {activeTab === 'homepage-control' && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
              <div className="border-b-2 border-[#111827] pb-3">
                <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-[#111827]">
                  হোমপেজ নিয়ন্ত্রণ ও লেআউট বিল্ডার (Homepage Control)
                </h2>
                <p className="text-xs text-[#6B7280]">
                  প্রধান সংবাদ (Hero Story) নির্বাচন করুন এবং ড্র্যাগ-অ্যান্ড-ড্রপ বা তীর চিহ্নের মাধ্যমে হোমপেজের সেকশনগুলোর ক্রম পরিবর্তন করুন
                </p>
              </div>

              {/* Change Hero Story */}
              <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4">
                <label className="block text-xs font-bold text-[#111827] mb-2">
                  প্রধান লিড সংবাদ নির্বাচন করুন (Select Hero Story):
                </label>
                <select
                  value={
                    publishedArticles.find((a) => a.isHero)?.id ||
                    publishedArticles[0]?.id
                  }
                  onChange={(e) => {
                    setHeroArticle(e.target.value);
                    showToast('হোমপেজের প্রধান সংবাদ (Hero Story) আপডেট হয়েছে!');
                  }}
                  className="w-full bg-white border border-[#D1D5DB] px-3.5 py-2.5 text-sm font-editorial font-bold outline-none"
                >
                  {publishedArticles.map((art) => (
                    <option key={art.id} value={art.id}>
                      [{art.categoryNameBn}] {art.headline}
                    </option>
                  ))}
                </select>
              </div>

              {/* Drag and Drop / Reorder Homepage Sections */}
              <div className="space-y-2.5">
                <h3 className="font-bold text-xs uppercase tracking-wider text-[#6B7280]">
                  হোমপেজ সেকশন ক্রম (Drag & Drop অথবা ↑ ↓ দিয়ে সাজান)
                </h3>
                {[...homepageSections]
                  .sort((a, b) => a.order - b.order)
                  .map((sec, idx, arr) => (
                    <div
                      key={sec.id}
                      draggable
                      onDragStart={() => setDraggedSectionIdx(idx)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        if (
                          draggedSectionIdx !== null &&
                          draggedSectionIdx !== idx
                        ) {
                          reorderHomepageSections(draggedSectionIdx, idx);
                          showToast('হোমপেজ সেকশনের ক্রম আপডেট হয়েছে!');
                        }
                        setDraggedSectionIdx(null);
                      }}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-[#E5E7EB] hover:border-[#111827] p-3.5 cursor-move"
                    >
                      <div className="flex items-center gap-3">
                        <GripVertical className="w-4 h-4 text-[#9CA3AF]" />
                        <span className="w-6 h-6 bg-[#111827] text-white text-xs font-bold flex items-center justify-center">
                          {toBengaliNumber(idx + 1)}
                        </span>
                        <div>
                          <span className="font-editorial font-bold text-sm sm:text-base text-[#111827]">
                            {sec.titleBn}
                          </span>
                          <span className="block text-[11px] text-[#6B7280]">
                            Key: {sec.key}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1.5 text-xs">
                          <span>সংবাদ সংখ্যা:</span>
                          <input
                            type="number"
                            min={2}
                            max={12}
                            value={sec.storyCount}
                            onChange={(e) =>
                              updateHomepageSection(sec.id, {
                                storyCount: Number(e.target.value),
                              })
                            }
                            className="w-14 border border-[#D1D5DB] px-2 py-1 text-xs font-bold"
                          />
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            disabled={idx === 0}
                            onClick={() =>
                              reorderHomepageSections(idx, idx - 1)
                            }
                            className="p-1.5 border border-[#D1D5DB] disabled:opacity-30 cursor-pointer"
                            title="উপরে নিন"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            disabled={idx === arr.length - 1}
                            onClick={() =>
                              reorderHomepageSections(idx, idx + 1)
                            }
                            className="p-1.5 border border-[#D1D5DB] disabled:opacity-30 cursor-pointer"
                            title="নিচে নিন"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <button
                          onClick={() =>
                            updateHomepageSection(sec.id, {
                              enabled: !sec.enabled,
                            })
                          }
                          className={`px-3 py-1 text-xs font-bold cursor-pointer ${
                            sec.enabled
                              ? 'bg-emerald-700 text-white'
                              : 'bg-gray-200 text-gray-700'
                          }`}
                        >
                          {sec.enabled ? 'Enabled ✓' : 'Disabled'}
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 13. MOST READ & 14. TRENDING NEWS */}
          {/* ============================================================== */}
          {(activeTab === 'most-read' || activeTab === 'trending-news') && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-4">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                সর্বাধিক পঠিত (০১-০৮) ও আলোচিত সংবাদ ব্যবস্থাপনা
              </h2>
              <div className="divide-y divide-[#E5E7EB]">
                {publishedArticles.slice(0, 12).map((art) => (
                  <div
                    key={art.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <span className="text-xs font-bold text-[#D32F2F]">
                        {art.categoryNameBn} • পাঠক: {toBengaliNumber(art.views)}
                      </span>
                      <h4 className="font-editorial font-bold text-sm text-[#111827]">
                        {art.headline}
                      </h4>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <label className="flex items-center gap-1.5 text-xs font-semibold cursor-pointer">
                        <input
                          type="checkbox"
                          checked={art.isTrending}
                          onChange={(e) =>
                            updateArticle(art.id, {
                              isTrending: e.target.checked,
                            })
                          }
                          className="accent-[#D32F2F]"
                        />
                        <span>আলোচিত (Trending)</span>
                      </label>
                      <select
                        value={art.mostReadRank || ''}
                        onChange={(e) => {
                          const val = e.target.value
                            ? Number(e.target.value)
                            : undefined;
                          updateMostReadRank(art.id, val);
                          showToast('সর্বাধিক পঠিত র‍্যাঙ্ক আপডেট হয়েছে');
                        }}
                        className="border border-[#D1D5DB] px-2.5 py-1 text-xs font-bold"
                      >
                        <option value="">র‍্যাঙ্ক নেই</option>
                        {[1, 2, 3, 4, 5, 6, 7, 8].map((r) => (
                          <option key={r} value={r}>
                            র‍্যাঙ্ক ০{toBengaliNumber(r)}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 9. AUTHORS / REPORTERS */}
          {/* ============================================================== */}
          {activeTab === 'reporters' && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                প্রতিবেদক ও লেখক প্যানেল (Authors / Reporters)
              </h2>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!repName.trim()) return;
                  addReporter({
                    nameBn: repName.trim(),
                    roleBn: repRole,
                    beatBn: repBeat,
                    email: repEmail || 'reporter@bd7news.com',
                    avatar:
                      'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
                  });
                  setRepName('');
                  setRepEmail('');
                  showToast('নতুন প্রতিবেদক যুক্ত করা হয়েছে');
                }}
                className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 grid grid-cols-1 sm:grid-cols-4 gap-3"
              >
                <input
                  type="text"
                  required
                  value={repName}
                  onChange={(e) => setRepName(e.target.value)}
                  placeholder="প্রতিবেদকের নাম *"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  value={repRole}
                  onChange={(e) => setRepRole(e.target.value)}
                  placeholder="পদবি"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  value={repBeat}
                  onChange={(e) => setRepBeat(e.target.value)}
                  placeholder="বিট (যেমন: অর্থনীতি, ক্রীড়া)"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <button
                  type="submit"
                  className="bg-[#111827] text-white font-bold text-xs py-2 cursor-pointer"
                >
                  + প্রতিবেদক যোগ করুন
                </button>
              </form>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {reporters.map((rep) => (
                  <div
                    key={rep.id}
                    className="border border-[#E5E7EB] p-4 flex items-center gap-3"
                  >
                    <img
                      src={rep.avatar}
                      alt={rep.nameBn}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <h4 className="font-editorial font-bold text-sm text-[#111827]">
                        {rep.nameBn}
                      </h4>
                      <p className="text-xs text-[#D32F2F] font-semibold">
                        {rep.roleBn}
                      </p>
                      <p className="text-[11px] text-[#6B7280]">{rep.beatBn}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 10. MEDIA LIBRARY & 11. PHOTO GALLERY & 12. VIDEO NEWS */}
          {/* ============================================================== */}
          {(activeTab === 'media-library' ||
            activeTab === 'photo-gallery' ||
            activeTab === 'video-news') && (
            <div className="space-y-6">
              {activeTab === 'media-library' && (
                <div className="space-y-6">
                  <PhotocardGeneratorModal isModal={false} />
                  <LogoUploadManager onSuccess={showToast} />
                </div>
              )}

              <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
                <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                  মিডিয়া লাইব্রেরি, ফটো গ্যালারি ও ভিডিও সংবাদ
                </h2>

              {/* Add Photo Gallery Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!galTitle.trim()) return;
                  addPhotoGallery({
                    titleBn: galTitle.trim(),
                    categoryBn: galCategory,
                    dateBn: '২৬ সেপ্টেম্বর ২০২৬',
                    coverImage: galCover,
                    photos: [
                      {
                        url: galCover,
                        captionBn: galCaption || galTitle.trim(),
                      },
                    ],
                  });
                  setGalTitle('');
                  setGalCaption('');
                  showToast('নতুন ফটো গ্যালারি অ্যালবাম যুক্ত হয়েছে!');
                }}
                className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 grid grid-cols-1 sm:grid-cols-4 gap-3"
              >
                <input
                  type="text"
                  required
                  value={galTitle}
                  onChange={(e) => setGalTitle(e.target.value)}
                  placeholder="ফটো গ্যালারি শিরোনাম *"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  value={galCover}
                  onChange={(e) => setGalCover(e.target.value)}
                  placeholder="ছবির URL *"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  value={galCaption}
                  onChange={(e) => setGalCaption(e.target.value)}
                  placeholder="ছবির ক্যাপশন"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <button
                  type="submit"
                  className="bg-[#D32F2F] text-white font-bold text-xs py-2 cursor-pointer"
                >
                  + গ্যালারিতে যোগ করুন
                </button>
              </form>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {articles.slice(0, 12).map((art) => (
                  <div
                    key={art.id}
                    className="border border-[#E5E7EB] overflow-hidden bg-[#F9FAFB]"
                  >
                    <img
                      src={art.featuredImage}
                      alt={art.headline}
                      className="w-full aspect-16/10 object-cover"
                    />
                    <div className="p-2.5">
                      <p className="text-xs font-bold text-[#111827] line-clamp-1">
                        {art.headline}
                      </p>
                      <span className="text-[10px] text-[#6B7280]">
                        {art.imageCaption}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 18. SEO SETTINGS */}
          {/* ============================================================== */}
          {activeTab === 'seo-settings' && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-5">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                গুগল নিউজ ও এসইও কনফিগারেশন (SEO Settings)
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold mb-1">
                    Default Meta Title
                  </label>
                  <input
                    type="text"
                    value={siteSettings.defaultSeoTitle}
                    onChange={(e) =>
                      updateSiteSettings({ defaultSeoTitle: e.target.value })
                    }
                    className="w-full border border-[#D1D5DB] px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">
                    Google Analytics 4 ID
                  </label>
                  <input
                    type="text"
                    value={siteSettings.googleAnalyticsId}
                    onChange={(e) =>
                      updateSiteSettings({ googleAnalyticsId: e.target.value })
                    }
                    className="w-full border border-[#D1D5DB] px-3 py-2 text-xs font-mono-num"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">
                  Default Meta Description
                </label>
                <textarea
                  rows={2}
                  value={siteSettings.defaultMetaDescription}
                  onChange={(e) =>
                    updateSiteSettings({
                      defaultMetaDescription: e.target.value,
                    })
                  }
                  className="w-full border border-[#D1D5DB] p-3 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB]">
                  <span className="text-xs font-bold text-emerald-700">
                    ✓ XML Sitemap সক্রিয়
                  </span>
                  <p className="text-[11px] text-[#6B7280] mt-1">
                    /sitemap.xml (Google News-friendly)
                  </p>
                </div>
                <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB]">
                  <span className="text-xs font-bold text-emerald-700">
                    ✓ Schema.org NewsArticle
                  </span>
                  <p className="text-[11px] text-[#6B7280] mt-1">
                    NewsMediaOrganization + BreadcrumbList JSON-LD
                  </p>
                </div>
                <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB]">
                  <span className="text-xs font-bold text-emerald-700">
                    ✓ Open Graph & Twitter Cards
                  </span>
                  <p className="text-[11px] text-[#6B7280] mt-1">
                    সোশ্যাল মিডিয়া প্রিভিউ কার্ড সক্রিয়
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 19. PUSH NOTIFICATIONS */}
          {/* ============================================================== */}
          {activeTab === 'push-notifications' && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                ব্রেকিং পুশ নোটিফিকেশন (Web Push Notifications)
              </h2>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!pushTitle.trim()) return;
                  sendPushNotification(pushTitle.trim(), pushBody.trim(), pushCat);
                  setPushTitle('');
                  setPushBody('');
                  showToast('সকল সাবস্ক্রাইবারের কাছে পুশ নোটিফিকেশন পাঠানো হয়েছে!');
                }}
                className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 space-y-3"
              >
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="text"
                    required
                    value={pushTitle}
                    onChange={(e) => setPushTitle(e.target.value)}
                    placeholder="নোটিফিকেশন শিরোনাম *"
                    className="sm:col-span-2 bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                  />
                  <select
                    value={pushCat}
                    onChange={(e) => setPushCat(e.target.value)}
                    className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.nameBn}>
                        {c.nameBn}
                      </option>
                    ))}
                  </select>
                </div>
                <textarea
                  rows={2}
                  value={pushBody}
                  onChange={(e) => setPushBody(e.target.value)}
                  placeholder="সংক্ষিপ্ত বার্তা..."
                  className="w-full bg-white border border-[#D1D5DB] p-2.5 text-xs"
                />
                <button
                  type="submit"
                  className="bg-[#D32F2F] text-white font-bold text-xs px-6 py-2.5 cursor-pointer"
                >
                  পুশ নোটিফিকেশন পাঠান
                </button>
              </form>

              <div className="divide-y divide-[#E5E7EB]">
                {pushNotifications.map((p) => (
                  <div
                    key={p.id}
                    className="py-3 flex items-center justify-between"
                  >
                    <div>
                      <span className="text-[11px] font-bold text-[#D32F2F]">
                        {p.targetCategory} • {p.sentAtBn}
                      </span>
                      <h4 className="font-editorial font-bold text-sm text-[#111827]">
                        {p.titleBn}
                      </h4>
                      <p className="text-xs text-[#6B7280]">{p.bodyBn}</p>
                    </div>
                    <span className="text-xs font-mono-num font-bold text-emerald-700">
                      {toBengaliNumber(p.subscribersReached)} পাঠক
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 20. COMMENTS MODERATION */}
          {/* ============================================================== */}
          {activeTab === 'comments' && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-4">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                পাঠকের মন্তব্য মডারেশন ({toBengaliNumber(comments.length)})
              </h2>
              <div className="divide-y divide-[#E5E7EB]">
                {comments.map((cmt) => (
                  <div
                    key={cmt.id}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-xs">
                        <strong className="text-[#111827]">
                          {cmt.authorName}
                        </strong>
                        <span className="text-[#6B7280]">
                          ({cmt.authorLocation}) • {cmt.createdAtBn}
                        </span>
                        <span
                          className={`px-2 py-0.5 text-[10px] font-bold uppercase ${
                            cmt.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {cmt.status}
                        </span>
                      </div>
                      <p className="text-sm text-[#1F2937] my-1">
                        “{cmt.content}”
                      </p>
                      <span className="text-[11px] text-[#6B7280]">
                        সংবাদ: {cmt.articleTitle}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {cmt.status !== 'approved' && (
                        <button
                          onClick={() =>
                            updateCommentStatus(cmt.id, 'approved')
                          }
                          className="px-3 py-1 bg-emerald-700 text-white text-xs font-bold cursor-pointer"
                        >
                          অনুমোদন করুন
                        </button>
                      )}
                      <button
                        onClick={() => deleteComment(cmt.id)}
                        className="px-3 py-1 bg-red-50 text-[#D32F2F] border border-red-200 text-xs font-bold cursor-pointer"
                      >
                        মুছে ফেলুন
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 21. USERS & 22. ROLES & PERMISSIONS */}
          {/* ============================================================== */}
          {(activeTab === 'users' || activeTab === 'roles') && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                ব্যবহারকারী এবং রোল ও পারমিশন (Users & Role-Based Permissions)
              </h2>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newUserName.trim() || !newUserEmail.trim()) return;
                  addAdminUser({
                    name: newUserName.trim(),
                    email: newUserEmail.trim(),
                    role: newUserRole,
                    status: 'active',
                  });
                  setNewUserName('');
                  setNewUserEmail('');
                  showToast('নতুন অ্যাডমিন/এডিটর ইউজার যুক্ত করা হয়েছে');
                }}
                className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 grid grid-cols-1 sm:grid-cols-4 gap-3"
              >
                <input
                  type="text"
                  required
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  placeholder="নাম *"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <input
                  type="email"
                  required
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  placeholder="ইমেইল *"
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs"
                />
                <select
                  value={newUserRole}
                  onChange={(e) => setNewUserRole(e.target.value as any)}
                  className="bg-white border border-[#D1D5DB] px-3 py-2 text-xs font-bold"
                >
                  <option value="Super Admin">Super Admin</option>
                  <option value="Chief Editor">Chief Editor</option>
                  <option value="News Editor">News Editor</option>
                  <option value="Sub-Editor">Sub-Editor</option>
                  <option value="Reporter">Reporter</option>
                  <option value="Ad Manager">Ad Manager</option>
                </select>
                <button
                  type="submit"
                  className="bg-[#111827] text-white font-bold text-xs py-2 cursor-pointer"
                >
                  + ইউজার যোগ করুন
                </button>
              </form>

              <div className="divide-y divide-[#E5E7EB]">
                {adminUsers.map((u) => (
                  <div
                    key={u.id}
                    className="py-3 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-editorial font-bold text-sm text-[#111827]">
                        {u.name}
                      </div>
                      <div className="text-xs text-[#6B7280]">{u.email}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="px-2.5 py-1 bg-[#F3F4F6] border border-[#E5E7EB] text-xs font-bold text-[#D32F2F]">
                        {u.role}
                      </span>
                      <span className="text-xs text-[#6B7280]">
                        {u.lastLoginBn}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 23. SITE SETTINGS */}
          {/* ============================================================== */}
          {activeTab === 'site-settings' && (
            <div className="space-y-6">
              <LogoUploadManager onSuccess={showToast} />

              <div className="bg-white border border-[#E5E7EB] p-5 space-y-5">
                <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                  সাইট সেটিংস (Site Settings — bd7news.com)
                </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold mb-1">
                    পোর্টালের নাম (Brand Name)
                  </label>
                  <input
                    type="text"
                    value={siteSettings.siteName}
                    onChange={(e) =>
                      updateSiteSettings({ siteName: e.target.value })
                    }
                    className="w-full border border-[#D1D5DB] px-3 py-2 text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">
                    ট্যাগলাইন (Tagline)
                  </label>
                  <input
                    type="text"
                    value={siteSettings.taglineBn}
                    onChange={(e) =>
                      updateSiteSettings({ taglineBn: e.target.value })
                    }
                    className="w-full border border-[#D1D5DB] px-3 py-2 text-sm font-editorial"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">
                    প্রধান সম্পাদক (Editor Name)
                  </label>
                  <input
                    type="text"
                    value={siteSettings.editorNameBn}
                    onChange={(e) =>
                      updateSiteSettings({ editorNameBn: e.target.value })
                    }
                    className="w-full border border-[#D1D5DB] px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">
                    ইমেইল (Contact Email)
                  </label>
                  <input
                    type="email"
                    value={siteSettings.email}
                    onChange={(e) =>
                      updateSiteSettings({ email: e.target.value })
                    }
                    className="w-full border border-[#D1D5DB] px-3 py-2 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">
                  কার্যালয়ের ঠিকানা
                </label>
                <input
                  type="text"
                  value={siteSettings.addressBn}
                  onChange={(e) =>
                    updateSiteSettings({ addressBn: e.target.value })
                  }
                  className="w-full border border-[#D1D5DB] px-3 py-2 text-sm"
                />
              </div>

              <button
                onClick={() => showToast('সাইট সেটিংস সফলভাবে সংরক্ষিত হয়েছে!')}
                className="bg-[#D32F2F] text-white font-bold text-xs px-6 py-2.5 cursor-pointer"
              >
                সেটিংস সংরক্ষণ করুন
              </button>
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 24. ANALYTICS & 25. BACKUP */}
          {/* ============================================================== */}
          {(activeTab === 'analytics' || activeTab === 'backup') && (
            <div className="bg-white border border-[#E5E7EB] p-5 space-y-6">
              <h2 className="font-editorial font-extrabold text-xl text-[#111827] border-b-2 border-[#111827] pb-3">
                {activeTab === 'analytics'
                  ? 'রিয়েল-টাইম অ্যানালিটিক্স ও পাঠক পরিসংখ্যান'
                  : 'ডেটাবেজ ব্যাকআপ ও সিস্টেম রিস্টোর'}
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB]">
                  <span className="text-xs text-[#6B7280]">মোট পেজভিউ</span>
                  <div className="text-2xl font-extrabold text-[#111827] mt-1">
                    {toBengaliNumber(totalViews.toLocaleString())}
                  </div>
                </div>
                <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB]">
                  <span className="text-xs text-[#6B7280]">
                    গড় পাঠের সময় (Avg Read Time)
                  </span>
                  <div className="text-2xl font-extrabold text-emerald-700 mt-1">
                    ০৪ মি. ১৮ সে.
                  </div>
                </div>
                <div className="p-4 bg-[#F9FAFB] border border-[#E5E7EB]">
                  <span className="text-xs text-[#6B7280]">ডিভাইস অনুপাত</span>
                  <div className="text-sm font-bold text-[#111827] mt-2">
                    মোবাইল: ৭৪% | ডেস্কটপ: ২৬%
                  </div>
                </div>
              </div>

              <div className="p-5 bg-[#FEF2F2] border border-[#FECACA] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="font-editorial font-bold text-base text-[#111827]">
                    সম্পূর্ণ পোর্টাল ব্যাকআপ ও ডিফল্ট রিসেট
                  </h4>
                  <p className="text-xs text-[#4B5563]">
                    আপনার সকল সংবাদ, বিজ্ঞাপন স্লট ও সেটিংস JSON আকারে ডাউনলোড করুন অথবা ডিফল্ট অবস্থায় ফিরিয়ে নিন।
                  </p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <button
                    onClick={() => {
                      const dataStr =
                        'data:text/json;charset=utf-8,' +
                        encodeURIComponent(
                          JSON.stringify(
                            { articles, ads, siteSettings },
                            null,
                            2
                          )
                        );
                      const dlAnchor = document.createElement('a');
                      dlAnchor.setAttribute('href', dataStr);
                      dlAnchor.setAttribute(
                        'download',
                        'bd7news-cms-backup-2026.json'
                      );
                      dlAnchor.click();
                      showToast('JSON ব্যাকআপ ফাইল ডাউনলোড শুরু হয়েছে');
                    }}
                    className="bg-[#111827] text-white text-xs font-bold px-4 py-2.5 cursor-pointer"
                  >
                    JSON ব্যাকআপ ডাউনলোড
                  </button>
                  <button
                    onClick={() => {
                      resetAllDataToDefault();
                      showToast('সকল ডেটা ডিফল্ট অবস্থায় রিসেট করা হয়েছে');
                    }}
                    className="bg-[#D32F2F] text-white text-xs font-bold px-4 py-2.5 cursor-pointer"
                  >
                    ডিফল্ট ডেটা রিস্টোর
                  </button>
                </div>
              </div>

              <WordPressThemeExporter onSuccess={showToast} />
            </div>
          )}

          {/* ============================================================== */}
          {/* 26. WORDPRESS THEME (.ZIP) GENERATOR */}
          {/* ============================================================== */}
          {activeTab === 'wordpress-theme' && (
            <WordPressThemeExporter onSuccess={showToast} />
          )}
        </main>
      </div>
    </div>
  );
};
