import React, { useState, useEffect, useRef } from 'react';
import {
  Clock,
  Share2,
  Printer,
  Copy,
  Check,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Tag,
  User,
  Quote,
  Eye,
  Send,
  Volume2,
  Square,
  Image as ImageIcon,
  Bookmark,
} from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';
import { NewsCard, MostReadWidget, SectionHeader } from './NewsCard';
import { AdSlot } from './AdSlot';
import { DailyUtilitiesWidget } from './DailyUtilitiesWidget';
import { PhotocardGeneratorModal } from './PhotocardGeneratorModal';

interface ArticlePageProps {
  articleId: string;
}

export const ArticlePage: React.FC<ArticlePageProps> = ({ articleId }) => {
  const {
    articles,
    publishedArticles,
    comments,
    addComment,
    navigateTo,
    incrementArticleView,
    siteSettings,
  } = useNews();

  const [fontSizeLevel, setFontSizeLevel] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [currentChunkIdx, setCurrentChunkIdx] = useState<number>(0);
  const [speechChunks, setSpeechChunks] = useState<string[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isSpeakingRef = useRef<boolean>(false);
  const [bookmarked, setBookmarked] = useState(false);
  const [photocardModalOpen, setPhotocardModalOpen] = useState(false);
  const [selectedReaction, setSelectedReaction] = useState<string | null>(null);
  const [reactionCounts, setReactionCounts] = useState<Record<string, number>>({
    like: 142,
    love: 89,
    wow: 34,
    sad: 12,
    angry: 7,
  });

  // Comment form state
  const [commentAuthor, setCommentAuthor] = useState('');
  const [commentLocation, setCommentLocation] = useState('');
  const [commentText, setCommentText] = useState('');
  const [commentSubmitted, setCommentSubmitted] = useState(false);

  const article = articles.find((a) => a.id === articleId) || publishedArticles[0];

  useEffect(() => {
    if (article) {
      incrementArticleView(article.id);
      document.title = `${article.seoTitle || article.headline} | bd7news.com`;
      try {
        const savedIds: string[] = JSON.parse(
          localStorage.getItem('bd7news_bookmarks_v1') || '[]'
        );
        setBookmarked(savedIds.includes(article.id));
      } catch {}
    }
    return () => {
      isSpeakingRef.current = false;
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      document.title = 'bd7news.com — সত্য সংবাদ সবসময় | বাংলাদেশের শীর্ষ অনলাইন নিউজ পোর্টাল';
    };
  }, [articleId]);

  if (!article) return null;

  // Previous / Next article calculation
  const currentIndex = publishedArticles.findIndex((a) => a.id === article.id);
  const prevArticle =
    currentIndex > 0 ? publishedArticles[currentIndex - 1] : undefined;
  const nextArticle =
    currentIndex >= 0 && currentIndex < publishedArticles.length - 1
      ? publishedArticles[currentIndex + 1]
      : undefined;

  // Related stories in the same category
  const relatedStories = publishedArticles
    .filter((a) => a.category === article.category && a.id !== article.id)
    .slice(0, 4);
  const fallbackRelated =
    relatedStories.length >= 3
      ? relatedStories
      : [
          ...relatedStories,
          ...publishedArticles.filter((a) => a.id !== article.id),
        ].slice(0, 4);

  // Comments for this article
  const articleComments = comments.filter(
    (c) => c.articleId === article.id && c.status === 'approved'
  );

  const shareUrl = `https://bd7news.com/article/${article.slug}`;

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const splitIntoBanglaChunks = (text: string): string[] => {
    const rawSentences = text
      .replace(/\s+/g, ' ')
      .split(/(?<=[।?!\n])/)
      .map((s) => s.trim())
      .filter(Boolean);

    const chunks: string[] = [];
    for (const sentence of rawSentences) {
      if (sentence.length <= 165) {
        chunks.push(sentence);
      } else {
        const words = sentence.split(' ');
        let cur = '';
        for (const w of words) {
          if ((cur + ' ' + w).trim().length > 160 && cur) {
            chunks.push(cur.trim());
            cur = w;
          } else {
            cur = (cur + ' ' + w).trim();
          }
        }
        if (cur) chunks.push(cur.trim());
      }
    }
    return chunks;
  };

  const stopBanglaSpeech = () => {
    isSpeakingRef.current = false;
    setIsSpeaking(false);
    if (audioRef.current) {
      audioRef.current.onended = null;
      audioRef.current.onerror = null;
      audioRef.current.pause();
      audioRef.current.src = '';
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  };

  const playBanglaChunkAt = (
    chunks: string[],
    idx: number,
    rate: number = speechRate
  ) => {
    if (!isSpeakingRef.current || idx >= chunks.length || idx < 0) {
      stopBanglaSpeech();
      return;
    }

    setCurrentChunkIdx(idx);
    const chunkText = chunks[idx];

    // Stop any previous audio
    if (audioRef.current) {
      audioRef.current.onended = null;
      audioRef.current.onerror = null;
      audioRef.current.pause();
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    // Helper: Fallback 2 -> Direct Google Translate Bangla MP3 with no-referrer
    const tryDirectCloudAudio = () => {
      if (!isSpeakingRef.current) return;
      const directAudio = new Audio();
      directAudio.referrerPolicy = 'no-referrer';
      directAudio.src = `https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=bn&client=tw-ob&q=${encodeURIComponent(
        chunkText
      )}`;
      directAudio.playbackRate = rate;
      audioRef.current = directAudio;

      directAudio.onended = () => {
        if (isSpeakingRef.current) {
          playBanglaChunkAt(chunks, idx + 1, rate);
        }
      };
      directAudio.onerror = () => {
        tryBrowserBanglaVoice();
      };
      directAudio.play().catch(() => {
        tryBrowserBanglaVoice();
      });
    };

    // Helper: Fallback 3 -> Native Browser Web Speech API with explicit bn-BD / bn-IN voice search
    const tryBrowserBanglaVoice = () => {
      if (!isSpeakingRef.current || !('speechSynthesis' in window)) {
        stopBanglaSpeech();
        return;
      }
      const utterance = new SpeechSynthesisUtterance(chunkText);
      utterance.lang = 'bn-BD';
      utterance.rate = rate;

      const voices = window.speechSynthesis.getVoices();
      const bnVoice =
        voices.find(
          (v) =>
            v.lang.toLowerCase() === 'bn-bd' ||
            v.lang.toLowerCase() === 'bn_bd'
        ) ||
        voices.find((v) => v.lang.toLowerCase().startsWith('bn')) ||
        voices.find(
          (v) =>
            v.name.toLowerCase().includes('bangla') ||
            v.name.toLowerCase().includes('bengali') ||
            v.name.includes('বাংলা')
        );

      if (bnVoice) {
        utterance.voice = bnVoice;
      }

      utterance.onend = () => {
        if (isSpeakingRef.current) {
          playBanglaChunkAt(chunks, idx + 1, rate);
        }
      };
      utterance.onerror = () => {
        stopBanglaSpeech();
      };
      window.speechSynthesis.speak(utterance);
    };

    // Primary Stage 1: Server-proxied Bangla MP3 (/api/tts-bn)
    const proxyAudio = new Audio(
      `/api/tts-bn?q=${encodeURIComponent(chunkText)}`
    );
    proxyAudio.playbackRate = rate;
    audioRef.current = proxyAudio;

    proxyAudio.onended = () => {
      if (isSpeakingRef.current) {
        playBanglaChunkAt(chunks, idx + 1, rate);
      }
    };
    proxyAudio.onerror = () => {
      tryDirectCloudAudio();
    };
    proxyAudio.play().catch(() => {
      tryDirectCloudAudio();
    });
  };

  const handleToggleSpeech = () => {
    if (isSpeaking) {
      stopBanglaSpeech();
      return;
    }
    const fullText = `${article.headline}। ${article.summary}। ${article.content.join(
      ' '
    )}`;
    const chunks = splitIntoBanglaChunks(fullText);
    if (chunks.length === 0) return;

    setSpeechChunks(chunks);
    isSpeakingRef.current = true;
    setIsSpeaking(true);
    playBanglaChunkAt(chunks, 0, speechRate);
  };

  const handleToggleBookmark = () => {
    try {
      const savedIds: string[] = JSON.parse(
        localStorage.getItem('bd7news_bookmarks_v1') || '[]'
      );
      let updated: string[];
      if (savedIds.includes(article.id)) {
        updated = savedIds.filter((id) => id !== article.id);
        setBookmarked(false);
      } else {
        updated = [...savedIds, article.id];
        setBookmarked(true);
      }
      localStorage.setItem('bd7news_bookmarks_v1', JSON.stringify(updated));
    } catch {}
  };

  const handleDownloadPhotocard = () => {
    setPhotocardModalOpen(true);
  };

  const handleReactionClick = (key: string) => {
    setReactionCounts((prev) => {
      const next = { ...prev };
      if (selectedReaction === key) {
        next[key] = Math.max(0, (next[key] || 1) - 1);
        setSelectedReaction(null);
      } else {
        if (selectedReaction) {
          next[selectedReaction] = Math.max(0, (next[selectedReaction] || 1) - 1);
        }
        next[key] = (next[key] || 0) + 1;
        setSelectedReaction(key);
      }
      return next;
    });
  };

  const encodedUrl = encodeURIComponent(shareUrl);
  const encodedTitle = encodeURIComponent(article.headline);
  const encodedTitleAndUrl = encodeURIComponent(
    `${article.headline} — বিস্তারিত: ${shareUrl}`
  );

  const socialPlatforms = [
    {
      id: 'facebook',
      label: 'Facebook',
      labelBn: 'ফেসবুক',
      bg: 'bg-[#1877F2] hover:bg-[#166FE5]',
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      badge: 'f',
    },
    {
      id: 'messenger',
      label: 'Messenger',
      labelBn: 'মেসেঞ্জার',
      bg: 'bg-[#0084FF] hover:bg-[#0073E6]',
      href: `fb-messenger://share/?link=${encodedUrl}`,
      badge: '💬',
    },
    {
      id: 'whatsapp',
      label: 'WhatsApp',
      labelBn: 'হোয়াটসঅ্যাপ',
      bg: 'bg-[#25D366] hover:bg-[#1EBE5D]',
      href: `https://api.whatsapp.com/send?text=${encodedTitleAndUrl}`,
      badge: 'WA',
    },
    {
      id: 'x',
      label: 'X (Twitter)',
      labelBn: 'এক্স',
      bg: 'bg-[#0F1419] hover:bg-[#272C30]',
      href: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`,
      badge: '𝕏',
    },
    {
      id: 'telegram',
      label: 'Telegram',
      labelBn: 'টেলিগ্রাম',
      bg: 'bg-[#0088CC] hover:bg-[#0077B5]',
      href: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`,
      badge: 'TG',
    },
    {
      id: 'linkedin',
      label: 'LinkedIn',
      labelBn: 'লিংকডইন',
      bg: 'bg-[#0A66C2] hover:bg-[#004182]',
      href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
      badge: 'in',
    },
    {
      id: 'email',
      label: 'Email',
      labelBn: 'ইমেইল',
      bg: 'bg-[#EA4335] hover:bg-[#D33426]',
      href: `mailto:?subject=${encodedTitle}&body=${encodedTitleAndUrl}`,
      badge: '✉',
    },
  ];

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentAuthor.trim() || !commentText.trim()) return;
    addComment(
      article.id,
      article.headline,
      commentAuthor.trim(),
      commentLocation.trim() || 'ঢাকা',
      commentText.trim()
    );
    setCommentAuthor('');
    setCommentLocation('');
    setCommentText('');
    setCommentSubmitted(true);
    setTimeout(() => setCommentSubmitted(false), 3500);
  };

  const bodyFontSizeClass =
    fontSizeLevel === 'large'
      ? 'text-[19px] sm:text-[21px] leading-[1.9]'
      : fontSizeLevel === 'xlarge'
      ? 'text-[21px] sm:text-[23px] leading-[1.95]'
      : 'text-[17px] sm:text-[18.5px] leading-[1.85]';

  // Schema.org NewsArticle & BreadcrumbList JSON-LD
  const schemaJsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'NewsArticle',
        headline: article.headline,
        description: article.metaDescription || article.summary,
        image: [article.featuredImage],
        datePublished: `${article.isoDate}T10:00:00+06:00`,
        dateModified: `${article.isoDate}T16:30:00+06:00`,
        author: [
          {
            '@type': 'Person',
            name: article.reporter,
          },
        ],
        publisher: {
          '@type': 'NewsMediaOrganization',
          name: 'bd7news.com',
          logo: {
            '@type': 'ImageObject',
            url: 'https://bd7news.com/logo.png',
          },
        },
        mainEntityOfPage: {
          '@type': 'WebPage',
          '@id': shareUrl,
        },
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          {
            '@type': 'ListItem',
            position: 1,
            name: 'প্রচ্ছদ',
            item: 'https://bd7news.com/',
          },
          {
            '@type': 'ListItem',
            position: 2,
            name: article.categoryNameBn,
            item: `https://bd7news.com/category/${article.category}`,
          },
          {
            '@type': 'ListItem',
            position: 3,
            name: article.headline,
            item: shareUrl,
          },
        ],
      },
    ],
  };

  return (
    <div className="max-w-[1320px] mx-auto px-4 py-6">
      {/* Schema.org JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaJsonLd) }}
      />

      {/* Breadcrumb */}
      <nav
        aria-label="Breadcrumb"
        className="flex items-center gap-2 text-xs sm:text-sm text-[#6B7280] pb-4 mb-5 border-b border-[#E5E7EB] overflow-x-auto whitespace-nowrap"
      >
        <button
          onClick={() => navigateTo({ type: 'home' })}
          className="hover:text-[#D32F2F] font-medium cursor-pointer"
        >
          প্রচ্ছদ
        </button>
        <span>/</span>
        <button
          onClick={() =>
            navigateTo({ type: 'category', categorySlug: article.category })
          }
          className="text-[#D32F2F] font-bold hover:underline cursor-pointer"
        >
          {article.categoryNameBn}
        </button>
        {article.subcategory && (
          <>
            <span>/</span>
            <button
              onClick={() =>
                navigateTo({
                  type: 'category',
                  categorySlug: article.category,
                  subcategory: article.subcategory,
                })
              }
              className="hover:text-[#111827] cursor-pointer"
            >
              {article.subcategory}
            </button>
          </>
        )}
        <span>/</span>
        <span className="text-[#111827] truncate max-w-xs sm:max-w-md">
          {article.headline}
        </span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* MAIN ARTICLE COLUMN (8 Cols) */}
        <main className="lg:col-span-8 lg:pr-6 lg:border-r lg:border-[#E5E7EB]">
          {/* Pre-Article Top AdSense Banner (Clickable & Dismissible) */}
          <AdSlot slot="top-banner" instanceKey={`art-top-${article.id}`} className="mt-0 mb-5" />

          {/* Category & Location Badge */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <span
              onClick={() =>
                navigateTo({ type: 'category', categorySlug: article.category })
              }
              className="bg-[#D32F2F] text-white text-xs font-bold px-3 py-1 uppercase tracking-wider cursor-pointer"
            >
              {article.categoryNameBn}
            </span>
            {article.subcategory && (
              <span className="text-xs font-semibold text-[#4B5563] bg-[#F3F4F6] px-2.5 py-1 border border-[#E5E7EB]">
                {article.subcategory}
              </span>
            )}
            {article.division && (
              <button
                onClick={() =>
                  navigateTo({
                    type: 'countrywide',
                    division: article.division,
                  })
                }
                className="text-xs font-bold text-[#111827] bg-[#FEF2F2] hover:bg-[#D32F2F] hover:text-white px-2.5 py-1 border border-[#FECACA] transition-colors cursor-pointer"
              >
                📍 {article.division} বিভাগ
              </button>
            )}
            {article.district && (
              <button
                onClick={() =>
                  navigateTo({
                    type: 'countrywide',
                    division: article.division,
                    district: article.district,
                  })
                }
                className="text-xs font-bold text-[#D32F2F] bg-[#FEF2F2] hover:bg-[#D32F2F] hover:text-white px-2.5 py-1 border border-[#FECACA] transition-colors cursor-pointer"
              >
                {article.district} জেলা
              </button>
            )}
            {article.upazila && (
              <button
                onClick={() =>
                  navigateTo({
                    type: 'countrywide',
                    division: article.division,
                    district: article.district,
                    upazila: article.upazila,
                  })
                }
                className="text-xs font-bold text-white bg-[#111827] hover:bg-[#D32F2F] px-2.5 py-1 transition-colors cursor-pointer"
              >
                {article.upazila} উপজেলা
              </button>
            )}
          </div>

          {/* Large Bengali Headline */}
          <h1 className="font-editorial font-extrabold text-2xl sm:text-4xl lg:text-[40px] text-[#111827] leading-[1.32] mb-3">
            {article.headline}
          </h1>

          {/* Subtitle / Deck */}
          {article.subtitle && (
            <p className="font-editorial text-base sm:text-xl text-[#4B5563] leading-[1.55] mb-5 border-l-4 border-[#D32F2F] pl-3.5">
              {article.subtitle}
            </p>
          )}

          {/* Reporter, Published/Updated Timestamps & Multi-Row Social Sharing Bar */}
          <div className="bg-[#F9FAFB] border-y-2 border-[#111827] mb-6">
            {/* Row 1: Reporter Byline + Utility Tools (Audio, Photocard, Bookmark, Font Size, Print) */}
            <div className="py-3.5 px-4 flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#E5E7EB]">
              {/* Reporter & Dates */}
              <div className="flex items-start sm:items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#111827] text-white flex items-center justify-center font-bold shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div className="text-xs sm:text-sm">
                  <div className="font-bold text-[#111827]">
                    {article.reporter}
                  </div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#6B7280] mt-0.5">
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-[#D32F2F]" />
                      প্রকাশ: {article.publishedAt}
                    </span>
                    {article.updatedAt && (
                      <span>• হালনাগাদ: {article.updatedAt}</span>
                    )}
                    <span className="inline-flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      পাঠক: {toBengaliNumber(article.views)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Utility Tools: Audio News / Kalbela Photocard / Bookmark / Font Size / Print */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Audio News Reader (খবরটি শুনুন) */}
                <button
                  onClick={handleToggleSpeech}
                  className={`px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 border transition-colors cursor-pointer ${
                    isSpeaking
                      ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                      : 'bg-white text-[#111827] border-[#D1D5DB] hover:border-[#111827]'
                  }`}
                  title="অডিওতে খবরটি শুনুন"
                >
                  {isSpeaking ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-current" />
                      <span>থামুন</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5 text-[#D32F2F]" />
                      <span>খবরটি শুনুন</span>
                    </>
                  )}
                </button>

                {/* Branded Photocard Generator */}
                <button
                  onClick={handleDownloadPhotocard}
                  className="px-3 py-1.5 bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                  title="ফটোকার্ড ডাউনলোড"
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>ফটোকার্ড ডাউনলোড</span>
                </button>

                {/* Bookmark Article */}
                <button
                  onClick={handleToggleBookmark}
                  className={`px-2.5 py-1.5 border text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                    bookmarked
                      ? 'bg-[#FEF2F2] text-[#D32F2F] border-[#D32F2F]'
                      : 'bg-white text-[#111827] border-[#D1D5DB] hover:border-[#111827]'
                  }`}
                  title="সংবাদটি সংরক্ষণ করুন"
                >
                  <Bookmark
                    className={`w-3.5 h-3.5 ${bookmarked ? 'fill-current' : ''}`}
                  />
                  <span>{bookmarked ? 'সংরক্ষিত' : 'সংরক্ষণ'}</span>
                </button>

                {/* Font Size Adjuster */}
                <div className="flex items-center border border-[#D1D5DB] bg-white">
                  <button
                    onClick={() => setFontSizeLevel('normal')}
                    className={`px-2.5 py-1 text-xs font-bold cursor-pointer ${
                      fontSizeLevel === 'normal'
                        ? 'bg-[#111827] text-white'
                        : 'text-[#111827]'
                    }`}
                    title="স্বাভাবিক ফন্ট"
                  >
                    অ
                  </button>
                  <button
                    onClick={() => setFontSizeLevel('large')}
                    className={`px-2.5 py-1 text-xs font-bold border-x border-[#D1D5DB] cursor-pointer ${
                      fontSizeLevel === 'large'
                        ? 'bg-[#111827] text-white'
                        : 'text-[#111827]'
                    }`}
                    title="বড় ফন্ট"
                  >
                    অ+
                  </button>
                  <button
                    onClick={() => setFontSizeLevel('xlarge')}
                    className={`px-2.5 py-1 text-xs font-bold cursor-pointer ${
                      fontSizeLevel === 'xlarge'
                        ? 'bg-[#111827] text-white'
                        : 'text-[#111827]'
                    }`}
                    title="অতিরিক্ত বড় ফন্ট"
                  >
                    অ++
                  </button>
                </div>

                {/* Print */}
                <button
                  onClick={() => window.print()}
                  className="p-1.5 bg-white hover:bg-[#111827] text-[#111827] hover:text-white border border-[#D1D5DB] transition-colors cursor-pointer"
                  title="প্রিন্ট করুন"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Row 2: Full Multi-Network Social Share Bar (Facebook, Messenger, WhatsApp, X, Telegram, LinkedIn, Email, Copy Link) */}
            <div className="py-2.5 px-4 bg-white flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#111827]">
                <Share2 className="w-3.5 h-3.5 text-[#D32F2F]" />
                <span>শেয়ার করুন:</span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {socialPlatforms.map((sp) => (
                  <a
                    key={sp.id}
                    href={sp.href}
                    target="_blank"
                    rel="noreferrer"
                    className={`px-2.5 py-1.5 text-white text-xs font-bold flex items-center gap-1.5 transition-all ${sp.bg}`}
                    title={`${sp.label}-এ শেয়ার করুন`}
                  >
                    <span className="font-mono-num text-[11px] bg-black/20 px-1.5 py-0.2 rounded-[1px]">
                      {sp.badge}
                    </span>
                    <span>{sp.label}</span>
                  </a>
                ))}

                {/* Copy Link */}
                <button
                  onClick={handleCopyLink}
                  className="px-2.5 py-1.5 bg-[#111827] hover:bg-[#D32F2F] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="লিংক কপি করুন"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>কপি হয়েছে!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>লিংক কপি</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Row 3: Live Bangla Audio News Player Bar (Visible when খবরটি শুনুন is active) */}
            {isSpeaking && speechChunks.length > 0 && (
              <div className="bg-[#111827] text-white px-4 py-3 border-t border-gray-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start sm:items-center gap-2.5 min-w-0">
                  <span className="inline-flex items-center gap-1 bg-[#D32F2F] text-white text-[11px] font-bold px-2 py-0.5 shrink-0 animate-pulse">
                    <Volume2 className="w-3.5 h-3.5" /> বাংলা অডিও চলছে (
                    {toBengaliNumber(currentChunkIdx + 1)}/
                    {toBengaliNumber(speechChunks.length)})
                  </span>
                  <p className="text-xs text-gray-200 truncate font-editorial">
                    “{speechChunks[currentChunkIdx]}”
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      playBanglaChunkAt(
                        speechChunks,
                        Math.max(0, currentChunkIdx - 1),
                        speechRate
                      )
                    }
                    disabled={currentChunkIdx === 0}
                    className="px-2.5 py-1 bg-white/10 hover:bg-white/20 disabled:opacity-40 text-xs font-bold cursor-pointer"
                  >
                    ⏮ আগের বাক্য
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      playBanglaChunkAt(
                        speechChunks,
                        currentChunkIdx + 1,
                        speechRate
                      )
                    }
                    disabled={currentChunkIdx >= speechChunks.length - 1}
                    className="px-2.5 py-1 bg-white/10 hover:bg-white/20 disabled:opacity-40 text-xs font-bold cursor-pointer"
                  >
                    পরের বাক্য ⏭
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const nextRate =
                        speechRate === 1.0 ? 1.15 : speechRate === 1.15 ? 1.25 : 1.0;
                      setSpeechRate(nextRate);
                      if (audioRef.current) {
                        audioRef.current.playbackRate = nextRate;
                      }
                    }}
                    className="px-2.5 py-1 bg-[#FFE600] text-[#111827] text-xs font-extrabold cursor-pointer"
                    title="অডিওর গতি পরিবর্তন করুন"
                  >
                    {toBengaliNumber(speechRate)}x
                  </button>
                  <button
                    type="button"
                    onClick={stopBanglaSpeech}
                    className="px-2.5 py-1 bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold cursor-pointer"
                  >
                    ⏹ থামুন
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Large Featured Image & Caption */}
          <figure className="mb-7 bg-[#F9FAFB] border border-[#E5E7EB] rounded-[2px] overflow-hidden">
            <div className="aspect-16/9 w-full overflow-hidden bg-[#F3F4F6]">
              <img
                src={article.featuredImage}
                alt={article.imageAlt || article.headline}
                className="w-full h-full object-cover"
              />
            </div>
            {article.imageCaption && (
              <figcaption className="px-4 py-2.5 text-xs sm:text-sm text-[#4B5563] border-t border-[#E5E7EB] bg-[#F9FAFB] font-editorial">
                {article.imageCaption}
              </figcaption>
            )}
          </figure>

          {/* Summary Lead Box */}
          <div className="bg-[#F9FAFB] border-l-4 border-[#111827] p-4 mb-6">
            <p className="font-editorial font-semibold text-base sm:text-lg text-[#111827] leading-relaxed">
              {article.summary}
            </p>
          </div>

          {/* Full Bengali Article Body */}
          <div className={`font-editorial text-[#1F2937] space-y-5 ${bodyFontSizeClass}`}>
            {article.content.map((paragraph, index) => (
              <React.Fragment key={index}>
                <p>{paragraph}</p>

                {/* Insert Pull Quote after 2nd paragraph if available */}
                {index === 1 && article.pullQuote && (
                  <blockquote className="my-7 bg-[#FEF2F2] border-l-4 border-[#D32F2F] p-5 sm:p-6 relative">
                    <Quote className="w-8 h-8 text-[#FECACA] absolute top-3 right-4" />
                    <p className="font-editorial font-bold text-lg sm:text-xl text-[#111827] leading-snug relative z-10">
                      “{article.pullQuote}”
                    </p>
                  </blockquote>
                )}

                {/* Insert In-Content Advertisement after 2nd paragraph */}
                {index === 1 && <AdSlot slot="in-content" instanceKey={`art-in-${article.id}`} />}

                {/* Insert In-Feed Native Advertisement after 3rd paragraph */}
                {index === 2 && (
                  <AdSlot
                    slot="in-feed"
                    instanceKey={`art-feed-${article.id}`}
                    className="my-5"
                  />
                )}
              </React.Fragment>
            ))}

            {/* Fallback if article has only 1 paragraph */}
            {article.content.length < 2 && <AdSlot slot="in-content" instanceKey={`art-in-fb-${article.id}`} />}
          </div>

          {/* Article Tags */}
          <div className="mt-8 pt-5 border-t border-[#E5E7EB] flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#111827] mr-2">
              <Tag className="w-4 h-4 text-[#D32F2F]" />
              সম্পর্কিত বিষয়:
            </span>
            {article.tags.map((tag) => (
              <button
                key={tag}
                onClick={() => navigateTo({ type: 'search', query: tag })}
                className="px-3 py-1 bg-[#F3F4F6] hover:bg-[#111827] text-[#374151] hover:text-white text-xs font-semibold border border-[#E5E7EB] transition-colors cursor-pointer"
              >
                #{tag}
              </button>
            ))}
          </div>

          {/* Official Google News & Social Channels Follow Bar (সর্বশেষ খবর পেতে ফলো করুন) */}
          <div className="mt-8 bg-[#111827] text-white p-4 sm:p-5 border-l-4 border-[#D32F2F] flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#FFE600] block">
                সর্বশেষ সংবাদ সবার আগে
              </span>
              <h4 className="font-editorial font-bold text-base sm:text-lg text-white mt-0.5">
                গুগল নিউজ ও সোশ্যাল মিডিয়ায় bd7news.com ফলো করুন:
              </h4>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <a
                href="https://news.google.com"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 bg-white text-[#111827] hover:bg-[#FFE600] text-xs font-extrabold flex items-center gap-1.5 transition-colors"
              >
                <span className="text-[#4285F4] font-black">G</span>
                <span>Google News</span>
              </a>
              <a
                href={siteSettings.facebookUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 bg-[#1877F2] hover:opacity-90 text-white text-xs font-bold flex items-center gap-1.5"
              >
                <span>f</span>
                <span>Facebook পেজ</span>
              </a>
              <a
                href="https://whatsapp.com/channel"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 bg-[#25D366] hover:opacity-90 text-white text-xs font-bold flex items-center gap-1.5"
              >
                <span>WA</span>
                <span>WhatsApp চ্যানেল</span>
              </a>
              <a
                href={siteSettings.youtubeUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 bg-[#FF0000] hover:opacity-90 text-white text-xs font-bold flex items-center gap-1.5"
              >
                <span>▶</span>
                <span>YouTube</span>
              </a>
              <a
                href="https://t.me"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 bg-[#0088CC] hover:opacity-90 text-white text-xs font-bold flex items-center gap-1.5"
              >
                <span>TG</span>
                <span>Telegram</span>
              </a>
            </div>
          </div>

          {/* Reader Emoji Reaction Bar (এই সংবাদে আপনার প্রতিক্রিয়া কী?) */}
          <div className="mt-6 bg-white border border-[#E5E7EB] p-4 sm:p-5">
            <div className="text-xs font-bold text-[#6B7280] uppercase tracking-wider mb-3 text-center">
              এই সংবাদে আপনার প্রতিক্রিয়া জানান
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { key: 'like', emoji: '👍', label: 'ভালো লেগেছে' },
                { key: 'love', emoji: '❤️', label: 'অসাধারণ' },
                { key: 'wow', emoji: '😮', label: 'বিস্ময়কর' },
                { key: 'sad', emoji: '😢', label: 'দুঃখজনক' },
                { key: 'angry', emoji: '😡', label: 'ক্ষুব্ধ' },
              ].map((r) => {
                const active = selectedReaction === r.key;
                return (
                  <button
                    key={r.key}
                    type="button"
                    onClick={() => handleReactionClick(r.key)}
                    className={`py-2.5 px-3 border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                      active
                        ? 'bg-[#FEF2F2] border-[#D32F2F] text-[#D32F2F] ring-1 ring-[#D32F2F]'
                        : 'bg-[#F9FAFB] border-[#E5E7EB] text-[#111827] hover:border-[#111827]'
                    }`}
                  >
                    <span className="text-base">{r.emoji}</span>
                    <span>{r.label}</span>
                    <span className="font-mono-num text-[11px] bg-white px-1.5 py-0.5 border border-[#E5E7EB]">
                      {toBengaliNumber(reactionCounts[r.key] || 0)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Expanded Bottom Social Share Bar */}
          <div className="mt-6 bg-[#F9FAFB] border-2 border-[#111827] p-4 sm:p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E5E7EB] pb-2.5">
              <div className="flex items-center gap-2 text-sm font-extrabold text-[#111827]">
                <Share2 className="w-4 h-4 text-[#D32F2F]" />
                <span>সংবাদটি বন্ধুদের সাথে শেয়ার করুন:</span>
              </div>
              <button
                onClick={handleDownloadPhotocard}
                className="px-3.5 py-1.5 bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>ফটোকার্ড ডাউনলোড</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {socialPlatforms.map((sp) => (
                <a
                  key={sp.id}
                  href={sp.href}
                  target="_blank"
                  rel="noreferrer"
                  className={`px-3.5 py-2 text-white text-xs font-bold flex items-center gap-1.5 transition-all ${sp.bg}`}
                >
                  <span className="font-mono-num text-[11px] bg-black/20 px-1.5 py-0.5">
                    {sp.badge}
                  </span>
                  <span>{sp.label} ({sp.labelBn})</span>
                </a>
              ))}

              <button
                onClick={handleCopyLink}
                className="px-3.5 py-2 bg-[#111827] hover:bg-[#D32F2F] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>লিংক কপি হয়েছে!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>লিংক কপি</span>
                  </>
                )}
              </button>

              <button
                onClick={() => window.print()}
                className="px-3.5 py-2 bg-white hover:bg-[#111827] text-[#111827] hover:text-white border border-[#D1D5DB] text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>প্রিন্ট</span>
              </button>
            </div>
          </div>

          {/* Previous / Next Article Navigation */}
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {prevArticle ? (
              <div
                onClick={() =>
                  navigateTo({ type: 'article', articleId: prevArticle.id })
                }
                className="group cursor-pointer bg-white border border-[#E5E7EB] hover:border-[#111827] p-4 transition-colors"
              >
                <span className="inline-flex items-center gap-1 text-xs font-bold text-[#6B7280] mb-1">
                  <ChevronLeft className="w-3.5 h-3.5" /> পূর্ববর্তী সংবাদ
                </span>
                <h4 className="font-editorial font-bold text-sm sm:text-base text-[#111827] group-hover:text-[#D32F2F] line-clamp-2">
                  {prevArticle.headline}
                </h4>
              </div>
            ) : (
              <div />
            )}

            {nextArticle && (
              <div
                onClick={() =>
                  navigateTo({ type: 'article', articleId: nextArticle.id })
                }
                className="group cursor-pointer bg-white border border-[#E5E7EB] hover:border-[#111827] p-4 text-right transition-colors"
              >
                <span className="inline-flex items-center justify-end gap-1 text-xs font-bold text-[#6B7280] mb-1">
                  পরবর্তী সংবাদ <ChevronRight className="w-3.5 h-3.5" />
                </span>
                <h4 className="font-editorial font-bold text-sm sm:text-base text-[#111827] group-hover:text-[#D32F2F] line-clamp-2">
                  {nextArticle.headline}
                </h4>
              </div>
            )}
          </div>

          {/* Reader Comment Section ("পাঠকের মন্তব্য") */}
          <section className="mt-10 pt-8 border-t-2 border-[#111827]">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-[#D32F2F]" />
                <h3 className="font-editorial font-extrabold text-xl text-[#111827]">
                  পাঠকের মন্তব্য ({toBengaliNumber(articleComments.length)})
                </h3>
              </div>
              <span className="text-xs text-[#6B7280]">
                মার্জিত ও প্রাসঙ্গিক মন্তব্য করুন
              </span>
            </div>

            {/* New Comment Form */}
            <form
              onSubmit={handleCommentSubmit}
              className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 sm:p-5 mb-6"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                <input
                  type="text"
                  required
                  value={commentAuthor}
                  onChange={(e) => setCommentAuthor(e.target.value)}
                  placeholder="আপনার নাম *"
                  className="bg-white border border-[#D1D5DB] focus:border-[#111827] outline-none px-3.5 py-2 text-sm"
                />
                <input
                  type="text"
                  value={commentLocation}
                  onChange={(e) => setCommentLocation(e.target.value)}
                  placeholder="আপনার শহর বা অবস্থান (যেমন: ঢাকা, চট্টগ্রাম)"
                  className="bg-white border border-[#D1D5DB] focus:border-[#111827] outline-none px-3.5 py-2 text-sm"
                />
              </div>
              <textarea
                rows={3}
                required
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="সংবাদটি সম্পর্কে আপনার মতামত লিখুন..."
                className="w-full bg-white border border-[#D1D5DB] focus:border-[#111827] outline-none p-3.5 text-sm mb-3"
              />
              <div className="flex items-center justify-between">
                {commentSubmitted ? (
                  <span className="text-xs font-bold text-emerald-700">
                    ✓ আপনার মন্তব্য সফলভাবে প্রকাশিত হয়েছে।
                  </span>
                ) : (
                  <span className="text-xs text-[#6B7280]">
                    ব্যক্তিগত আক্রমণ ও বিদ্বেষমূলক মন্তব্য প্রকাশযোগ্য নয়।
                  </span>
                )}
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 bg-[#111827] hover:bg-[#D32F2F] text-white text-xs font-bold px-5 py-2.5 transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" /> মন্তব্য প্রকাশ করুন
                </button>
              </div>
            </form>

            {/* Comments List */}
            <div className="space-y-4">
              {articleComments.map((cmt) => (
                <div
                  key={cmt.id}
                  className="bg-white border border-[#E5E7EB] p-4 rounded-[2px]"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-full bg-[#F3F4F6] border border-[#D1D5DB] text-[#111827] font-bold text-xs flex items-center justify-center">
                        {cmt.authorName.charAt(0)}
                      </span>
                      <div>
                        <span className="font-bold text-sm text-[#111827]">
                          {cmt.authorName}
                        </span>
                        {cmt.authorLocation && (
                          <span className="text-xs text-[#6B7280] ml-1.5">
                            ({cmt.authorLocation})
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="text-xs text-[#6B7280]">
                      {cmt.createdAtBn}
                    </span>
                  </div>
                  <p className="text-sm text-[#374151] leading-relaxed pl-9">
                    {cmt.content}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* Related Stories ("সম্পর্কিত আরও সংবাদ") */}
          <AdSlot slot="multiplex-ad" instanceKey={`art-mp-${article.id}`} />

          <section className="mt-8 pt-8 border-t-2 border-[#111827]">
            <SectionHeader
              titleBn="সম্পর্কিত আরও সংবাদ"
              onSeeMore={() =>
                navigateTo({ type: 'category', categorySlug: article.category })
              }
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {fallbackRelated.map((rel) => (
                <NewsCard key={rel.id} article={rel} variant="vertical" />
              ))}
            </div>
          </section>
        </main>

        {/* RIGHT SIDEBAR (4 Cols) */}
        <aside className="lg:col-span-4 space-y-6">
          <AdSlot slot="sidebar-ad" />
          <MostReadWidget />

          {/* Latest in Category Box */}
          <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 rounded-[2px]">
            <div className="flex items-center gap-2 border-b-2 border-[#111827] pb-2 mb-3">
              <span className="w-2.5 h-4 bg-[#D32F2F] inline-block" />
              <h3 className="font-editorial font-bold text-lg text-[#111827]">
                সর্বশেষ আপডেট
              </h3>
            </div>
            <div className="divide-y divide-[#E5E7EB]">
              {publishedArticles.slice(0, 5).map((art) => (
                <NewsCard
                  key={art.id}
                  article={art}
                  variant="compact-right"
                />
              ))}
            </div>
          </div>

          <DailyUtilitiesWidget />
        </aside>
      </div>

      {/* Floating Sticky Vertical Social Share Bar on Desktop Left Edge */}
      <div className="hidden xl:flex fixed left-3 top-1/2 -translate-y-1/2 z-30 flex-col bg-white border-2 border-[#111827] shadow-xl p-1.5 gap-1.5">
        <span className="text-[9px] font-extrabold text-center text-[#111827] uppercase tracking-tighter border-b border-[#E5E7EB] pb-1">
          শেয়ার
        </span>
        {socialPlatforms.slice(0, 6).map((sp) => (
          <a
            key={sp.id}
            href={sp.href}
            target="_blank"
            rel="noreferrer"
            title={`${sp.label}-এ শেয়ার করুন`}
            className={`w-9 h-9 text-white text-xs font-extrabold flex items-center justify-center transition-transform hover:scale-105 ${sp.bg}`}
          >
            {sp.badge}
          </a>
        ))}
        <button
          onClick={handleDownloadPhotocard}
          title="ফটোকার্ড ডাউনলোড"
          className="w-9 h-9 bg-[#D32F2F] hover:bg-[#B71C1C] text-white flex items-center justify-center cursor-pointer"
        >
          <ImageIcon className="w-4 h-4" />
        </button>
        <button
          onClick={handleCopyLink}
          title="লিংক কপি করুন"
          className="w-9 h-9 bg-[#111827] hover:bg-[#D32F2F] text-white flex items-center justify-center cursor-pointer"
        >
          {copied ? (
            <Check className="w-4 h-4 text-emerald-400" />
          ) : (
            <Copy className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Kalbela-Style Photocard Generator Studio Modal */}
      {photocardModalOpen && (
        <PhotocardGeneratorModal
          article={article}
          isModal={true}
          onClose={() => setPhotocardModalOpen(false)}
        />
      )}
    </div>
  );
};
