import React, { useState } from 'react';
import {
  Newspaper,
  Printer,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  Calendar,
  MapPin,
  ArrowLeft,
} from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';

export const EPaperView: React.FC = () => {
  const { publishedArticles, siteSettings, navigateTo } = useNews();
  const [activePage, setActivePage] = useState<number>(1);
  const [edition, setEdition] = useState<string>('ঢাকা সংস্করণ');
  const [zoom, setZoom] = useState<number>(100);

  const pages = [
    {
      num: 1,
      titleBn: 'প্রথম পাতা',
      articles: publishedArticles.slice(0, 7),
    },
    {
      num: 2,
      titleBn: 'নগর ও সারাদেশ',
      articles: publishedArticles
        .filter((a) => a.category === 'countrywide' || a.category === 'national')
        .slice(0, 6),
    },
    {
      num: 3,
      titleBn: 'আন্তর্জাতিক ও রাজনীতি',
      articles: publishedArticles
        .filter((a) => a.category === 'politics' || a.category === 'international')
        .slice(0, 6),
    },
    {
      num: 4,
      titleBn: 'খেলার পাতা (ক্রিকেট ও ফুটবল)',
      articles: publishedArticles
        .filter((a) => a.category === 'cricket' || a.category === 'football')
        .slice(0, 6),
    },
    {
      num: 5,
      titleBn: 'বাণিজ্য, প্রযুক্তি ও চাকরি',
      articles: publishedArticles
        .filter(
          (a) =>
            a.category === 'economy' ||
            a.category === 'technology' ||
            a.category === 'jobs'
        )
        .slice(0, 6),
    },
    {
      num: 6,
      titleBn: 'শেষের পাতা ও আবহাওয়া',
      articles: publishedArticles
        .filter(
          (a) =>
            a.category === 'weather' ||
            a.category === 'special-report' ||
            a.category === 'entertainment'
        )
        .slice(0, 6),
    },
  ];

  const currentPageObj = pages.find((p) => p.num === activePage) || pages[0];
  const pageArticles =
    currentPageObj.articles.length >= 4
      ? currentPageObj.articles
      : publishedArticles.slice(0, 6);

  const leadStory = pageArticles[0];
  const secondaryStories = pageArticles.slice(1, 3);
  const bottomColumns = pageArticles.slice(3, 6);

  return (
    <div className="bg-[#E5E7EB] min-h-screen py-6 px-3 sm:px-6">
      {/* Top E-Paper Control Toolbar */}
      <div className="max-w-[1240px] mx-auto bg-[#111827] text-white p-3.5 sm:p-4 mb-5 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo({ type: 'home' })}
            className="inline-flex items-center gap-1.5 bg-white/10 hover:bg-[#D32F2F] text-white text-xs font-bold px-3 py-1.5 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> অনলাইন সংস্করণে ফিরুন
          </button>
          <div className="flex items-center gap-2">
            <Newspaper className="w-5 h-5 text-[#D32F2F]" />
            <div>
              <h1 className="font-editorial font-extrabold text-base sm:text-lg text-white leading-none">
                bd7news.com ই-পেপার (E-Paper)
              </h1>
              <span className="text-[11px] text-gray-400">
                শনিবার, ২৬ সেপ্টেম্বর ২০২৬ • ১১ আশ্বিন ১৪৩৩ বঙ্গাব্দ
              </span>
            </div>
          </div>
        </div>

        {/* Page Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {pages.map((p) => (
            <button
              key={p.num}
              onClick={() => setActivePage(p.num)}
              className={`px-3 py-1.5 text-xs font-bold transition-colors cursor-pointer shrink-0 ${
                activePage === p.num
                  ? 'bg-[#D32F2F] text-white'
                  : 'bg-white/10 text-gray-300 hover:bg-white/20'
              }`}
            >
              পাতা {toBengaliNumber(p.num)}: {p.titleBn}
            </button>
          ))}
        </div>

        {/* Right Controls: Edition, Zoom, Print */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-white/10 px-2.5 py-1 text-xs">
            <MapPin className="w-3.5 h-3.5 text-[#D32F2F]" />
            <select
              value={edition}
              onChange={(e) => setEdition(e.target.value)}
              className="bg-transparent text-white font-bold outline-none cursor-pointer"
            >
              <option value="ঢাকা সংস্করণ" className="text-black">
                ঢাকা সংস্করণ
              </option>
              <option value="চট্টগ্রাম সংস্করণ" className="text-black">
                চট্টগ্রাম সংস্করণ
              </option>
              <option value="রাজশাহী সংস্করণ" className="text-black">
                রাজশাহী সংস্করণ
              </option>
              <option value="সিলেট সংস্করণ" className="text-black">
                সিলেট সংস্করণ
              </option>
            </select>
          </div>

          <button
            onClick={() => setZoom((z) => Math.max(85, z - 10))}
            className="p-1.5 bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            title="জুম কমান"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono-num font-bold px-1">
            {toBengaliNumber(zoom)}%
          </span>
          <button
            onClick={() => setZoom((z) => Math.min(125, z + 10))}
            className="p-1.5 bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            title="জুম বাড়ান"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold px-3 py-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" /> প্রিন্ট পাতা
          </button>
        </div>
      </div>

      {/* Broadsheet Print Newspaper Sheet */}
      <div
        style={{
          transform: `scale(${zoom / 100})`,
          transformOrigin: 'top center',
        }}
        className="max-w-[1160px] mx-auto bg-[#FCFBF7] text-[#111827] border-2 border-[#111827] shadow-2xl p-5 sm:p-10 transition-transform"
      >
        {/* Newspaper Masthead Header */}
        <div className="border-b-4 border-double border-[#111827] pb-4 mb-6">
          <div className="flex flex-wrap items-center justify-between text-xs font-bold text-[#374151] border-b border-[#111827] pb-2 mb-4">
            <span>বর্ষ ০১ • সংখ্যা ২৪২ • {edition}</span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#D32F2F]" /> শনিবার, ২৬ সেপ্টেম্বর ২০২৬ | ১১ আশ্বিন ১৪৩৩ বঙ্গাব্দ
            </span>
            <span>
              পাতা {toBengaliNumber(currentPageObj.num)} ({currentPageObj.titleBn}) • মূল্য ১০.০০ টাকা
            </span>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="border border-[#111827] p-2.5 text-xs max-w-[240px] bg-white">
              <span className="font-bold text-[#D32F2F] block">আজকের আবহাওয়া:</span>
              <span>ঢাকা: ৩০°সে, আংশিক মেঘলা। সন্ধ্যায় হালকা বৃষ্টির সম্ভাবনা।</span>
            </div>

            <div className="text-center">
              {siteSettings.logoUrl ? (
                <img
                  src={siteSettings.logoUrl}
                  alt={siteSettings.siteName}
                  className="h-16 w-auto mx-auto object-contain"
                />
              ) : (
                <div className="font-editorial font-black text-4xl sm:text-6xl tracking-tight text-[#111827]">
                  bd<span className="text-[#D32F2F]">7</span>news
                  <span className="text-xl sm:text-2xl text-[#D32F2F] font-bold">
                    .com
                  </span>
                </div>
              )}
              <p className="font-editorial font-bold text-xs sm:text-sm text-[#374151] tracking-widest mt-1">
                {siteSettings.taglineBn} — {currentPageObj.titleBn}
              </p>
            </div>

            <div className="border border-[#111827] p-2.5 text-xs max-w-[240px] bg-white text-right">
              <span className="font-bold text-[#111827] block">
                সম্পাদক ও প্রকাশক: {siteSettings.editorNameBn}
              </span>
              <span className="text-[#4B5563]">
                {siteSettings.addressBn}
              </span>
            </div>
          </div>
        </div>

        {/* Broadsheet 8-Column Newspaper Layout */}
        {leadStory && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-6 border-b-2 border-[#111827]">
            {/* Left 8 Cols: Banner Lead Story */}
            <div
              onClick={() =>
                navigateTo({ type: 'article', articleId: leadStory.id })
              }
              className="lg:col-span-8 lg:pr-6 lg:border-r border-[#111827] cursor-pointer group"
            >
              <span className="text-xs font-bold text-[#D32F2F]">
                {leadStory.categoryNameBn} • প্রধান শিরোনাম
              </span>
              <h2 className="font-editorial font-extrabold text-2xl sm:text-4xl text-[#111827] group-hover:text-[#D32F2F] leading-tight mt-1 mb-3">
                {leadStory.headline}
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div className="md:col-span-7">
                  <img
                    src={leadStory.featuredImage}
                    alt={leadStory.headline}
                    className="w-full aspect-16/10 object-cover border border-[#111827]"
                  />
                  <span className="block text-[11px] text-[#4B5563] mt-1 italic">
                    {leadStory.imageCaption}
                  </span>
                </div>
                <div className="md:col-span-5 font-editorial text-sm text-[#1F2937] leading-relaxed space-y-2 text-justify">
                  <p className="font-bold text-[#111827]">
                    {leadStory.reporter}:
                  </p>
                  <p>{leadStory.summary}</p>
                  {leadStory.content[0] && (
                    <p className="line-clamp-5">{leadStory.content[0]}</p>
                  )}
                  <span className="inline-block text-xs font-bold text-[#D32F2F] underline pt-1">
                    বিস্তারিত পড়ুন (ক্লিক করুন) →
                  </span>
                </div>
              </div>
            </div>

            {/* Right 4 Cols: Two Stacked Broadsheet Stories */}
            <div className="lg:col-span-4 divide-y divide-[#111827] space-y-4">
              {secondaryStories.map((art, i) => (
                <div
                  key={art.id}
                  onClick={() =>
                    navigateTo({ type: 'article', articleId: art.id })
                  }
                  className={`cursor-pointer group ${i > 0 ? 'pt-4' : ''}`}
                >
                  <span className="text-[11px] font-bold text-[#D32F2F]">
                    {art.categoryNameBn}
                  </span>
                  <h3 className="font-editorial font-bold text-lg sm:text-xl text-[#111827] group-hover:text-[#D32F2F] leading-snug mt-0.5 mb-2">
                    {art.headline}
                  </h3>
                  <p className="font-editorial text-xs sm:text-sm text-[#374151] leading-relaxed text-justify line-clamp-4">
                    <strong className="text-[#111827]">{art.reporter}: </strong>
                    {art.summary}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bottom 3-Column Broadsheet Articles */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 divide-y md:divide-y-0 md:divide-x divide-[#111827]">
          {bottomColumns.map((art, idx) => (
            <div
              key={art.id}
              onClick={() => navigateTo({ type: 'article', articleId: art.id })}
              className={`cursor-pointer group ${
                idx > 0 ? 'pt-4 md:pt-0 md:pl-6' : ''
              }`}
            >
              <div className="flex items-center gap-2 text-[11px] text-[#6B7280] mb-1">
                <span className="font-bold text-[#D32F2F]">
                  {art.categoryNameBn}
                </span>
                <span>·</span>
                <span>{art.reporter}</span>
              </div>
              <h3 className="font-editorial font-bold text-lg text-[#111827] group-hover:text-[#D32F2F] leading-snug mb-2">
                {art.headline}
              </h3>
              <img
                src={art.featuredImage}
                alt={art.headline}
                className="w-full aspect-16/9 object-cover border border-[#111827] mb-2.5"
              />
              <p className="font-editorial text-xs sm:text-sm text-[#374151] leading-relaxed text-justify line-clamp-4">
                {art.summary}
              </p>
            </div>
          ))}
        </div>

        {/* Newspaper Footer Pagination */}
        <div className="mt-8 pt-4 border-t-2 border-[#111827] flex items-center justify-between text-xs font-bold">
          <button
            onClick={() =>
              setActivePage((p) => (p > 1 ? p - 1 : pages.length))
            }
            className="inline-flex items-center gap-1 px-3 py-1.5 border border-[#111827] bg-white hover:bg-[#111827] hover:text-white cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" /> আগের পাতা
          </button>
          <span>
            bd7news.com ই-পেপার • পাতা {toBengaliNumber(activePage)} /{' '}
            {toBengaliNumber(pages.length)}
          </span>
          <button
            onClick={() =>
              setActivePage((p) => (p < pages.length ? p + 1 : 1))
            }
            className="inline-flex items-center gap-1 px-3 py-1.5 border border-[#111827] bg-white hover:bg-[#111827] hover:text-white cursor-pointer"
          >
            পরের পাতা <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
