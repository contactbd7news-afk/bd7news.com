import React from 'react';
import { Clock, Play, Flame, TrendingUp, ChevronRight } from 'lucide-react';
import { Article } from '../types/news';
import { useNews, toBengaliNumber } from '../context/NewsContext';

interface NewsCardProps {
  article: Article;
  variant?:
    | 'hero'
    | 'sub-hero'
    | 'compact-right'
    | 'vertical'
    | 'horizontal-feed'
    | 'numbered'
    | 'trending-compact'
    | 'overlay'
    | 'video';
  rank?: number;
  className?: string;
}

export const NewsCard: React.FC<NewsCardProps> = ({
  article,
  variant = 'vertical',
  rank,
  className = '',
}) => {
  const { navigateTo, siteSettings } = useNews();
  const isEn = siteSettings.language === 'en';
  const displayHeadline =
    isEn && article.englishHeadline ? article.englishHeadline : article.headline;

  const handleClick = () => {
    navigateTo({ type: 'article', articleId: article.id });
  };

  // 1. HERO FEATURED STORY (Large 16:9 image, photo caption scrim, deck subtitle, summary & key quote)
  if (variant === 'hero') {
    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer bg-white flex flex-col ${className}`}
      >
        <div className="relative aspect-16/9 w-full overflow-hidden bg-[#111827] border border-[#E5E7EB] rounded-[2px]">
          <img
            src={article.featuredImage}
            alt={article.imageAlt || article.headline}
            loading="eager"
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
          />
          {/* Subtle bottom gradient scrim for caption legibility */}
          <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/85 via-black/35 to-transparent pointer-events-none" />

          {/* Top-left Breaking / Lead Status */}
          <div className="absolute top-3 left-3 flex items-center gap-2">
            {article.isBreaking ? (
              <span className="bg-[#D32F2F] text-white text-xs font-bold px-3 py-1 flex items-center gap-1.5 shadow-md">
                <span className="w-2 h-2 rounded-full bg-[#FFE600] animate-ping" />
                <Flame className="w-3.5 h-3.5 fill-current" />
                <span>ব্রেকিং লিড</span>
              </span>
            ) : (
              <span className="bg-[#111827]/90 text-white text-xs font-bold px-3 py-1 border-l-3 border-[#D32F2F]">
                প্রধান সংবাদ
              </span>
            )}
          </div>

          {/* Bottom-left Image Caption overlay */}
          {article.imageCaption && (
            <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between gap-2 text-[11px] text-gray-200 font-editorial">
              <span className="truncate opacity-95">{article.imageCaption}</span>
            </div>
          )}
        </div>

        <div className="pt-4">
          {/* Clean Unboxed Metadata Row */}
          <div className="flex flex-wrap items-center gap-2 text-xs mb-2">
            <span className="font-extrabold text-[#D32F2F] uppercase tracking-wider">
              {article.categoryNameBn}
            </span>
            {article.subcategory && (
              <>
                <span className="text-[#9CA3AF]">•</span>
                <span className="text-[#374151] font-semibold">
                  {article.subcategory}
                </span>
              </>
            )}
            <span className="text-[#9CA3AF]">•</span>
            <span className="inline-flex items-center gap-1 text-[#6B7280]">
              <Clock className="w-3.5 h-3.5 text-[#D32F2F]" />
              {article.timeAgoBn}
            </span>
            <span className="text-[#9CA3AF] hidden sm:inline">•</span>
            <span className="text-[#6B7280] hidden sm:inline">
              {article.reporter}
            </span>
          </div>

          {/* Commanding Bengali Headline */}
          <h1 className="font-editorial font-extrabold text-2xl sm:text-3xl lg:text-[33px] text-[#111827] group-hover:text-[#D32F2F] leading-[1.32] transition-colors mb-3">
            {displayHeadline}
          </h1>

          {/* Editorial Deck / Subtitle if available */}
          {article.subtitle && (
            <div className="border-l-3 border-[#D32F2F] bg-[#FEF2F2]/60 pl-3.5 py-1.5 mb-3">
              <p className="font-editorial font-bold text-sm sm:text-[15px] text-[#1F2937] leading-snug">
                {article.subtitle}
              </p>
            </div>
          )}

          {/* Lead Summary */}
          <p className="text-sm sm:text-[15.5px] text-[#4B5563] leading-[1.72] line-clamp-3 mb-3.5">
            {article.summary}
          </p>

          {/* Bottom Action & Pull Quote Bar */}
          <div className="pt-3 border-t border-[#E5E7EB] flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-3 text-[#6B7280]">
              <span className="font-semibold text-[#111827]">
                পাঠক: {toBengaliNumber(article.views.toLocaleString())}
              </span>
              {article.updatedAt && (
                <>
                  <span>•</span>
                  <span>হালনাগাদ: {article.timeAgoBn}</span>
                </>
              )}
            </div>
            <span className="inline-flex items-center gap-1 font-bold text-[#D32F2F] group-hover:translate-x-0.5 transition-transform">
              <span>বিস্তারিত প্রতিবেদন পড়ুন</span>
              <ChevronRight className="w-4 h-4" />
            </span>
          </div>
        </div>
      </article>
    );
  }

  // 2. SUB-HERO CARD (Medium vertical card below hero or in category main)
  if (variant === 'sub-hero') {
    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer bg-[#F9FAFB] hover:bg-white border border-[#E5E7EB] hover:border-[#111827] p-3.5 rounded-[2px] transition-all flex flex-col justify-between ${className}`}
      >
        <div>
          <div className="relative aspect-16/9 w-full overflow-hidden bg-[#F3F4F6] border border-[#E5E7EB] rounded-[2px] mb-3">
            <img
              src={article.featuredImage}
              alt={article.headline}
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-[1.04] transition-transform duration-300"
            />
            {article.isBreaking && (
              <span className="absolute top-2 left-2 bg-[#D32F2F] text-white text-[10px] font-bold px-2 py-0.5">
                ব্রেকিং
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] mb-1.5">
            <span className="font-extrabold text-[#D32F2F]">
              {article.categoryNameBn}
            </span>
            {article.subcategory && (
              <>
                <span className="text-[#9CA3AF]">•</span>
                <span className="text-[#4B5563] font-medium">
                  {article.subcategory}
                </span>
              </>
            )}
            <span className="text-[#9CA3AF]">•</span>
            <span className="text-[#6B7280]">{article.timeAgoBn}</span>
          </div>
          <h3 className="font-editorial font-bold text-base sm:text-[17px] text-[#111827] group-hover:text-[#D32F2F] leading-[1.38] transition-colors line-clamp-2 mb-1.5">
            {displayHeadline}
          </h3>
          <p className="text-xs sm:text-[13px] text-[#4B5563] line-clamp-2 leading-relaxed">
            {article.summary}
          </p>
        </div>
        <div className="mt-3 pt-2 border-t border-[#E5E7EB] flex items-center justify-between text-[11px] text-[#6B7280]">
          <span className="truncate">{article.reporter}</span>
          <span className="font-bold text-[#111827] group-hover:text-[#D32F2F] shrink-0">
            পড়ুন →
          </span>
        </div>
      </article>
    );
  }

  // 3. COMPACT RIGHT CARD (Thumbnail + Optional Rank + Category + Headline + Summary + Time)
  if (variant === 'compact-right') {
    const rankDisplay =
      rank !== undefined
        ? isEn
          ? String(rank).padStart(2, '0')
          : toBengaliNumber(String(rank).padStart(2, '0'))
        : null;

    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer flex items-start gap-3.5 py-3.5 px-2.5 -mx-2.5 hover:bg-[#F9FAFB] rounded-[2px] transition-colors first:pt-2 last:pb-2 ${className}`}
      >
        <div className="w-32 sm:w-36 aspect-16/10 shrink-0 overflow-hidden bg-[#F3F4F6] border border-[#E5E7EB] rounded-[2px] relative">
          <img
            src={article.featuredImage}
            alt={article.headline}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {rankDisplay && (
            <span className="absolute top-0 left-0 bg-[#111827]/90 text-white font-editorial font-extrabold text-xs px-2 py-0.5 border-b border-r border-white/20">
              {rankDisplay}
            </span>
          )}
          {article.videoDuration && (
            <span className="absolute bottom-1 right-1 bg-black/80 text-white text-[10px] px-1 py-0.5 flex items-center gap-0.5">
              <Play className="w-2.5 h-2.5 fill-current" />
              {article.videoDuration}
            </span>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 text-[11px] mb-1">
            <span className="font-extrabold text-[#D32F2F]">
              {article.categoryNameBn}
            </span>
            {article.subcategory && (
              <>
                <span className="text-[#D1D5DB]">•</span>
                <span className="text-[#6B7280] truncate">
                  {article.subcategory}
                </span>
              </>
            )}
          </div>
          <h3 className="font-editorial font-bold text-sm sm:text-[15.5px] text-[#111827] group-hover:text-[#D32F2F] leading-[1.38] transition-colors line-clamp-2 mb-1">
            {displayHeadline}
          </h3>
          <p className="text-xs text-[#6B7280] line-clamp-1 mb-1.5 hidden sm:block">
            {article.summary}
          </p>
          <div className="flex items-center gap-2 text-[11px] text-[#6B7280]">
            <span className="inline-flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#D32F2F]" />
              {article.timeAgoBn}
            </span>
            <span>•</span>
            <span>{toBengaliNumber(article.views.toLocaleString())} পাঠক</span>
          </div>
        </div>
      </article>
    );
  }

  // 4. HORIZONTAL FEED (For Latest News feed & Category lists)
  if (variant === 'horizontal-feed') {
    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer flex items-start justify-between gap-4 py-4 border-b border-[#E5E7EB] last:border-b-0 ${className}`}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-[#D32F2F]">
              {article.categoryNameBn}
            </span>
            <span className="text-[#D1D5DB]">•</span>
            <span className="text-xs text-[#6B7280] flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {article.timeAgoBn}
            </span>
          </div>
          <h3 className="font-editorial font-bold text-base sm:text-lg text-[#111827] group-hover:text-[#D32F2F] leading-[1.4] transition-colors mb-1.5">
            {displayHeadline}
          </h3>
          <p className="text-xs sm:text-sm text-[#4B5563] line-clamp-2 leading-relaxed hidden sm:block">
            {article.summary}
          </p>
        </div>
        <div className="w-28 sm:w-40 aspect-16/10 shrink-0 overflow-hidden bg-[#F3F4F6] border border-[#E5E7EB] rounded-[2px]">
          <img
            src={article.featuredImage}
            alt={article.headline}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
      </article>
    );
  }

  // 5. NUMBERED MOST READ CARD (01 to 08)
  if (variant === 'numbered') {
    const rankNum = rank || 1;
    const rankDisplay = isEn
      ? String(rankNum).padStart(2, '0')
      : toBengaliNumber(String(rankNum).padStart(2, '0'));

    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer flex items-start gap-3.5 py-3 border-b border-[#E5E7EB] last:border-b-0 ${className}`}
      >
        <span className="font-editorial font-extrabold text-2xl sm:text-3xl text-[#D1D5DB] group-hover:text-[#D32F2F] leading-none select-none transition-colors w-8 shrink-0">
          {rankDisplay}
        </span>
        <div className="flex-1 min-w-0">
          <span className="text-[11px] font-bold text-[#D32F2F] block mb-0.5">
            {article.categoryNameBn}
          </span>
          <h4 className="font-editorial font-bold text-sm sm:text-[15px] text-[#111827] group-hover:text-[#D32F2F] leading-[1.4] transition-colors line-clamp-2">
            {displayHeadline}
          </h4>
        </div>
      </article>
    );
  }

  // 6. TRENDING COMPACT CARD ("আলোচিত")
  if (variant === 'trending-compact') {
    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer bg-[#F9FAFB] hover:bg-white border border-[#E5E7EB] hover:border-[#111827] p-3 rounded-[2px] transition-all flex items-start gap-2.5 ${className}`}
      >
        <TrendingUp className="w-4 h-4 text-[#D32F2F] shrink-0 mt-1" />
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-[11px] text-[#6B7280] mb-0.5">
            <span className="font-bold text-[#D32F2F]">{article.categoryNameBn}</span>
            <span>•</span>
            <span>{article.timeAgoBn}</span>
          </div>
          <h4 className="font-editorial font-bold text-sm text-[#111827] group-hover:text-[#D32F2F] leading-snug line-clamp-2">
            {displayHeadline}
          </h4>
        </div>
      </article>
    );
  }

  // 7. OVERLAY CARD (For "বিশেষ প্রতিবেদন" Special Report)
  if (variant === 'overlay') {
    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer relative aspect-16/10 w-full overflow-hidden bg-[#111827] border border-[#374151] rounded-[2px] ${className}`}
      >
        <img
          src={article.featuredImage}
          alt={article.headline}
          loading="lazy"
          className="w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-90 transition-all duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent" />
        <div className="absolute inset-0 p-5 flex flex-col justify-end">
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-[#D32F2F] text-white text-[11px] font-bold px-2 py-0.5 uppercase tracking-wide">
              {article.categoryNameBn}
            </span>
            <span className="text-xs text-gray-300">{article.subcategory}</span>
          </div>
          <h3 className="font-editorial font-bold text-lg sm:text-xl text-white group-hover:text-[#FCA5A5] leading-[1.38] transition-colors mb-1.5">
            {displayHeadline}
          </h3>
          <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed">
            {article.summary}
          </p>
        </div>
      </article>
    );
  }

  // 8. VIDEO CARD
  if (variant === 'video') {
    return (
      <article
        onClick={handleClick}
        className={`group cursor-pointer flex flex-col ${className}`}
      >
        <div className="relative aspect-16/9 w-full overflow-hidden bg-black border border-[#374151] rounded-[2px] mb-2.5">
          <img
            src={article.featuredImage}
            alt={article.headline}
            loading="lazy"
            className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-black/25 group-hover:bg-black/10 transition-colors flex items-center justify-center">
            <div className="w-11 h-11 rounded-full bg-[#D32F2F] text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
              <Play className="w-5 h-5 fill-current ml-0.5" />
            </div>
          </div>
          {article.videoDuration && (
            <span className="absolute bottom-2 right-2 bg-black/85 text-white font-mono-num text-[11px] font-semibold px-2 py-0.5">
              {article.videoDuration}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 text-[11px] text-[#FCA5A5] font-semibold mb-1">
          <span>{article.subcategory || article.categoryNameBn}</span>
          <span>•</span>
          <span className="text-gray-400">{article.timeAgoBn}</span>
        </div>
        <h4 className="font-editorial font-bold text-sm sm:text-base text-white group-hover:text-[#FCA5A5] leading-[1.4] transition-colors line-clamp-2">
          {displayHeadline}
        </h4>
      </article>
    );
  }

  // DEFAULT VERTICAL CARD
  return (
    <article
      onClick={handleClick}
      className={`group cursor-pointer bg-white border border-[#E5E7EB] hover:border-[#111827] rounded-[2px] overflow-hidden flex flex-col transition-colors ${className}`}
    >
      <div className="relative aspect-16/9 w-full overflow-hidden bg-[#F3F4F6]">
        <img
          src={article.featuredImage}
          alt={article.headline}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="p-3.5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-1.5 mb-1">
            <span className="text-[11px] font-bold text-[#D32F2F]">
              {article.categoryNameBn}
            </span>
            <span className="text-[#D1D5DB]">•</span>
            <span className="text-[11px] text-[#6B7280]">{article.timeAgoBn}</span>
          </div>
          <h3 className="font-editorial font-bold text-base text-[#111827] group-hover:text-[#D32F2F] leading-[1.4] transition-colors line-clamp-3 mb-2">
            {displayHeadline}
          </h3>
        </div>
        <p className="text-xs text-[#4B5563] line-clamp-2 leading-relaxed">
          {article.summary}
        </p>
      </div>
    </article>
  );
};

// Reusable MostRead Sidebar Component ("সর্বাধিক পঠিত" 01-08)
export const MostReadWidget: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { publishedArticles } = useNews();

  const mostReadArticles = [...publishedArticles]
    .sort((a, b) => {
      if (a.mostReadRank && b.mostReadRank) return a.mostReadRank - b.mostReadRank;
      if (a.mostReadRank) return -1;
      if (b.mostReadRank) return 1;
      return b.views - a.views;
    })
    .slice(0, 8);

  return (
    <div className={`bg-white border border-[#E5E7EB] p-4 rounded-[2px] ${className}`}>
      <div className="flex items-center justify-between border-b-2 border-[#111827] pb-2.5 mb-2">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-5 bg-[#D32F2F] inline-block" />
          <h3 className="font-editorial font-bold text-lg text-[#111827]">
            সর্বাধিক পঠিত
          </h3>
        </div>
        <span className="text-[11px] font-semibold text-[#6B7280] bg-[#F3F4F6] px-2 py-0.5">
          শীর্ষ ০৮
        </span>
      </div>

      <div className="divide-y divide-[#E5E7EB]">
        {mostReadArticles.map((art, index) => (
          <NewsCard
            key={art.id}
            article={art}
            variant="numbered"
            rank={index + 1}
          />
        ))}
      </div>
    </div>
  );
};

// Reusable Section Header Component
export const SectionHeader: React.FC<{
  titleBn: string;
  subtitleBn?: string;
  onSeeMore?: () => void;
  seeMoreLabelBn?: string;
  dark?: boolean;
}> = ({ titleBn, subtitleBn, onSeeMore, seeMoreLabelBn = 'আরও সংবাদ', dark = false }) => {
  return (
    <div
      className={`flex items-center justify-between pb-2.5 mb-5 border-b-2 ${
        dark ? 'border-white/20 text-white' : 'border-[#111827] text-[#111827]'
      }`}
    >
      <div className="flex items-center gap-2.5">
        <span className="w-3 h-6 bg-[#D32F2F] inline-block shrink-0" />
        <div>
          <h2 className="font-editorial font-extrabold text-xl sm:text-2xl leading-none">
            {titleBn}
          </h2>
          {subtitleBn && (
            <p
              className={`text-xs mt-1 ${
                dark ? 'text-gray-400' : 'text-[#6B7280]'
              }`}
            >
              {subtitleBn}
            </p>
          )}
        </div>
      </div>

      {onSeeMore && (
        <button
          onClick={onSeeMore}
          className={`inline-flex items-center gap-1 text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
            dark
              ? 'text-[#FCA5A5] hover:text-white'
              : 'text-[#D32F2F] hover:text-[#111827]'
          }`}
        >
          <span>{seeMoreLabelBn}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
