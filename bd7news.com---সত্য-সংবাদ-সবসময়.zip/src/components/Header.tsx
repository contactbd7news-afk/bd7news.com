import React, { useState } from 'react';
import {
  Search,
  Globe,
  ShieldCheck,
  Flame,
  ChevronDown,
  Menu,
  X,
  Calendar,
  Play,
  Camera,
  FileText,
  Compass,
  CloudSun,
} from 'lucide-react';
import { useNews } from '../context/NewsContext';
import { AdSlot } from './AdSlot';

export const Header: React.FC = () => {
  const {
    activeView,
    navigateTo,
    categories,
    siteSettings,
    toggleLanguage,
    currentAdminUser,
  } = useNews();

  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [sportsMenuOpen, setSportsMenuOpen] = useState(false);
  const [mobileSportsExpanded, setMobileSportsExpanded] = useState(true);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [quickSearchOpen, setQuickSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const isEn = siteSettings.language === 'en';

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      navigateTo({ type: 'search', query: '' });
    } else {
      navigateTo({ type: 'search', query: searchQuery.trim() });
    }
    setQuickSearchOpen(false);
  };

  // Main Navigation Items (Cricket & Football are now sub-menus under খেলাধুলা)
  const navItems = [
    { key: 'home', labelBn: 'প্রচ্ছদ', labelEn: 'Home', action: () => navigateTo({ type: 'home' }) },
    { key: 'latest', labelBn: 'সর্বশেষ', labelEn: 'Latest', action: () => navigateTo({ type: 'latest' }) },
    { key: 'national', labelBn: 'জাতীয়', labelEn: 'National', action: () => navigateTo({ type: 'category', categorySlug: 'national' }) },
    { key: 'countrywide', labelBn: 'সারাদেশ (জেলা-উপজেলা)', labelEn: 'Countrywide', action: () => navigateTo({ type: 'countrywide' }) },
    { key: 'politics', labelBn: 'রাজনীতি', labelEn: 'Politics', action: () => navigateTo({ type: 'category', categorySlug: 'politics' }) },
    { key: 'international', labelBn: 'আন্তর্জাতিক', labelEn: 'International', action: () => navigateTo({ type: 'category', categorySlug: 'international' }) },
    {
      key: 'sports',
      labelBn: 'খেলাধুলা',
      labelEn: 'Sports',
      hasSubmenu: true,
      action: () => {
        navigateTo({ type: 'category', categorySlug: 'sports' });
        setSportsMenuOpen((prev) => !prev);
        setMoreMenuOpen(false);
      },
    },
    { key: 'entertainment', labelBn: 'বিনোদন', labelEn: 'Entertainment', action: () => navigateTo({ type: 'category', categorySlug: 'entertainment' }) },
    { key: 'economy', labelBn: 'অর্থনীতি', labelEn: 'Economy', action: () => navigateTo({ type: 'category', categorySlug: 'economy' }) },
    { key: 'technology', labelBn: 'প্রযুক্তি', labelEn: 'Technology', action: () => navigateTo({ type: 'category', categorySlug: 'technology' }) },
    { key: 'jobs', labelBn: 'চাকরি', labelEn: 'Jobs', action: () => navigateTo({ type: 'category', categorySlug: 'jobs' }) },
    { key: 'weather', labelBn: 'আবহাওয়া', labelEn: 'Weather', action: () => navigateTo({ type: 'weather' }) },
    { key: 'lifestyle', labelBn: 'জীবনযাপন', labelEn: 'Lifestyle', action: () => navigateTo({ type: 'category', categorySlug: 'lifestyle' }) },
    { key: 'religion', labelBn: 'ধর্ম', labelEn: 'Religion', action: () => navigateTo({ type: 'category', categorySlug: 'religion' }) },
    { key: 'video', labelBn: 'ভিডিও', labelEn: 'Video', action: () => navigateTo({ type: 'video' }) },
  ];

  const isSportsSectionActive =
    activeView.type === 'category' &&
    (activeView.categorySlug === 'sports' ||
      activeView.categorySlug === 'cricket' ||
      activeView.categorySlug === 'football');

  const isNavItemActive = (key: string) => {
    if (key === 'home' && activeView.type === 'home') return true;
    if (key === 'latest' && activeView.type === 'latest') return true;
    if (key === 'countrywide' && activeView.type === 'countrywide') return true;
    if (key === 'weather' && (activeView.type === 'weather' || (activeView.type === 'category' && activeView.categorySlug === 'weather'))) return true;
    if (key === 'video' && activeView.type === 'video') return true;
    if (key === 'sports' && isSportsSectionActive) return true;
    if (activeView.type === 'category' && activeView.categorySlug === key) return true;
    return false;
  };

  return (
    <header className="bg-white border-b border-[#E5E7EB] relative z-30">
      {/* Top Banner Ad Slot (Controllable from Admin Panel) */}
      <div className="max-w-[1320px] mx-auto px-4">
        <AdSlot slot="top-banner" className="my-1.5" />
      </div>

      {/* 1. VERY TOP UTILITY BAR */}
      <div className="bg-[#F9FAFB] border-y border-[#E5E7EB] text-xs text-[#4B5563]">
        <div className="max-w-[1320px] mx-auto px-4 h-9 flex items-center justify-between gap-2">
          {/* Date */}
          <div className="flex items-center gap-2 truncate">
            <Calendar className="w-3.5 h-3.5 text-[#D32F2F] shrink-0" />
            <span className="font-medium text-[#111827]">
              {isEn
                ? 'Saturday, 26 September 2026 | 11 Ashwin 1433'
                : 'শনিবার, ২৬ সেপ্টেম্বর ২০২৬ | ১১ আশ্বিন ১৪৩৩ বঙ্গাব্দ'}
            </span>
            <span className="hidden lg:inline text-[#9CA3AF]">|</span>
            <button
              onClick={() => navigateTo({ type: 'weather' })}
              className="hidden md:inline-flex items-center gap-1.5 text-[#0284C7] hover:text-[#D32F2F] font-bold transition-colors cursor-pointer"
              title="আজকের আবহাওয়ার খবর ও পূর্বাভাস"
            >
              <CloudSun className="w-3.5 h-3.5" />
              <span>{isEn ? 'Dhaka 30°C • Weather' : 'ঢাকা ৩০°সে • আবহাওয়ার খবর'}</span>
            </button>
            <span className="hidden lg:inline text-[#9CA3AF]">|</span>
            <button
              onClick={() => navigateTo({ type: 'epaper' })}
              className="hidden sm:inline-flex items-center gap-1.5 text-[#111827] hover:text-[#D32F2F] font-bold transition-colors cursor-pointer"
              title="আজকের ছাপা পত্রিকা (ই-পেপার সংস্করণ)"
            >
              <FileText className="w-3.5 h-3.5 text-[#D32F2F]" />
              <span>{isEn ? 'E-Paper' : 'ই-পেপার'}</span>
            </button>
          </div>

          {/* Right Utility Controls */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            {/* Language Switch: বাংলা ও English */}
            <button
              onClick={toggleLanguage}
              className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-white border border-[#E5E7EB] hover:border-[#111827] text-[#111827] font-semibold text-[11px] transition-colors cursor-pointer"
              title="ভাষা পরিবর্তন করুন / Switch Language"
            >
              <Globe className="w-3 h-3 text-[#D32F2F]" />
              <span className={!isEn ? 'text-[#D32F2F] font-bold' : 'text-[#6B7280]'}>
                বাংলা
              </span>
              <span className="text-[#D1D5DB]">/</span>
              <span className={isEn ? 'text-[#D32F2F] font-bold' : 'text-[#6B7280]'}>
                English
              </span>
            </button>

            {/* Search Icon */}
            <button
              onClick={() => setQuickSearchOpen(!quickSearchOpen)}
              className="inline-flex items-center gap-1 text-[#111827] hover:text-[#D32F2F] font-medium transition-colors cursor-pointer"
              title="সংবাদ খুঁজুন"
            >
              <Search className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isEn ? 'Search' : 'খুঁজুন'}</span>
            </button>

            {/* Social Media Icons */}
            <div className="hidden md:flex items-center gap-2.5 border-x border-[#E5E7EB] px-3">
              <a
                href={siteSettings.facebookUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[#4B5563] hover:text-[#1877F2] font-bold text-[11px]"
                title="Facebook"
              >
                FB
              </a>
              <a
                href={siteSettings.youtubeUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[#4B5563] hover:text-[#FF0000] font-bold text-[11px]"
                title="YouTube"
              >
                YT
              </a>
              <a
                href={siteSettings.xUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[#4B5563] hover:text-[#111827] font-bold text-[11px]"
                title="X (Twitter)"
              >
                X
              </a>
              <a
                href={siteSettings.instagramUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[#4B5563] hover:text-[#E4405F] font-bold text-[11px]"
                title="Instagram"
              >
                IG
              </a>
            </div>

            {/* Login / Admin Button */}
            <button
              onClick={() => navigateTo({ type: 'admin', tab: 'dashboard' })}
              className="inline-flex items-center gap-1.5 bg-[#111827] hover:bg-[#D32F2F] text-white px-2.5 py-1 text-[11px] font-semibold transition-colors cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>
                {currentAdminUser
                  ? isEn
                    ? 'Admin Panel'
                    : 'অ্যাডমিন প্যানেল'
                  : isEn
                  ? 'Login / Admin'
                  : 'লগইন / অ্যাডমিন'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. MAIN HEADER (Masthead) */}
      <div className="max-w-[1320px] mx-auto px-4 py-3.5 md:py-5 flex items-center justify-between gap-4">
        {/* Left: Hamburger (Mobile) + Brand Logo & Tagline */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileDrawerOpen(true)}
            className="lg:hidden p-2 border border-[#E5E7EB] text-[#111827] hover:border-[#111827]"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div
            onClick={() => navigateTo({ type: 'home' })}
            className="cursor-pointer group select-none"
          >
            {siteSettings.logoUrl ? (
              <div>
                <img
                  src={siteSettings.logoUrl}
                  alt={siteSettings.siteName}
                  style={{ height: `${siteSettings.logoHeight || 52}px` }}
                  className="w-auto max-w-[240px] sm:max-w-[340px] object-contain"
                />
                {(siteSettings.showTaglineWithLogo ?? true) && (
                  <div className="flex items-center gap-2 mt-1">
                    <span className="h-[2px] w-6 bg-[#D32F2F] inline-block" />
                    <p className="font-editorial font-semibold text-xs sm:text-sm text-[#4B5563] tracking-wide">
                      {isEn ? siteSettings.taglineEn : siteSettings.taglineBn}
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div>
                <div className="flex items-baseline gap-1">
                  <span className="font-editorial font-extrabold text-3xl sm:text-4xl md:text-[44px] tracking-tight text-[#111827] leading-none">
                    bd<span className="text-[#D32F2F]">7</span>news
                  </span>
                  <span className="font-ui font-bold text-base sm:text-xl text-[#D32F2F]">
                    .com
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="h-[2px] w-6 bg-[#D32F2F] inline-block" />
                  <p className="font-editorial font-semibold text-xs sm:text-sm text-[#4B5563] tracking-wide">
                    {isEn ? siteSettings.taglineEn : siteSettings.taglineBn}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Center/Right Optional Header Ad Slot on Desktop */}
        <div className="hidden xl:block">
          <AdSlot slot="header-ad" />
        </div>

        {/* Right Side: Breaking News button, Search, Social Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Breaking News Button */}
          <button
            onClick={() => navigateTo({ type: 'latest' })}
            className="inline-flex items-center gap-1.5 bg-[#FEF2F2] hover:bg-[#D32F2F] text-[#D32F2F] hover:text-white border border-[#FECACA] px-3 py-2 text-xs sm:text-sm font-bold transition-colors cursor-pointer"
          >
            <Flame className="w-4 h-4 fill-current" />
            <span>{isEn ? 'Breaking News' : 'ব্রেকিং নিউজ'}</span>
          </button>

          {/* Search Button */}
          <button
            onClick={() => setQuickSearchOpen(!quickSearchOpen)}
            className="inline-flex items-center gap-1.5 bg-[#F9FAFB] hover:bg-[#111827] text-[#111827] hover:text-white border border-[#E5E7EB] px-3 py-2 text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
          >
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline">{isEn ? 'Search' : 'অনুসন্ধান'}</span>
          </button>

          {/* Social Icons on Main Header */}
          <div className="hidden sm:flex items-center gap-1.5">
            <a
              href={siteSettings.facebookUrl}
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 flex items-center justify-center border border-[#E5E7EB] hover:border-[#111827] hover:bg-[#111827] hover:text-white text-xs font-bold transition-colors"
              title="Facebook"
            >
              f
            </a>
            <a
              href={siteSettings.youtubeUrl}
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 flex items-center justify-center border border-[#E5E7EB] hover:border-[#D32F2F] hover:bg-[#D32F2F] hover:text-white text-xs font-bold transition-colors"
              title="YouTube"
            >
              ▶
            </a>
            <a
              href={siteSettings.xUrl}
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 flex items-center justify-center border border-[#E5E7EB] hover:border-[#111827] hover:bg-[#111827] hover:text-white text-xs font-bold transition-colors"
              title="X"
            >
              𝕏
            </a>
          </div>
        </div>
      </div>

      {/* Expandable Search Bar */}
      {quickSearchOpen && (
        <div className="bg-[#F9FAFB] border-t border-[#E5E7EB] py-3 px-4 shadow-inner">
          <form
            onSubmit={handleSearchSubmit}
            className="max-w-[800px] mx-auto flex items-center gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#6B7280] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="শিরোনাম, বিষয় বা কীওয়ার্ড লিখে সংবাদ খুঁজুন (যেমন: মেট্রোরেল, ক্রিকেট, অর্থনীতি)..."
                className="w-full bg-white border border-[#D1D5DB] focus:border-[#111827] outline-none pl-10 pr-4 py-2 text-sm text-[#111827]"
                autoFocus
              />
            </div>
            <button
              type="submit"
              className="bg-[#D32F2F] hover:bg-[#B71C1C] text-white font-semibold text-sm px-5 py-2 transition-colors cursor-pointer"
            >
              খুঁজুন
            </button>
            <button
              type="button"
              onClick={() => setQuickSearchOpen(false)}
              className="p-2 text-[#6B7280] hover:text-[#111827] border border-[#E5E7EB] bg-white"
            >
              <X className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* 3. STICKY MAIN NAVIGATION BAR */}
      <nav
        className="sticky top-0 z-30 bg-white border-t-2 border-t-[#111827] border-b border-b-[#E5E7EB] shadow-xs"
        onMouseLeave={() => setSportsMenuOpen(false)}
      >
        <div className="max-w-[1320px] mx-auto px-4 flex items-center justify-between h-11">
          <div className="flex items-center overflow-x-auto no-scrollbar divide-x divide-[#F3F4F6]">
            {navItems.map((item) => {
              const active = isNavItemActive(item.key);
              const isSports = item.key === 'sports';
              return (
                <button
                  key={item.key}
                  onMouseEnter={() => {
                    if (isSports) {
                      setSportsMenuOpen(true);
                      setMoreMenuOpen(false);
                    }
                  }}
                  onClick={() => {
                    if (!isSports) {
                      setSportsMenuOpen(false);
                      setMoreMenuOpen(false);
                    }
                    item.action();
                  }}
                  className={`px-3 xl:px-3.5 h-11 flex items-center gap-1 text-[14px] font-semibold whitespace-nowrap transition-colors relative cursor-pointer ${
                    active
                      ? 'text-[#D32F2F] bg-[#FEF2F2]'
                      : 'text-[#111827] hover:text-[#D32F2F] hover:bg-[#F9FAFB]'
                  }`}
                >
                  <span>{isEn ? item.labelEn : item.labelBn}</span>
                  {item.hasSubmenu && (
                    <ChevronDown
                      className={`w-3.5 h-3.5 transition-transform ${
                        sportsMenuOpen || isSportsSectionActive
                          ? 'rotate-180 text-[#D32F2F]'
                          : ''
                      }`}
                    />
                  )}
                  {active && (
                    <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-[#D32F2F]" />
                  )}
                </button>
              );
            })}

            {/* আরও ▼ Dropdown Button */}
            <div className="relative">
              <button
                onClick={() => {
                  setMoreMenuOpen(!moreMenuOpen);
                  setSportsMenuOpen(false);
                }}
                className="px-3.5 h-11 flex items-center gap-1 text-[14px] font-semibold text-[#111827] hover:text-[#D32F2F] whitespace-nowrap cursor-pointer"
              >
                <span>{isEn ? 'More' : 'আরও'}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* খেলাধুলা (Sports) Sub-Menu Bar: ক্রিকেট | ফুটবল | অন্যান্য */}
        {(sportsMenuOpen || isSportsSectionActive) && (
          <div className="bg-[#F9FAFB] border-t border-[#E5E7EB] border-b border-[#D1D5DB] shadow-xs">
            <div className="max-w-[1320px] mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                <span className="text-xs font-extrabold text-[#111827] uppercase tracking-wider px-2 py-1 bg-[#E5E7EB] rounded-[2px] shrink-0">
                  {isEn ? 'Sports Menu:' : 'খেলাধুলা সাব-মেনু:'}
                </span>

                <button
                  onClick={() => {
                    navigateTo({ type: 'category', categorySlug: 'sports' });
                    setSportsMenuOpen(false);
                  }}
                  className={`px-3 py-1 text-xs sm:text-sm font-bold border transition-colors cursor-pointer whitespace-nowrap ${
                    activeView.type === 'category' &&
                    activeView.categorySlug === 'sports' &&
                    !activeView.subcategory
                      ? 'bg-[#111827] text-white border-[#111827]'
                      : 'bg-white text-[#111827] border-[#D1D5DB] hover:border-[#D32F2F] hover:text-[#D32F2F]'
                  }`}
                >
                  {isEn ? 'All Sports' : 'সব খেলাধুলা'}
                </button>

                {/* ক্রিকেট Sub-Menu Item */}
                <button
                  onClick={() => {
                    navigateTo({ type: 'category', categorySlug: 'cricket' });
                    setSportsMenuOpen(false);
                  }}
                  className={`px-3.5 py-1 text-xs sm:text-sm font-bold border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                    activeView.type === 'category' &&
                    activeView.categorySlug === 'cricket'
                      ? 'bg-[#047857] text-white border-[#047857]'
                      : 'bg-white text-[#111827] border-[#D1D5DB] hover:border-[#047857] hover:text-[#047857]'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                  <span>{isEn ? 'Cricket' : 'ক্রিকেট'}</span>
                </button>

                {/* ফুটবল Sub-Menu Item */}
                <button
                  onClick={() => {
                    navigateTo({ type: 'category', categorySlug: 'football' });
                    setSportsMenuOpen(false);
                  }}
                  className={`px-3.5 py-1 text-xs sm:text-sm font-bold border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                    activeView.type === 'category' &&
                    activeView.categorySlug === 'football'
                      ? 'bg-[#1D4ED8] text-white border-[#1D4ED8]'
                      : 'bg-white text-[#111827] border-[#D1D5DB] hover:border-[#1D4ED8] hover:text-[#1D4ED8]'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-[#3B82F6]" />
                  <span>{isEn ? 'Football' : 'ফুটবল'}</span>
                </button>

                {/* Quick Tournament Sub-Links */}
                <span className="text-[#D1D5DB] hidden md:inline">|</span>
                {[
                  { label: 'বাংলাদেশ ক্রিকেট', slug: 'cricket', sub: 'Bangladesh Cricket' },
                  { label: 'বিপিএল (BPL)', slug: 'cricket', sub: 'BPL' },
                  { label: 'আইসিসি (ICC)', slug: 'cricket', sub: 'ICC' },
                  { label: 'বাংলাদেশ ফুটবল', slug: 'football', sub: 'Bangladesh Football' },
                  { label: 'চ্যাম্পিয়নস লিগ', slug: 'football', sub: 'Champions League' },
                  { label: 'প্রিমিয়ার লিগ', slug: 'football', sub: 'Premier League' },
                ].map((t) => (
                  <button
                    key={t.sub}
                    onClick={() => {
                      navigateTo({
                        type: 'category',
                        categorySlug: t.slug,
                        subcategory: t.sub,
                      });
                      setSportsMenuOpen(false);
                    }}
                    className={`hidden md:inline-flex px-2.5 py-1 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                      activeView.type === 'category' &&
                      activeView.subcategory === t.sub
                        ? 'text-[#D32F2F] font-bold underline'
                        : 'text-[#4B5563] hover:text-[#D32F2F]'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* আরও ▼ Mega Dropdown Panel */}
        {moreMenuOpen && (
          <div className="absolute left-0 right-0 top-full bg-white border-b-2 border-[#111827] shadow-xl z-40">
            <div className="max-w-[1320px] mx-auto p-6 grid grid-cols-2 sm:grid-cols-4 gap-6">
              <div>
                <h4 className="font-editorial font-bold text-sm text-[#D32F2F] border-b border-[#E5E7EB] pb-2 mb-3">
                  বিশেষ আয়োজন
                </h4>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button
                      onClick={() => {
                        navigateTo({ type: 'category', categorySlug: 'special-report' });
                        setMoreMenuOpen(false);
                      }}
                      className="flex items-center gap-2 text-[#111827] hover:text-[#D32F2F] font-medium cursor-pointer"
                    >
                      <Compass className="w-4 h-4 text-[#D32F2F]" /> বিশেষ প্রতিবেদন
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => {
                        navigateTo({ type: 'category', categorySlug: 'opinion' });
                        setMoreMenuOpen(false);
                      }}
                      className="flex items-center gap-2 text-[#111827] hover:text-[#D32F2F] font-medium cursor-pointer"
                    >
                      <FileText className="w-4 h-4 text-[#D32F2F]" /> মতামত ও কলাম
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => {
                        navigateTo({ type: 'photo-gallery' });
                        setMoreMenuOpen(false);
                      }}
                      className="flex items-center gap-2 text-[#111827] hover:text-[#D32F2F] font-medium cursor-pointer"
                    >
                      <Camera className="w-4 h-4 text-[#D32F2F]" /> ছবিতে আজ (ফটো গ্যালারি)
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => {
                        navigateTo({ type: 'epaper' });
                        setMoreMenuOpen(false);
                      }}
                      className="flex items-center gap-2 text-[#111827] hover:text-[#D32F2F] font-bold cursor-pointer"
                    >
                      <FileText className="w-4 h-4 text-[#D32F2F]" /> আজকের পত্রিকা (ই-পেপার)
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => {
                        navigateTo({ type: 'video' });
                        setMoreMenuOpen(false);
                      }}
                      className="flex items-center gap-2 text-[#111827] hover:text-[#D32F2F] font-medium cursor-pointer"
                    >
                      <Play className="w-4 h-4 text-[#D32F2F]" /> ভিডিও সংবাদ
                    </button>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-editorial font-bold text-sm text-[#111827] border-b border-[#E5E7EB] pb-2 mb-3">
                  সকল বিভাগ
                </h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        navigateTo({ type: 'category', categorySlug: cat.slug });
                        setMoreMenuOpen(false);
                      }}
                      className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                    >
                      • {cat.nameBn}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-editorial font-bold text-sm text-[#111827] border-b border-[#E5E7EB] pb-2 mb-3">
                  খেলাধুলা ও টুর্নামেন্ট
                </h4>
                <ul className="space-y-1.5 text-sm text-[#4B5563]">
                  {['Bangladesh Cricket', 'BPL', 'ICC', 'Bangladesh Football', 'Champions League', 'Premier League'].map(
                    (sub) => (
                      <li key={sub}>
                        <button
                          onClick={() => {
                            navigateTo({
                              type: 'category',
                              categorySlug: sub.includes('Football') || sub.includes('League') ? 'football' : 'cricket',
                              subcategory: sub,
                            });
                            setMoreMenuOpen(false);
                          }}
                          className="hover:text-[#D32F2F] cursor-pointer"
                        >
                          → {sub}
                        </button>
                      </li>
                    )
                  )}
                </ul>
              </div>

              <div className="bg-[#F9FAFB] p-4 border border-[#E5E7EB] flex flex-col justify-between">
                <div>
                  <span className="text-[11px] font-bold uppercase text-[#D32F2F]">
                    নিউজরুম সিএমএস
                  </span>
                  <h5 className="font-editorial font-bold text-base text-[#111827] mt-1">
                    bd7news.com অ্যাডমিন ড্যাশবোর্ড
                  </h5>
                  <p className="text-xs text-[#6B7280] mt-1">
                    নতুন সংবাদ প্রকাশ, ব্রেকিং নিউজ টিকার, হোমপেজ নিয়ন্ত্রণ ও বিজ্ঞাপন ব্যবস্থাপনা করুন।
                  </p>
                </div>
                <button
                  onClick={() => {
                    navigateTo({ type: 'admin', tab: 'dashboard' });
                    setMoreMenuOpen(false);
                  }}
                  className="mt-3 w-full bg-[#111827] hover:bg-[#D32F2F] text-white text-xs font-semibold py-2 transition-colors cursor-pointer"
                >
                  সিএমএস প্যানেলে প্রবেশ করুন
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Mobile Drawer Navigation */}
      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 lg:hidden flex">
          <div className="bg-white w-80 max-w-[85vw] h-full overflow-y-auto p-5 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#E5E7EB]">
                <div>
                  {siteSettings.logoUrl ? (
                    <img
                      src={siteSettings.logoUrl}
                      alt={siteSettings.siteName}
                      className="h-10 w-auto max-w-[200px] object-contain"
                    />
                  ) : (
                    <span className="font-editorial font-extrabold text-2xl text-[#111827]">
                      bd<span className="text-[#D32F2F]">7</span>news.com
                    </span>
                  )}
                  <p className="text-xs text-[#6B7280] mt-0.5">{siteSettings.taglineBn}</p>
                </div>
                <button
                  onClick={() => setMobileDrawerOpen(false)}
                  className="p-1.5 border border-[#E5E7EB] text-[#111827]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-1">
                {navItems.map((item) => {
                  if (item.key === 'sports') {
                    return (
                      <div key="sports" className="border-b border-[#F3F4F6]">
                        <div className="flex items-center justify-between">
                          <button
                            onClick={() => {
                              navigateTo({ type: 'category', categorySlug: 'sports' });
                              setMobileDrawerOpen(false);
                            }}
                            className="flex-1 text-left px-3 py-2.5 text-sm font-semibold text-[#111827] hover:text-[#D32F2F]"
                          >
                            {item.labelBn}
                          </button>
                          <button
                            onClick={() =>
                              setMobileSportsExpanded(!mobileSportsExpanded)
                            }
                            className="px-3 py-2.5 text-xs font-bold text-[#D32F2F] flex items-center gap-1"
                          >
                            <span>সাব-মেনু</span>
                            <ChevronDown
                              className={`w-4 h-4 transition-transform ${
                                mobileSportsExpanded ? 'rotate-180' : ''
                              }`}
                            />
                          </button>
                        </div>

                        {mobileSportsExpanded && (
                          <div className="bg-[#F9FAFB] pl-6 pr-3 py-1.5 space-y-1 border-t border-[#F3F4F6]">
                            <button
                              onClick={() => {
                                navigateTo({
                                  type: 'category',
                                  categorySlug: 'cricket',
                                });
                                setMobileDrawerOpen(false);
                              }}
                              className="w-full text-left py-2 text-xs sm:text-sm font-bold text-[#047857] hover:text-[#D32F2F] flex items-center justify-between"
                            >
                              <span>• ক্রিকেট (Cricket)</span>
                              <span>→</span>
                            </button>
                            <button
                              onClick={() => {
                                navigateTo({
                                  type: 'category',
                                  categorySlug: 'football',
                                });
                                setMobileDrawerOpen(false);
                              }}
                              className="w-full text-left py-2 text-xs sm:text-sm font-bold text-[#1D4ED8] hover:text-[#D32F2F] flex items-center justify-between"
                            >
                              <span>• ফুটবল (Football)</span>
                              <span>→</span>
                            </button>
                            <button
                              onClick={() => {
                                navigateTo({
                                  type: 'category',
                                  categorySlug: 'sports',
                                });
                                setMobileDrawerOpen(false);
                              }}
                              className="w-full text-left py-2 text-xs font-semibold text-[#4B5563] hover:text-[#D32F2F] flex items-center justify-between"
                            >
                              <span>• সব খেলাধুলা</span>
                              <span>→</span>
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  }

                  return (
                    <button
                      key={item.key}
                      onClick={() => {
                        item.action();
                        setMobileDrawerOpen(false);
                      }}
                      className="w-full text-left px-3 py-2.5 text-sm font-semibold text-[#111827] hover:bg-[#F9FAFB] hover:text-[#D32F2F] border-b border-[#F3F4F6] flex items-center justify-between"
                    >
                      <span>{item.labelBn}</span>
                      <span className="text-xs text-[#9CA3AF]">→</span>
                    </button>
                  );
                })}
                <button
                  onClick={() => {
                    navigateTo({ type: 'photo-gallery' });
                    setMobileDrawerOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 text-sm font-semibold text-[#111827] hover:bg-[#F9FAFB] hover:text-[#D32F2F] border-b border-[#F3F4F6]"
                >
                  ছবিতে আজ
                </button>
                <button
                  onClick={() => {
                    navigateTo({ type: 'category', categorySlug: 'opinion' });
                    setMobileDrawerOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 text-sm font-semibold text-[#111827] hover:bg-[#F9FAFB] hover:text-[#D32F2F] border-b border-[#F3F4F6]"
                >
                  মতামত
                </button>
                <button
                  onClick={() => {
                    navigateTo({ type: 'category', categorySlug: 'special-report' });
                    setMobileDrawerOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 text-sm font-semibold text-[#111827] hover:bg-[#F9FAFB] hover:text-[#D32F2F] border-b border-[#F3F4F6]"
                >
                  বিশেষ প্রতিবেদন
                </button>
              </div>
            </div>

            <div className="pt-4 border-t border-[#E5E7EB] mt-6">
              <button
                onClick={() => {
                  navigateTo({ type: 'admin', tab: 'dashboard' });
                  setMobileDrawerOpen(false);
                }}
                className="w-full bg-[#111827] text-white py-2.5 text-sm font-semibold flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" /> অ্যাডমিন ড্যাশবোর্ড
              </button>
            </div>
          </div>
          <div className="flex-1" onClick={() => setMobileDrawerOpen(false)} />
        </div>
      )}
    </header>
  );
};
