import React, { useState } from 'react';
import {
  ExternalLink,
  X,
  CheckCircle2,
  MousePointerClick,
  ArrowRight,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { AdPlacementSlot } from '../types/news';
import { useNews } from '../context/NewsContext';

interface AdSlotProps {
  slot: AdPlacementSlot;
  className?: string;
  instanceKey?: string;
}

const MULTIPLEX_ITEMS = [
  {
    id: 'mp-1',
    brand: 'গ্রামীণফোন ফাইবার হোম',
    title: 'বিনা খরচে রাউটার ও ইনস্টলেশনসহ আনলিমিটেড হাই-স্পিড ইন্টারনেট সংযোগ',
    tag: 'ইন্টারনেট অফার',
    cta: 'প্যাকেজ দেখুন',
    image:
      'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=500&q=80',
  },
  {
    id: 'mp-2',
    brand: 'বিকাশ পেমেন্ট রিওয়ার্ডস',
    title: 'সুপারশপ ও রেস্টুরেন্টে কিউআর পেমেন্ট করলেই সর্বোচ্চ ৫০০ টাকা তাৎক্ষণিক ক্যাশব্যাক',
    tag: 'ক্যাশব্যাক',
    cta: 'অফার নিন',
    image:
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=500&q=80',
  },
  {
    id: 'mp-3',
    brand: 'পূর্বাচল রয়্যাল সিটি',
    title: 'রাজউক পূর্বাচল সংলগ্ন রেডি প্লটে ৬০ মাসের সহজ কিস্তিতে বিনিয়োগের সুবর্ণ সুযোগ',
    tag: 'রিয়েল এস্টেট',
    cta: 'ব্রশিউর নিন',
    image:
      'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=500&q=80',
  },
  {
    id: 'mp-4',
    brand: 'ল্যাবএইড কার্ডিয়াক চেকআপ',
    title: 'সিনিয়র সিটিজেন ও পরিবারের সবার জন্য কমপ্লিট হেলথ স্ক্রিনিং প্যাকেজে ৩৫% ছাড়',
    tag: 'স্বাস্থ্যসেবা',
    cta: 'বুকিং দিন',
    image:
      'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=500&q=80',
  },
];

export const AdSlot: React.FC<AdSlotProps> = ({
  slot,
  className = '',
  instanceKey,
}) => {
  const {
    getActiveAdForSlot,
    recordAdClick,
    dismissedAdSlots,
    dismissAdSlot,
  } = useNews();

  const ad = getActiveAdForSlot(slot);
  const slotDismissKey = instanceKey ? `${slot}-${instanceKey}` : slot;

  const [isClosed, setIsClosed] = useState(false);
  const [isClicked, setIsClicked] = useState(false);
  const [dismissedMultiplexCards, setDismissedMultiplexCards] = useState<
    string[]
  >([]);

  if (!ad) return null;

  const isGloballyDismissed = dismissedAdSlots.includes(slotDismissKey);

  // Device responsiveness classes based on ad.device
  const deviceVisibilityClass =
    ad.device === 'desktop'
      ? 'hidden md:block'
      : ad.device === 'mobile'
      ? 'block md:hidden'
      : 'block';

  // Immediately close/hide the ad without showing any feedback text box
  const handleCloseAd = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsClosed(true);
    dismissAdSlot(slotDismissKey);
  };

  const handleAdClick = (
    e: React.MouseEvent,
    customHeadline?: string,
    customBrand?: string
  ) => {
    e.stopPropagation();
    setIsClicked(true);
    if (customHeadline || customBrand) {
      recordAdClick({
        ...ad,
        sponsorBrandBn: customBrand || ad.sponsorBrandBn,
        sponsorHeadlineBn: customHeadline || ad.sponsorHeadlineBn,
      });
    } else {
      recordAdClick(ad);
    }
  };

  if (isClosed || isGloballyDismissed) {
    return null;
  }

  // Clean, minimal top bar with only a subtle "বিজ্ঞাপন" label and immediate Close (✕) button
  const renderCleanCloseBar = () => (
    <div className="flex items-center justify-between mb-2 pb-1 border-b border-[#E5E7EB] text-[11px] text-[#6B7280]">
      <span className="font-semibold text-[#6B7280]">বিজ্ঞাপন</span>
      <button
        type="button"
        onClick={handleCloseAd}
        className="px-2 py-0.5 bg-white hover:bg-[#D32F2F] text-[#4B5563] hover:text-white border border-[#D1D5DB] hover:border-[#D32F2F] text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
        title="বিজ্ঞাপন বন্ধ করুন"
      >
        <X className="w-3 h-3" />
        <span>বন্ধ করুন</span>
      </button>
    </div>
  );

  // ============================================================================
  // 1. IN-FEED NATIVE AD
  // ============================================================================
  if (slot === 'in-feed') {
    return (
      <div
        className={`${deviceVisibilityClass} bg-[#FFFBEB]/70 hover:bg-[#FFFBEB] border border-[#FDE68A] hover:border-[#111827] p-3.5 rounded-[2px] transition-all ${className}`}
      >
        {renderCleanCloseBar()}

        {ad.adCode.trim() ? (
          <div
            className="w-full overflow-hidden text-xs"
            dangerouslySetInnerHTML={{ __html: ad.adCode }}
          />
        ) : (
          <div
            onClick={handleAdClick}
            className="group cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
          >
            {ad.sponsorBgImage && (
              <div className="w-full sm:w-40 aspect-16/10 shrink-0 overflow-hidden bg-[#F3F4F6] border border-[#E5E7EB] relative">
                <img
                  src={ad.sponsorBgImage}
                  alt={ad.sponsorBrandBn}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <span className="absolute top-1.5 left-1.5 bg-[#111827]/85 text-[#FFE600] text-[10px] font-bold px-1.5 py-0.5">
                  স্পন্সরড
                </span>
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 text-xs mb-1">
                <span className="font-extrabold text-[#D32F2F]">
                  {ad.sponsorBrandBn}
                </span>
              </div>
              <h4 className="font-editorial font-bold text-base sm:text-lg text-[#111827] group-hover:text-[#D32F2F] leading-snug mb-1 transition-colors">
                {ad.sponsorHeadlineBn}
              </h4>
              <p className="text-xs text-[#4B5563] line-clamp-2 mb-2.5">
                {ad.sponsorSubtextBn}
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleAdClick}
                  className="inline-flex items-center gap-1.5 bg-[#111827] group-hover:bg-[#D32F2F] text-white text-xs font-bold px-3.5 py-1.5 transition-colors cursor-pointer"
                >
                  {isClicked ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#FFE600]" />
                  ) : (
                    <MousePointerClick className="w-3.5 h-3.5" />
                  )}
                  <span>{ad.sponsorCtaBn}</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ============================================================================
  // 2. MULTIPLEX AD GRID
  // ============================================================================
  if (slot === 'multiplex-ad') {
    const visibleCards = MULTIPLEX_ITEMS.filter(
      (item) => !dismissedMultiplexCards.includes(item.id)
    );
    if (visibleCards.length === 0) return null;

    return (
      <div
        className={`${deviceVisibilityClass} my-6 bg-[#F9FAFB] border border-[#E5E7EB] p-4 rounded-[2px] ${className}`}
      >
        {renderCleanCloseBar()}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {visibleCards.map((item) => (
            <div
              key={item.id}
              onClick={(e) => handleAdClick(e, item.title, item.brand)}
              className="group cursor-pointer bg-white border border-[#E5E7EB] hover:border-[#111827] flex flex-col justify-between overflow-hidden relative transition-all"
            >
              {/* Per-card dismiss button */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setDismissedMultiplexCards((prev) => [...prev, item.id]);
                }}
                className="absolute top-2 right-2 z-10 bg-black/75 hover:bg-[#D32F2F] text-white p-1 transition-colors cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-3 h-3" />
              </button>

              <div>
                <div className="aspect-16/10 w-full overflow-hidden bg-[#F3F4F6] relative">
                  <img
                    src={item.image}
                    alt={item.brand}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <span className="absolute bottom-1.5 left-1.5 bg-[#111827]/90 text-white text-[10px] font-bold px-1.5 py-0.5">
                    {item.tag}
                  </span>
                </div>
                <div className="p-3">
                  <div className="text-[11px] font-bold text-[#D32F2F] mb-1 truncate">
                    {item.brand}
                  </div>
                  <h5 className="font-editorial font-bold text-sm text-[#111827] group-hover:text-[#D32F2F] leading-snug line-clamp-2">
                    {item.title}
                  </h5>
                </div>
              </div>

              <div className="px-3 pb-3 pt-1 flex items-center justify-between border-t border-dashed border-[#E5E7EB]">
                <span className="text-[10px] text-[#6B7280]">স্পন্সরড</span>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#111827] group-hover:text-[#D32F2F]">
                  {item.cta} <ExternalLink className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ============================================================================
  // 3. SIDEBAR AD LAYOUT
  // ============================================================================
  if (slot === 'sidebar-ad') {
    return (
      <div
        className={`${deviceVisibilityClass} bg-[#F9FAFB] border border-[#E5E7EB] p-3.5 rounded-[2px] ${className}`}
      >
        {renderCleanCloseBar()}

        {ad.adCode.trim() ? (
          <div
            className="w-full overflow-hidden text-xs"
            dangerouslySetInnerHTML={{ __html: ad.adCode }}
          />
        ) : (
          <div
            onClick={handleAdClick}
            className="bg-white border border-[#E5E7EB] hover:border-[#111827] p-4 flex flex-col justify-between min-h-[200px] relative overflow-hidden group cursor-pointer transition-colors"
          >
            <div className="absolute top-0 left-0 w-1 h-full bg-[#D32F2F]" />
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="inline-block text-[11px] font-semibold text-[#D32F2F] bg-red-50 px-2 py-0.5 border border-red-100">
                  {ad.sponsorBrandBn}
                </span>
                <span className="text-[10px] text-[#6B7280]">স্পন্সরড</span>
              </div>
              <h4 className="font-editorial font-bold text-base text-[#111827] leading-snug mb-2 group-hover:text-[#D32F2F] transition-colors">
                {ad.sponsorHeadlineBn}
              </h4>
              <p className="text-xs text-[#4B5563] leading-relaxed">
                {ad.sponsorSubtextBn}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-[#E5E7EB] flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={handleAdClick}
                className="flex-1 inline-flex items-center justify-center gap-1.5 text-xs font-bold text-white bg-[#111827] group-hover:bg-[#D32F2F] px-3 py-2 transition-colors cursor-pointer"
              >
                {isClicked ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#FFE600]" />
                ) : (
                  <MousePointerClick className="w-3.5 h-3.5" />
                )}
                <span>{ad.sponsorCtaBn}</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ============================================================================
  // 4. HEADER COMPACT AD
  // ============================================================================
  if (slot === 'header-ad') {
    return (
      <div
        className={`${deviceVisibilityClass} bg-[#F9FAFB] border border-[#E5E7EB] px-3 py-2 rounded-[2px] max-w-md relative ${className}`}
      >
        <div
          onClick={handleAdClick}
          className="flex items-center justify-between gap-3 cursor-pointer group"
        >
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 mb-0.5">
              <span className="text-[11px] font-bold text-[#D32F2F] truncate">
                {ad.sponsorBrandBn}
              </span>
            </div>
            <p className="text-xs font-medium text-[#111827] group-hover:text-[#D32F2F] line-clamp-1 transition-colors">
              {ad.sponsorHeadlineBn}
            </p>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <span className="text-[11px] font-semibold bg-[#111827] group-hover:bg-[#D32F2F] text-white px-2.5 py-1 transition-colors">
              {ad.sponsorCtaBn}
            </span>
            <button
              type="button"
              onClick={handleCloseAd}
              className="p-1 text-[#6B7280] hover:text-[#D32F2F] bg-white border border-[#E5E7EB] cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // 5. HORIZONTAL LEADERBOARD / BANNER / IN-CONTENT / MOBILE BANNER
  // ============================================================================
  return (
    <div className={`${deviceVisibilityClass} my-4 ${className}`}>
      <div className="bg-[#F9FAFB] border border-[#E5E7EB] px-4 py-3 rounded-[2px]">
        {renderCleanCloseBar()}

        {ad.adCode.trim() ? (
          <div
            className="w-full overflow-hidden"
            dangerouslySetInnerHTML={{ __html: ad.adCode }}
          />
        ) : (
          <div
            onClick={handleAdClick}
            className="bg-white border border-[#E5E7EB] hover:border-[#111827] px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative group cursor-pointer transition-colors"
          >
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#D32F2F]" />
            <div className="pl-2">
              <div className="flex flex-wrap items-center gap-2 mb-0.5">
                <span className="text-xs font-bold text-[#D32F2F]">
                  {ad.sponsorBrandBn}
                </span>
                <span className="text-[#E5E7EB]">•</span>
                <span className="text-xs text-[#6B7280]">
                  {ad.sponsorSubtextBn}
                </span>
              </div>
              <p className="font-editorial font-bold text-sm sm:text-base text-[#111827] group-hover:text-[#D32F2F] transition-colors">
                {ad.sponsorHeadlineBn}
              </p>
            </div>
            <div className="shrink-0 pl-2 sm:pl-0 flex items-center gap-2">
              <button
                type="button"
                onClick={handleAdClick}
                className="inline-flex items-center gap-1.5 bg-[#111827] group-hover:bg-[#D32F2F] text-white text-xs font-semibold px-3.5 py-2 transition-colors cursor-pointer"
              >
                {isClicked ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#FFE600]" />
                ) : (
                  <MousePointerClick className="w-3.5 h-3.5" />
                )}
                <span>{ad.sponsorCtaBn}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ==============================================================================
// GLOBAL FLOATING ADS + CLEAN PRE-POST VIGNETTE INTERSTITIAL
// ==============================================================================
export const GlobalFloatingAds: React.FC = () => {
  const {
    articles,
    publishedArticles,
    getActiveAdForSlot,
    recordAdClick,
    dismissedAdSlots,
    dismissAdSlot,
    pendingArticleNavigation,
    confirmPendingArticleNavigation,
  } = useNews();

  const [collapsedStickyBottom, setCollapsedStickyBottom] = useState(false);
  const [collapsedAnchorTop, setCollapsedAnchorTop] = useState(false);
  const [vignetteAdClicked, setVignetteAdClicked] = useState(false);

  const stickyAd = getActiveAdForSlot('sticky-bottom');
  const anchorTopAd = getActiveAdForSlot('anchor-top');
  const sideRailAd = getActiveAdForSlot('side-rail');
  const socialBarAd = getActiveAdForSlot('social-bar');
  const popUnderAd = getActiveAdForSlot('pop-under');
  const vignetteAd =
    getActiveAdForSlot('vignette-interstitial') ||
    getActiveAdForSlot('homepage-banner') ||
    getActiveAdForSlot('top-banner');

  const pendingArticle = pendingArticleNavigation
    ? articles.find((a) => a.id === pendingArticleNavigation) ||
      publishedArticles[0]
    : null;

  return (
    <>
      {/* ==================================================================== */}
      {/* 1. CLEAN PRE-POST VIGNETTE / INTERSTITIAL AD                         */}
      {/* ==================================================================== */}
      {pendingArticle && vignetteAd && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="bg-white border-2 border-[#111827] max-w-lg w-full shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
            {/* Clean Top Bar with Close Button */}
            <div className="bg-[#111827] text-white px-4 py-2 flex items-center justify-between gap-2">
              <span className="text-xs text-gray-200 font-bold">বিজ্ঞাপন</span>

              <button
                type="button"
                onClick={() => {
                  setVignetteAdClicked(false);
                  confirmPendingArticleNavigation();
                }}
                className="inline-flex items-center gap-1 bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold px-3 py-1 transition-colors cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-3.5 h-3.5" />
                <span>বন্ধ করুন</span>
              </button>
            </div>

            {/* Main Clickable Vignette Ad Body */}
            <div className="p-5">
              {vignetteAd.sponsorBgImage && (
                <div
                  onClick={() => {
                    setVignetteAdClicked(true);
                    recordAdClick(vignetteAd);
                  }}
                  className="relative aspect-16/8 w-full overflow-hidden bg-[#111827] border border-[#E5E7EB] mb-4 group cursor-pointer"
                >
                  <img
                    src={vignetteAd.sponsorBgImage}
                    alt={vignetteAd.sponsorBrandBn}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent flex flex-col justify-end p-3.5">
                    <span className="inline-block w-fit bg-[#FFE600] text-[#111827] text-[11px] font-extrabold px-2 py-0.5">
                      {vignetteAd.sponsorBrandBn}
                    </span>
                  </div>
                </div>
              )}

              <div className="mb-4">
                <div className="text-xs font-extrabold text-[#D32F2F] mb-1">
                  {vignetteAd.sponsorBrandBn}
                </div>
                <h3
                  onClick={() => {
                    setVignetteAdClicked(true);
                    recordAdClick(vignetteAd);
                  }}
                  className="font-editorial font-extrabold text-xl text-[#111827] hover:text-[#D32F2F] leading-snug mb-1.5 cursor-pointer transition-colors"
                >
                  {vignetteAd.sponsorHeadlineBn}
                </h3>
                <p className="text-xs sm:text-sm text-[#4B5563] leading-relaxed">
                  {vignetteAd.sponsorSubtextBn}
                </p>
              </div>

              {/* Action Buttons: 1. Click Ad | 2. Close & Read Post */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setVignetteAdClicked(true);
                    recordAdClick(vignetteAd);
                  }}
                  className="w-full bg-[#1A73E8] hover:bg-[#1557B0] text-white font-bold text-xs sm:text-sm py-2.5 px-4 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  {vignetteAdClicked ? (
                    <CheckCircle2 className="w-4 h-4 text-[#FFE600]" />
                  ) : (
                    <MousePointerClick className="w-4 h-4" />
                  )}
                  <span>{vignetteAd.sponsorCtaBn}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setVignetteAdClicked(false);
                    confirmPendingArticleNavigation();
                  }}
                  className="w-full bg-[#111827] hover:bg-[#D32F2F] text-white font-bold text-xs sm:text-sm py-2.5 px-4 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <span>সংবাদটি পড়ুন</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* 2. TOP ANCHOR AD (Only when enabled in Admin)                        */}
      {/* ==================================================================== */}
      {anchorTopAd && !dismissedAdSlots.includes('anchor-top') && (
        <div className="fixed top-0 left-0 right-0 z-40 bg-white/95 backdrop-blur border-b-2 border-[#111827] shadow-md transition-all">
          {!collapsedAnchorTop ? (
            <div className="max-w-[1320px] mx-auto px-3 py-1.5 flex items-center justify-between gap-3">
              <div
                onClick={() => recordAdClick(anchorTopAd)}
                className="flex items-center gap-2.5 min-w-0 cursor-pointer group flex-1"
              >
                <span className="text-xs font-extrabold text-[#D32F2F] shrink-0 hidden sm:inline">
                  {anchorTopAd.sponsorBrandBn}:
                </span>
                <p className="text-xs font-semibold text-[#111827] group-hover:text-[#D32F2F] truncate">
                  {anchorTopAd.sponsorHeadlineBn}
                </p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => recordAdClick(anchorTopAd)}
                  className="text-[11px] font-bold bg-[#111827] hover:bg-[#D32F2F] text-white px-2.5 py-1 cursor-pointer"
                >
                  {anchorTopAd.sponsorCtaBn}
                </button>
                <button
                  type="button"
                  onClick={() => setCollapsedAnchorTop(true)}
                  className="p-1 text-[#6B7280] hover:text-[#111827] border border-[#E5E7EB] cursor-pointer"
                  title="সংকুচিত করুন"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => dismissAdSlot('anchor-top')}
                  className="px-2 py-1 bg-red-50 hover:bg-[#D32F2F] text-[#D32F2F] hover:text-white border border-red-200 text-[10px] font-extrabold flex items-center gap-0.5 cursor-pointer"
                  title="বন্ধ করুন"
                >
                  <X className="w-3 h-3" /> বন্ধ
                </button>
              </div>
            </div>
          ) : (
            <div className="flex justify-center">
              <button
                type="button"
                onClick={() => setCollapsedAnchorTop(false)}
                className="bg-[#111827] text-white text-[10px] font-bold px-3 py-0.5 flex items-center gap-1 cursor-pointer"
              >
                <span>বিজ্ঞাপন দেখুন</span>
                <ChevronDown className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================================================================== */}
      {/* 3. DESKTOP SIDE RAIL STICKY AD (Only when enabled in Admin)          */}
      {/* ==================================================================== */}
      {sideRailAd && !dismissedAdSlots.includes('side-rail') && (
        <div className="hidden 2xl:flex fixed right-3 top-1/2 -translate-y-1/2 z-30 w-40 bg-white border-2 border-[#111827] shadow-xl flex-col overflow-hidden">
          <div className="bg-[#111827] text-white px-2 py-1 flex items-center justify-between text-[10px]">
            <span className="font-bold text-[#FFE600]">বিজ্ঞাপন</span>
            <button
              type="button"
              onClick={() => dismissAdSlot('side-rail')}
              className="hover:text-[#FCA5A5] font-extrabold cursor-pointer"
              title="বন্ধ করুন"
            >
              ✕ বন্ধ
            </button>
          </div>
          <div
            onClick={() => recordAdClick(sideRailAd)}
            className="p-3 cursor-pointer group flex flex-col justify-between gap-3"
          >
            <div>
              <span className="inline-block text-[10px] font-extrabold text-[#D32F2F] bg-red-50 px-1.5 py-0.5 border border-red-200 mb-1.5">
                {sideRailAd.sponsorBrandBn}
              </span>
              <h5 className="font-editorial font-bold text-xs text-[#111827] group-hover:text-[#D32F2F] leading-snug mb-1.5">
                {sideRailAd.sponsorHeadlineBn}
              </h5>
              <p className="text-[11px] text-[#6B7280] leading-tight">
                {sideRailAd.sponsorSubtextBn}
              </p>
            </div>
            <button
              type="button"
              className="w-full bg-[#111827] group-hover:bg-[#D32F2F] text-white text-[11px] font-bold py-1.5 cursor-pointer"
            >
              {sideRailAd.sponsorCtaBn} →
            </button>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* 4. STICKY BOTTOM ANCHOR AD                                           */}
      {/* ==================================================================== */}
      {stickyAd && !dismissedAdSlots.includes('sticky-bottom') && (
        <div className="fixed bottom-14 md:bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur border-t-2 border-[#111827] shadow-lg">
          {!collapsedStickyBottom ? (
            <div className="max-w-[1320px] mx-auto px-4 py-2 flex items-center justify-between gap-4">
              <div
                onClick={() => recordAdClick(stickyAd)}
                className="flex items-center gap-3 min-w-0 cursor-pointer group flex-1"
              >
                <span className="text-xs font-bold text-[#D32F2F] shrink-0 hidden sm:inline">
                  {stickyAd.sponsorBrandBn}:
                </span>
                <p className="text-xs sm:text-sm font-medium text-[#111827] group-hover:text-[#D32F2F] truncate">
                  {stickyAd.sponsorHeadlineBn}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => recordAdClick(stickyAd)}
                  className="text-xs font-semibold bg-[#D32F2F] hover:bg-[#B71C1C] text-white px-3 py-1 cursor-pointer flex items-center gap-1"
                >
                  <MousePointerClick className="w-3.5 h-3.5" />
                  <span>{stickyAd.sponsorCtaBn}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCollapsedStickyBottom(true)}
                  className="p-1 text-[#6B7280] hover:text-[#111827] border border-[#E5E7EB] cursor-pointer"
                  title="সংকুচিত করুন"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => dismissAdSlot('sticky-bottom')}
                  className="px-2 py-1 bg-gray-100 hover:bg-[#D32F2F] text-[#111827] hover:text-white border border-[#D1D5DB] text-xs font-bold flex items-center gap-1 cursor-pointer"
                  title="বন্ধ করুন"
                >
                  <X className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">বন্ধ করুন</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex justify-center">
              <button
                type="button"
                onClick={() => setCollapsedStickyBottom(false)}
                className="bg-[#111827] text-white text-[11px] font-bold px-3 py-1 flex items-center gap-1 cursor-pointer"
              >
                <ChevronUp className="w-3.5 h-3.5" />
                <span>বিজ্ঞাপন দেখুন</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==================================================================== */}
      {/* 5. SOCIAL BAR FLOATING NOTIFICATION AD (Only when enabled in Admin)  */}
      {/* ==================================================================== */}
      {socialBarAd && !dismissedAdSlots.includes('social-bar') && (
        <div className="fixed bottom-20 right-4 z-40 max-w-xs bg-white border-2 border-[#111827] shadow-xl p-3 rounded-[2px]">
          <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-[#E5E7EB]">
            <span className="text-[10px] font-bold text-[#6B7280]">
              স্পন্সরড
            </span>
            <button
              type="button"
              onClick={() => dismissAdSlot('social-bar')}
              className="px-1.5 py-0.5 bg-gray-100 hover:bg-[#D32F2F] text-[#111827] hover:text-white text-[10px] font-bold flex items-center gap-0.5 cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-3 h-3" /> বন্ধ
            </button>
          </div>
          <div
            onClick={() => recordAdClick(socialBarAd)}
            className="cursor-pointer group"
          >
            <p className="text-xs font-bold text-[#111827] group-hover:text-[#D32F2F] mb-1">
              {socialBarAd.sponsorBrandBn}
            </p>
            <p className="text-xs text-[#4B5563] mb-2">
              {socialBarAd.sponsorHeadlineBn}
            </p>
            <span className="inline-flex items-center justify-center gap-1 w-full text-center text-xs font-semibold bg-[#111827] group-hover:bg-[#D32F2F] text-white py-1.5 transition-colors">
              <MousePointerClick className="w-3.5 h-3.5" />
              <span>{socialBarAd.sponsorCtaBn}</span>
            </span>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* 6. POP-UNDER / INTERSTITIAL PROMO BANNER (Only when enabled in Admin)*/}
      {/* ==================================================================== */}
      {popUnderAd && !dismissedAdSlots.includes('pop-under') && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white border-2 border-[#111827] max-w-md w-full p-6 relative shadow-2xl">
            <button
              type="button"
              onClick={() => dismissAdSlot('pop-under')}
              className="absolute top-3 right-3 px-2 py-1 text-xs font-bold text-[#111827] hover:bg-[#D32F2F] hover:text-white border border-[#E5E7EB] flex items-center gap-1 cursor-pointer"
            >
              <X className="w-4 h-4" /> বন্ধ করুন
            </button>
            <div className="text-xs font-bold text-[#D32F2F] mb-1">
              {popUnderAd.sponsorBrandBn}
            </div>
            <h3 className="font-editorial font-bold text-xl text-[#111827] mb-2">
              {popUnderAd.sponsorHeadlineBn}
            </h3>
            <p className="text-sm text-[#4B5563] mb-5">
              {popUnderAd.sponsorSubtextBn}
            </p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  recordAdClick(popUnderAd);
                  dismissAdSlot('pop-under');
                }}
                className="flex-1 bg-[#D32F2F] text-white font-semibold text-sm py-2.5 cursor-pointer"
              >
                {popUnderAd.sponsorCtaBn}
              </button>
              <button
                type="button"
                onClick={() => dismissAdSlot('pop-under')}
                className="px-4 py-2.5 border border-[#E5E7EB] text-sm text-[#4B5563] cursor-pointer"
              >
                এড়িয়ে যান
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
