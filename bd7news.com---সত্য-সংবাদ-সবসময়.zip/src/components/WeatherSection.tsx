import React, { useState } from 'react';
import {
  CloudRain,
  CloudSun,
  CloudLightning,
  Sun,
  Wind,
  Droplets,
  AlertTriangle,
  Compass,
  Thermometer,
  Clock,
  ChevronRight,
  Waves,
} from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';
import { NewsCard, MostReadWidget, SectionHeader } from './NewsCard';
import { AdSlot } from './AdSlot';

export interface DivisionWeatherInfo {
  id: string;
  divisionBn: string;
  tempC: number;
  feelsLikeC: number;
  highC: number;
  lowC: number;
  conditionBn: string;
  rainChance: number;
  humidity: number;
  windSpeedKm: number;
  windDirBn: string;
  iconType: 'rain' | 'storm' | 'partly-cloudy' | 'sunny';
  alertBn?: string;
  forecast3Days: { dayBn: string; tempBn: string; condBn: string }[];
}

export const BD_DIVISION_WEATHER: DivisionWeatherInfo[] = [
  {
    id: 'dhaka',
    divisionBn: 'ঢাকা',
    tempC: 30,
    feelsLikeC: 34,
    highC: 32,
    lowC: 26,
    conditionBn: 'আংশিক মেঘলা ও হালকা বৃষ্টির সম্ভাবনা',
    rainChance: 65,
    humidity: 78,
    windSpeedKm: 14,
    windDirBn: 'দক্ষিণ/দক্ষিণ-পূর্ব',
    iconType: 'partly-cloudy',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '৩১° / ২৫°', condBn: 'অস্থায়ী দমকা হাওয়াসহ বৃষ্টি' },
      { dayBn: 'সোমবার', tempBn: '৩০° / ২৫°', condBn: 'মাঝারি ধরনের বৃষ্টিপাত' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩২° / ২৬°', condBn: 'আংশিক মেঘলা আকাশ' },
    ],
  },
  {
    id: 'chattogram',
    divisionBn: 'চট্টগ্রাম',
    tempC: 28,
    feelsLikeC: 32,
    highC: 29,
    lowC: 25,
    conditionBn: 'মাঝারি থেকে ভারী বর্ষণ ও দমকা হাওয়া',
    rainChance: 90,
    humidity: 88,
    windSpeedKm: 28,
    windDirBn: 'দক্ষিণ-পূর্ব',
    iconType: 'storm',
    alertBn: 'চট্টগ্রাম ও কক্সবাজার সমুদ্রবন্দরে ৩ নম্বর স্থানীয় সতর্ক সংকেত; পাহাড়ি এলাকায় ভূমিধসের সতর্কতা।',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '২৮° / ২৪°', condBn: 'ভারী বর্ষণের সম্ভাবনা' },
      { dayBn: 'সোমবার', tempBn: '২৯° / ২৫°', condBn: 'বজ্রসহ মাঝারি বৃষ্টি' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩১° / ২৫°', condBn: 'হালকা থেকে মাঝারি বৃষ্টি' },
    ],
  },
  {
    id: 'sylhet',
    divisionBn: 'সিলেট',
    tempC: 27,
    feelsLikeC: 31,
    highC: 29,
    lowC: 24,
    conditionBn: 'বজ্রসহ মাঝারি থেকে ভারী বৃষ্টিপাত',
    rainChance: 85,
    humidity: 86,
    windSpeedKm: 18,
    windDirBn: 'পূর্ব/দক্ষিণ-পূর্ব',
    iconType: 'rain',
    alertBn: 'সুরমা ও কুশিয়ারা নদীর পানি কয়েকটি পয়েন্টে বৃদ্ধি পাচ্ছে।',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '২৮° / ২৪°', condBn: 'মাঝারি থেকে ভারী বৃষ্টি' },
      { dayBn: 'সোমবার', tempBn: '২৯° / ২৪°', condBn: 'থেমে থেমে বৃষ্টিপাত' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩০° / ২৫°', condBn: 'মেঘলা আকাশ' },
    ],
  },
  {
    id: 'khulna',
    divisionBn: 'খুলনা',
    tempC: 29,
    feelsLikeC: 33,
    highC: 31,
    lowC: 26,
    conditionBn: 'দমকা হাওয়াসহ হালকা থেকে মাঝারি বৃষ্টি',
    rainChance: 80,
    humidity: 84,
    windSpeedKm: 24,
    windDirBn: 'দক্ষিণ',
    iconType: 'rain',
    alertBn: 'মোংলা সমুদ্রবন্দরে ৩ নম্বর স্থানীয় সতর্ক সংকেত বলবৎ।',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '২৯° / ২৫°', condBn: 'মাঝারি ধরনের বর্ষণ' },
      { dayBn: 'সোমবার', tempBn: '৩১° / ২৬°', condBn: 'হালকা বৃষ্টির সম্ভাবনা' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩২° / ২৬°', condBn: 'আংশিক মেঘলা' },
    ],
  },
  {
    id: 'barishal',
    divisionBn: 'বরিশাল',
    tempC: 28,
    feelsLikeC: 32,
    highC: 30,
    lowC: 25,
    conditionBn: 'মেঘলা আকাশ ও মাঝারি থেকে ভারী বৃষ্টি',
    rainChance: 88,
    humidity: 87,
    windSpeedKm: 26,
    windDirBn: 'দক্ষিণ/দক্ষিণ-পূর্ব',
    iconType: 'storm',
    alertBn: 'পায়রা সমুদ্রবন্দরে ৩ নম্বর স্থানীয় সতর্ক সংকেত; উপকূলীয় নদ-নদীতে স্বাভাবিকের চেয়ে ২ ফুট অধিক জোয়ার।',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '২৮° / ২৫°', condBn: 'ভারী বৃষ্টিপাত ও দমকা হাওয়া' },
      { dayBn: 'সোমবার', tempBn: '৩০° / ২৫°', condBn: 'মাঝারি বৃষ্টি' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩১° / ২৬°', condBn: 'আংশিক মেঘলা' },
    ],
  },
  {
    id: 'rajshahi',
    divisionBn: 'রাজশাহী',
    tempC: 33,
    feelsLikeC: 36,
    highC: 34,
    lowC: 27,
    conditionBn: 'রৌদ্রোজ্জ্বল ও আংশিক মেঘলা আকাশ',
    rainChance: 35,
    humidity: 68,
    windSpeedKm: 12,
    windDirBn: 'দক্ষিণ-পশ্চিম',
    iconType: 'sunny',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '৩৩° / ২৬°', condBn: 'বিচ্ছিন্নভাবে হালকা বৃষ্টি' },
      { dayBn: 'সোমবার', tempBn: '৩২° / ২৬°', condBn: 'আংশিক মেঘলা' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩৩° / ২৭°', condBn: 'রৌদ্রোজ্জ্বল' },
    ],
  },
  {
    id: 'rangpur',
    divisionBn: 'রংপুর',
    tempC: 31,
    feelsLikeC: 34,
    highC: 32,
    lowC: 25,
    conditionBn: 'আংশিক মেঘলা, বিকেলে হালকা বৃষ্টির সম্ভাবনা',
    rainChance: 50,
    humidity: 74,
    windSpeedKm: 15,
    windDirBn: 'পূর্ব',
    iconType: 'partly-cloudy',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '৩১° / ২৫°', condBn: 'হালকা থেকে মাঝারি বৃষ্টি' },
      { dayBn: 'সোমবার', tempBn: '৩০° / ২৪°', condBn: 'বজ্রসহ বৃষ্টি' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩২° / ২৫°', condBn: 'আংশিক মেঘলা' },
    ],
  },
  {
    id: 'mymensingh',
    divisionBn: 'ময়মনসিংহ',
    tempC: 29,
    feelsLikeC: 33,
    highC: 31,
    lowC: 25,
    conditionBn: 'মেঘলা আকাশ ও হালকা থেকে মাঝারি বৃষ্টি',
    rainChance: 70,
    humidity: 81,
    windSpeedKm: 16,
    windDirBn: 'দক্ষিণ-পূর্ব',
    iconType: 'rain',
    forecast3Days: [
      { dayBn: 'আগামীকাল', tempBn: '৩০° / ২৫°', condBn: 'মাঝারি বৃষ্টিপাত' },
      { dayBn: 'সোমবার', tempBn: '৩০° / ২৪°', condBn: 'হালকা বৃষ্টি' },
      { dayBn: 'মঙ্গলবার', tempBn: '৩১° / ২৫°', condBn: 'আংশিক মেঘলা' },
    ],
  },
];

export const WeatherIcon: React.FC<{
  type: DivisionWeatherInfo['iconType'];
  className?: string;
}> = ({ type, className = 'w-8 h-8' }) => {
  if (type === 'storm')
    return <CloudLightning className={`${className} text-amber-500`} />;
  if (type === 'rain')
    return <CloudRain className={`${className} text-sky-600`} />;
  if (type === 'sunny')
    return <Sun className={`${className} text-amber-500`} />;
  return <CloudSun className={`${className} text-sky-600`} />;
};

// ============================================================================
// 1. HOMEPAGE WEATHER SECTION ("আবহাওয়ার খবর ও লাইভ পূর্বাভাস")
// ============================================================================
export const WeatherHomepageSection: React.FC = () => {
  const { publishedArticles, navigateTo } = useNews();
  const [selectedDivId, setSelectedDivId] = useState<string>('dhaka');

  const activeWeather =
    BD_DIVISION_WEATHER.find((w) => w.id === selectedDivId) ||
    BD_DIVISION_WEATHER[0];

  const weatherArticles = publishedArticles.filter(
    (a) =>
      a.category === 'weather' ||
      a.subcategory === 'পরিবেশ ও জলবায়ু' ||
      a.tags.includes('আবহাওয়া')
  );

  return (
    <section className="mb-12 bg-[#F8FAFC] border-y-2 border-[#111827] p-5 sm:p-6 rounded-[2px]">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 mb-5 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-2.5">
          <span className="w-3 h-7 bg-[#0284C7] inline-block shrink-0" />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-[#111827]">
                আবহাওয়ার খবর ও পূর্বাভাস
              </h2>
              <span className="bg-[#FEF2F2] text-[#D32F2F] border border-[#FECACA] text-[11px] font-bold px-2 py-0.5 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> সমুদ্রবন্দরে ৩ নম্বর সংকেত
              </span>
            </div>
            <p className="text-xs text-[#6B7280] mt-0.5">
              আবহাওয়া অধিদপ্তরের সর্বশেষ বুলেটিন, ৮ বিভাগের তাপমাত্রা ও বৃষ্টিপাতের পূর্বাভাস
            </p>
          </div>
        </div>

        <button
          onClick={() => navigateTo({ type: 'weather' })}
          className="inline-flex items-center gap-1 text-xs sm:text-sm font-bold text-[#D32F2F] hover:text-[#111827] cursor-pointer self-start md:self-auto"
        >
          <span>আবহাওয়ার পূর্ণাঙ্গ পাতা</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 5 Cols: Interactive 8-Division Live Weather Board */}
        <div className="lg:col-span-5 bg-white border border-[#E5E7EB] p-4 sm:p-5 rounded-[2px] flex flex-col justify-between">
          <div>
            {/* Division Selector Pills */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-[#111827] flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-[#0284C7]" /> বিভাগওয়ারী আবহাওয়া:
              </span>
              <span className="text-[11px] text-[#6B7280]">লাইভ আপডেট</span>
            </div>

            <div className="flex flex-wrap gap-1.5 mb-4 pb-3 border-b border-[#E5E7EB]">
              {BD_DIVISION_WEATHER.map((w) => (
                <button
                  key={w.id}
                  onClick={() => setSelectedDivId(w.id)}
                  className={`px-2.5 py-1 text-xs font-bold border transition-colors cursor-pointer ${
                    selectedDivId === w.id
                      ? 'bg-[#0284C7] text-white border-[#0284C7]'
                      : 'bg-[#F9FAFB] text-[#374151] border-[#E5E7EB] hover:border-[#111827]'
                  }`}
                >
                  {w.divisionBn} ({toBengaliNumber(w.tempC)}°সে)
                </button>
              ))}
            </div>

            {/* Active Division Weather Details */}
            <div className="flex items-center justify-between gap-4 bg-[#F0F9FF] border border-[#BAE6FD] p-4 mb-4">
              <div>
                <span className="text-xs font-bold text-[#0369A1] uppercase">
                  {activeWeather.divisionBn} বিভাগ
                </span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="font-editorial font-extrabold text-3xl sm:text-4xl text-[#111827]">
                    {toBengaliNumber(activeWeather.tempC)}°সে
                  </span>
                  <span className="text-xs text-[#4B5563]">
                    (অনুভূত {toBengaliNumber(activeWeather.feelsLikeC)}°সে)
                  </span>
                </div>
                <p className="font-editorial font-bold text-sm text-[#111827] mt-1">
                  {activeWeather.conditionBn}
                </p>
              </div>
              <div className="shrink-0 bg-white p-3 border border-[#BAE6FD] rounded-full">
                <WeatherIcon type={activeWeather.iconType} className="w-10 h-10" />
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-3 gap-2.5 mb-4 text-center">
              <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-2.5">
                <div className="flex items-center justify-center gap-1 text-[11px] text-[#6B7280]">
                  <CloudRain className="w-3.5 h-3.5 text-[#0284C7]" /> বৃষ্টির সম্ভাবনা
                </div>
                <div className="font-bold text-sm text-[#111827] mt-0.5">
                  {toBengaliNumber(activeWeather.rainChance)}%
                </div>
              </div>
              <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-2.5">
                <div className="flex items-center justify-center gap-1 text-[11px] text-[#6B7280]">
                  <Droplets className="w-3.5 h-3.5 text-[#0284C7]" /> আর্দ্রতা
                </div>
                <div className="font-bold text-sm text-[#111827] mt-0.5">
                  {toBengaliNumber(activeWeather.humidity)}%
                </div>
              </div>
              <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-2.5">
                <div className="flex items-center justify-center gap-1 text-[11px] text-[#6B7280]">
                  <Wind className="w-3.5 h-3.5 text-[#0284C7]" /> বাতাসের গতি
                </div>
                <div className="font-bold text-sm text-[#111827] mt-0.5">
                  {toBengaliNumber(activeWeather.windSpeedKm)} কিমি/ঘণ্টা
                </div>
              </div>
            </div>

            {/* Alert Banner if any */}
            {activeWeather.alertBn && (
              <div className="bg-[#FEF2F2] border-l-4 border-[#D32F2F] p-3 mb-4 text-xs text-[#991B1B] font-medium">
                <strong>সতর্কবার্তা:</strong> {activeWeather.alertBn}
              </div>
            )}

            {/* 3-Day Mini Forecast */}
            <div className="border-t border-[#E5E7EB] pt-3">
              <span className="block text-[11px] font-bold text-[#6B7280] uppercase mb-2">
                আগামী ৩ দিনের পূর্বাভাস ({activeWeather.divisionBn})
              </span>
              <div className="divide-y divide-[#E5E7EB] text-xs">
                {activeWeather.forecast3Days.map((f) => (
                  <div
                    key={f.dayBn}
                    className="py-1.5 flex items-center justify-between"
                  >
                    <span className="font-bold text-[#111827] w-20">
                      {f.dayBn}
                    </span>
                    <span className="text-[#4B5563] flex-1">{f.condBn}</span>
                    <span className="font-mono-num font-bold text-[#0284C7]">
                      {f.tempBn}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={() => navigateTo({ type: 'weather' })}
            className="mt-4 w-full bg-[#111827] hover:bg-[#0284C7] text-white font-editorial font-bold text-xs py-2.5 transition-colors cursor-pointer"
          >
            সকল বিভাগের আবহাওয়া ও সতর্কবার্তা দেখুন →
          </button>
        </div>

        {/* Right 7 Cols: Weather News Stories */}
        <div className="lg:col-span-7 flex flex-col justify-between">
          {weatherArticles[0] && (
            <div className="bg-white border border-[#E5E7EB] p-4 rounded-[2px] mb-5">
              <div
                onClick={() =>
                  navigateTo({ type: 'article', articleId: weatherArticles[0].id })
                }
                className="group cursor-pointer grid grid-cols-1 sm:grid-cols-12 gap-4 items-center"
              >
                <div className="sm:col-span-6 aspect-16/10 overflow-hidden bg-[#F3F4F6]">
                  <img
                    src={weatherArticles[0].featuredImage}
                    alt={weatherArticles[0].headline}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="sm:col-span-6">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="bg-[#0284C7] text-white text-[11px] font-bold px-2 py-0.5">
                      {weatherArticles[0].subcategory || 'আবহাওয়া বুলেটিন'}
                    </span>
                    <span className="text-xs text-[#6B7280]">
                      {weatherArticles[0].timeAgoBn}
                    </span>
                  </div>
                  <h3 className="font-editorial font-bold text-lg sm:text-xl text-[#111827] group-hover:text-[#D32F2F] leading-snug mb-2 transition-colors">
                    {weatherArticles[0].headline}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#4B5563] line-clamp-3 leading-relaxed">
                    {weatherArticles[0].summary}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Secondary Weather News Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {weatherArticles.slice(1, 5).map((art) => (
              <div
                key={art.id}
                onClick={() =>
                  navigateTo({ type: 'article', articleId: art.id })
                }
                className="group cursor-pointer bg-white border border-[#E5E7EB] hover:border-[#111827] p-3.5 flex items-start gap-3 rounded-[2px] transition-colors"
              >
                <img
                  src={art.featuredImage}
                  alt={art.headline}
                  className="w-24 aspect-16/10 object-cover shrink-0 bg-[#F3F4F6] border border-[#E5E7EB]"
                />
                <div className="min-w-0">
                  <span className="text-[11px] font-bold text-[#0284C7]">
                    {art.subcategory || art.categoryNameBn}
                  </span>
                  <h4 className="font-editorial font-bold text-sm text-[#111827] group-hover:text-[#D32F2F] leading-snug line-clamp-2 mt-0.5">
                    {art.headline}
                  </h4>
                  <span className="text-[11px] text-[#6B7280] mt-1 block">
                    {art.timeAgoBn}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// ============================================================================
// 2. DEDICATED FULL PAGE: "আবহাওয়ার খবর ও পূর্বাভাস" (WeatherPage)
// ============================================================================
export const WeatherPage: React.FC = () => {
  const { publishedArticles, navigateTo } = useNews();
  const [selectedSub, setSelectedSub] = useState<string>('ALL');

  const weatherSubcategories = [
    'ALL',
    'আবহাওয়ার পূর্বাভাস',
    'সামুদ্রিক সতর্কবার্তা ও নিম্নচাপ',
    'বৃষ্টিপাত ও নদ-নদীর অবস্থা',
    'তাপমাত্রা ও জলবায়ু',
    'কৃষি আবহাওয়া',
  ];

  const allWeatherArticles = publishedArticles.filter(
    (a) =>
      a.category === 'weather' ||
      a.subcategory === 'পরিবেশ ও জলবায়ু' ||
      a.tags.includes('আবহাওয়া')
  );

  const filteredArticles =
    selectedSub === 'ALL'
      ? allWeatherArticles
      : allWeatherArticles.filter((a) => a.subcategory === selectedSub);

  const displayArticles =
    filteredArticles.length > 0 ? filteredArticles : allWeatherArticles;

  return (
    <div className="max-w-[1320px] mx-auto px-4 py-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-[#6B7280] mb-3">
        <button
          onClick={() => navigateTo({ type: 'home' })}
          className="hover:text-[#D32F2F] cursor-pointer"
        >
          প্রচ্ছদ
        </button>
        <span>/</span>
        <span className="font-bold text-[#0284C7]">আবহাওয়ার খবর</span>
      </div>

      {/* Weather Masthead & Maritime Warning Banner */}
      <div className="bg-white border-2 border-[#111827] p-5 sm:p-6 mb-6 rounded-[2px]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E5E7EB] pb-4 mb-5">
          <div className="flex items-center gap-3">
            <span className="w-3.5 h-9 bg-[#0284C7] inline-block" />
            <div>
              <h1 className="font-editorial font-extrabold text-2xl sm:text-3xl text-[#111827]">
                আবহাওয়ার খবর ও লাইভ পূর্বাভাস
              </h1>
              <p className="text-xs sm:text-sm text-[#6B7280]">
                বাংলাদেশ আবহাওয়া অধিদপ্তরের (BMD) সর্বশেষ বুলেটিন, সমুদ্রবন্দর সংকেত ও ৮ বিভাগের তাপমাত্রা
              </p>
            </div>
          </div>

          <div className="bg-[#FEF2F2] border border-[#FECACA] px-4 py-2 text-xs text-[#991B1B] flex items-center gap-2">
            <Waves className="w-4 h-4 text-[#D32F2F] shrink-0" />
            <span>
              <strong>সামুদ্রিক সতর্কবার্তা:</strong> চট্টগ্রাম, কক্সবাজার, মোংলা ও পায়রা সমুদ্রবন্দরে ৩ নম্বর স্থানীয় সতর্ক সংকেত
            </span>
          </div>
        </div>

        {/* All 8 Divisions Live Weather Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {BD_DIVISION_WEATHER.map((w) => (
            <div
              key={w.id}
              className="bg-[#F8FAFC] border border-[#E2E8F0] p-3 rounded-[2px] flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-editorial font-bold text-sm text-[#111827]">
                    {w.divisionBn}
                  </span>
                  <WeatherIcon type={w.iconType} className="w-5 h-5" />
                </div>
                <div className="font-editorial font-extrabold text-xl text-[#0284C7]">
                  {toBengaliNumber(w.tempC)}°সে
                </div>
                <p className="text-[11px] text-[#4B5563] line-clamp-2 mt-1 leading-snug">
                  {w.conditionBn}
                </p>
              </div>
              <div className="mt-2 pt-2 border-t border-[#E2E8F0] flex items-center justify-between text-[10px] text-[#6B7280]">
                <span>বৃষ্টি: {toBengaliNumber(w.rainChance)}%</span>
                <span>আর্দ্রতা: {toBengaliNumber(w.humidity)}%</span>
              </div>
            </div>
          ))}
        </div>

        {/* Subcategory Filter Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar mt-5 pt-4 border-t border-[#E5E7EB]">
          {weatherSubcategories.map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSub(sub)}
              className={`px-3.5 py-1.5 text-xs font-bold border whitespace-nowrap transition-colors cursor-pointer ${
                selectedSub === sub
                  ? 'bg-[#0284C7] text-white border-[#0284C7]'
                  : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:border-[#111827]'
              }`}
            >
              {sub === 'ALL' ? 'সব আবহাওয়ার খবর' : sub}
            </button>
          ))}
        </div>
      </div>

      {/* Weather News Articles & Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8">
          {displayArticles[0] && (
            <div className="pb-6 mb-6 border-b border-[#E5E7EB]">
              <NewsCard article={displayArticles[0]} variant="hero" />
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-6">
            {displayArticles.slice(1).map((art) => (
              <NewsCard key={art.id} article={art} variant="vertical" />
            ))}
          </div>
        </div>

        <aside className="lg:col-span-4 space-y-6">
          {/* River & Flood Warning Box */}
          <div className="bg-[#F0F9FF] border border-[#BAE6FD] p-4 rounded-[2px]">
            <div className="flex items-center gap-2 border-b border-[#BAE6FD] pb-2 mb-3">
              <Thermometer className="w-4 h-4 text-[#0284C7]" />
              <h3 className="font-editorial font-bold text-base text-[#111827]">
                আবহাওয়া ও নদ-নদীর বিশেষ তথ্য
              </h3>
            </div>
            <ul className="space-y-2.5 text-xs text-[#334155] leading-relaxed">
              <li>
                • <strong>সিনপটিক অবস্থা:</strong> উত্তর-পশ্চিম বঙ্গোপসাগর ও তৎসংলগ্ন এলাকায় একটি সুস্পষ্ট লঘুচাপ অবস্থান করছে।
              </li>
              <li>
                • <strong>সমুদ্রবন্দর সংকেত:</strong> চট্টগ্রাম, কক্সবাজার, মোংলা ও পায়রা সমুদ্রবন্দরকে ৩ নম্বর স্থানীয় সতর্ক সংকেত দেখাতে বলা হয়েছে।
              </li>
              <li>
                • <strong>নদীবন্দর সংকেত:</strong> ঢাকা, ফরিদপুর, খুলনা, বরিশাল, পটুয়াখালী, নোয়াখালী, কুমিল্লা ও চট্টগ্রাম অঞ্চলের নদীবন্দরসমূহকে ১ নম্বর সতর্ক সংকেত।
              </li>
              <li>
                • <strong>সর্বোচ্চ তাপমাত্রা:</strong> রাজশাহী ৩৪.০° সেলসিয়াস | <strong>সর্বনিম্ন:</strong> সিলেট ২৪.০° সেলসিয়াস।
              </li>
            </ul>
          </div>

          <AdSlot slot="sidebar-ad" />
          <MostReadWidget />
        </aside>
      </div>
    </div>
  );
};
