import React, { useState, useEffect } from 'react';
import {
  Moon,
  TrendingUp,
  Vote,
  CheckCircle2,
  Coins,
  MapPin,
} from 'lucide-react';
import { toBengaliNumber } from '../context/NewsContext';

interface PrayerSchedule {
  division: string;
  fajr: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
  sunrise: string;
}

const PRAYER_TIMES_BY_DIVISION: PrayerSchedule[] = [
  {
    division: 'ঢাকা',
    fajr: '৪:৩৪ ভোর',
    sunrise: '৫:৪৮ সকাল',
    dhuhr: '১১:৫৬ দুপুর',
    asr: '৪:১৮ বিকেল',
    maghrib: '৫:৫৪ সন্ধ্যা',
    isha: '৭:০৯ রাত',
  },
  {
    division: 'চট্টগ্রাম',
    fajr: '৪:২৯ ভোর',
    sunrise: '৫:৪৩ সকাল',
    dhuhr: '১১:৫১ দুপুর',
    asr: '৪:১৩ বিকেল',
    maghrib: '৫:৪৯ সন্ধ্যা',
    isha: '৭:০৪ রাত',
  },
  {
    division: 'রাজশাহী',
    fajr: '৪:৪০ ভোর',
    sunrise: '৫:৫৪ সকাল',
    dhuhr: '১২:০২ দুপুর',
    asr: '৪:২৪ বিকেল',
    maghrib: '৬:০০ সন্ধ্যা',
    isha: '৭:১৫ রাত',
  },
  {
    division: 'খুলনা',
    fajr: '৪:৩৮ ভোর',
    sunrise: '৫:৫২ সকাল',
    dhuhr: '১২:০০ দুপুর',
    asr: '৪:২২ বিকেল',
    maghrib: '৫:৫৮ সন্ধ্যা',
    isha: '৭:১৩ রাত',
  },
  {
    division: 'সিলেট',
    fajr: '৪:২৮ ভোর',
    sunrise: '৫:৪২ সকাল',
    dhuhr: '১১:৫০ দুপুর',
    asr: '৪:১২ বিকেল',
    maghrib: '৫:৪৮ সন্ধ্যা',
    isha: '৭:০৩ রাত',
  },
  {
    division: 'বরিশাল',
    fajr: '৪:৩৫ ভোর',
    sunrise: '৫:৪৯ সকাল',
    dhuhr: '১১:৫৭ দুপুর',
    asr: '৪:১৯ বিকেল',
    maghrib: '৫:৫৫ সন্ধ্যা',
    isha: '৭:১০ রাত',
  },
  {
    division: 'রংপুর',
    fajr: '৪:৩৯ ভোর',
    sunrise: '৫:৫৩ সকাল',
    dhuhr: '১২:০১ দুপুর',
    asr: '৪:২৩ বিকেল',
    maghrib: '৫:৫৯ সন্ধ্যা',
    isha: '৭:১৪ রাত',
  },
  {
    division: 'ময়মনসিংহ',
    fajr: '৪:৩৩ ভোর',
    sunrise: '৫:৪৭ সকাল',
    dhuhr: '১১:৫৫ দুপুর',
    asr: '৪:১৭ বিকেল',
    maghrib: '৫:৫৩ সন্ধ্যা',
    isha: '৭:০৮ রাত',
  },
];

const EXCHANGE_RATES = [
  { currency: 'মার্কিন ডলার (USD)', rate: '১২০.৫০ টাকা', change: '+০.২৫' },
  { currency: 'ইউরো (EUR)', rate: '১৩১.৮০ টাকা', change: '+০.৪০' },
  { currency: 'ব্রিটিশ পাউন্ড (GBP)', rate: '১৫৬.২০ টাকা', change: '+০.১৫' },
  { currency: 'সৌদি রিয়াল (SAR)', rate: '৩২.১০ টাকা', change: 'স্থিতিশীল' },
  { currency: 'মালয়েশিয়ান রিঙ্গিত (MYR)', rate: '২৭.৪৫ টাকা', change: '+০.১০' },
  { currency: '২২ ক্যারেট স্বর্ণ (ভরি)', rate: '১,৩৮,৭০০ টাকা', change: 'বাজুস নির্ধারিত' },
];

interface PollOption {
  id: string;
  label: string;
  votes: number;
}

const DEFAULT_POLL_OPTIONS: PollOption[] = [
  { id: 'yes', label: 'হ্যাঁ, পুরোপুরি একমত', votes: 684 },
  { id: 'no', label: 'না, আরও সংস্কার প্রয়োজন', votes: 219 },
  { id: 'neutral', label: 'মন্তব্য নেই', votes: 57 },
];

export const DailyUtilitiesWidget: React.FC = () => {
  const [selectedDiv, setSelectedDiv] = useState<string>('ঢাকা');
  const [pollOptions, setPollOptions] = useState<PollOption[]>(() => {
    try {
      const saved = localStorage.getItem('bd7news_daily_poll_v1');
      return saved ? JSON.parse(saved) : DEFAULT_POLL_OPTIONS;
    } catch {
      return DEFAULT_POLL_OPTIONS;
    }
  });
  const [votedOption, setVotedOption] = useState<string | null>(() => {
    try {
      return localStorage.getItem('bd7news_daily_poll_voted_v1');
    } catch {
      return null;
    }
  });
  const [selectedChoice, setSelectedChoice] = useState<string>('yes');

  useEffect(() => {
    try {
      localStorage.setItem('bd7news_daily_poll_v1', JSON.stringify(pollOptions));
    } catch {}
  }, [pollOptions]);

  const currentPrayer =
    PRAYER_TIMES_BY_DIVISION.find((p) => p.division === selectedDiv) ||
    PRAYER_TIMES_BY_DIVISION[0];

  const totalVotes = pollOptions.reduce((sum, opt) => sum + opt.votes, 0);

  const handleVoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (votedOption) return;
    const updated = pollOptions.map((opt) =>
      opt.id === selectedChoice ? { ...opt, votes: opt.votes + 1 } : opt
    );
    setPollOptions(updated);
    setVotedOption(selectedChoice);
    try {
      localStorage.setItem('bd7news_daily_poll_voted_v1', selectedChoice);
    } catch {}
  };

  return (
    <div className="space-y-6">
      {/* 1. PRAYER TIMES WIDGET (নামাজের সময়সূচি) */}
      <div className="bg-white border border-[#E5E7EB] p-4 rounded-[2px]">
        <div className="flex items-center justify-between border-b-2 border-[#111827] pb-2.5 mb-3">
          <div className="flex items-center gap-2">
            <Moon className="w-4 h-4 text-[#047857]" />
            <h3 className="font-editorial font-bold text-base text-[#111827]">
              নামাজের সময়সূচি
            </h3>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="w-3 h-3 text-[#D32F2F]" />
            <select
              value={selectedDiv}
              onChange={(e) => setSelectedDiv(e.target.value)}
              aria-label="বিভাগ নির্বাচন করুন"
              className="text-xs font-bold text-[#111827] bg-[#F9FAFB] border border-[#D1D5DB] px-2 py-0.5 outline-none cursor-pointer"
            >
              {PRAYER_TIMES_BY_DIVISION.map((p) => (
                <option key={p.division} value={p.division}>
                  {p.division}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {[
            { name: 'ফজর', time: currentPrayer.fajr },
            { name: 'জোহর', time: currentPrayer.dhuhr },
            { name: 'আসর', time: currentPrayer.asr },
            { name: 'মাগরিব', time: currentPrayer.maghrib },
            { name: 'ইশা', time: currentPrayer.isha },
            { name: 'সূর্যোদয়', time: currentPrayer.sunrise },
          ].map((item) => (
            <div
              key={item.name}
              className="flex items-center justify-between px-3 py-2 bg-[#F9FAFB] border border-[#E5E7EB]"
            >
              <span className="font-bold text-[#111827]">{item.name}</span>
              <span className="font-mono-num text-[#047857] font-semibold">
                {item.time}
              </span>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-[#6B7280] mt-2.5 text-center">
          সূত্র: ইসলামিক ফাউন্ডেশন বাংলাদেশ ({selectedDiv} অঞ্চল)
        </p>
      </div>

      {/* 2. CURRENCY & GOLD MARKET WIDGET (মুদ্রা ও বাজারদর) */}
      <div className="bg-white border border-[#E5E7EB] p-4 rounded-[2px]">
        <div className="flex items-center justify-between border-b-2 border-[#111827] pb-2.5 mb-3">
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-[#D32F2F]" />
            <h3 className="font-editorial font-bold text-base text-[#111827]">
              বিনিময় হার ও স্বর্ণের বাজারদর
            </h3>
          </div>
          <span className="text-[11px] text-[#6B7280]">আজকের দর</span>
        </div>

        <div className="divide-y divide-[#E5E7EB] text-xs">
          {EXCHANGE_RATES.map((item) => (
            <div
              key={item.currency}
              className="py-2 flex items-center justify-between gap-2"
            >
              <span className="font-medium text-[#374151]">{item.currency}</span>
              <div className="text-right">
                <span className="font-mono-num font-bold text-[#111827]">
                  {item.rate}
                </span>
                <span className="text-[10px] text-emerald-700 ml-1.5">
                  ({item.change})
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. DAILY READER POLL (আজকের অনলাইন জরিপ) */}
      <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 rounded-[2px]">
        <div className="flex items-center justify-between border-b-2 border-[#111827] pb-2.5 mb-3">
          <div className="flex items-center gap-2">
            <Vote className="w-4 h-4 text-[#D32F2F]" />
            <h3 className="font-editorial font-bold text-base text-[#111827]">
              আজকের জনমত জরিপ
            </h3>
          </div>
          <span className="text-[11px] font-mono-num text-[#6B7280]">
            মোট ভোট: {toBengaliNumber(totalVotes)}
          </span>
        </div>

        <p className="font-editorial font-bold text-sm text-[#111827] leading-snug mb-3.5">
          নিত্যপ্রয়োজনীয় পণ্যের বাজার নিয়ন্ত্রণে জেলা পর্যায়ে ডিজিটাল মূল্য তালিকা ও তদারকি কি কার্যকর ভূমিকা রাখবে বলে মনে করেন?
        </p>

        {!votedOption ? (
          <form onSubmit={handleVoteSubmit} className="space-y-2.5">
            {pollOptions.map((opt) => (
              <label
                key={opt.id}
                className={`flex items-center gap-2.5 p-2.5 border text-xs font-medium cursor-pointer transition-colors ${
                  selectedChoice === opt.id
                    ? 'bg-white border-[#111827] text-[#111827] font-bold'
                    : 'bg-white border-[#E5E7EB] text-[#4B5563]'
                }`}
              >
                <input
                  type="radio"
                  name="daily_poll"
                  value={opt.id}
                  checked={selectedChoice === opt.id}
                  onChange={() => setSelectedChoice(opt.id)}
                  className="accent-[#D32F2F]"
                />
                <span>{opt.label}</span>
              </label>
            ))}

            <button
              type="submit"
              className="w-full bg-[#111827] hover:bg-[#D32F2F] text-white font-bold text-xs py-2.5 transition-colors cursor-pointer"
            >
              মতামত প্রদান করুন
            </button>
          </form>
        ) : (
          <div className="space-y-3">
            {pollOptions.map((opt) => {
              const pct =
                totalVotes > 0 ? Math.round((opt.votes / totalVotes) * 100) : 0;
              const isUserVote = votedOption === opt.id;
              return (
                <div key={opt.id} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span
                      className={`font-medium ${
                        isUserVote ? 'font-bold text-[#D32F2F]' : 'text-[#111827]'
                      }`}
                    >
                      {opt.label} {isUserVote ? '(আপনার ভোট)' : ''}
                    </span>
                    <span className="font-mono-num font-bold text-[#111827]">
                      {toBengaliNumber(pct)}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-[#E5E7EB] overflow-hidden">
                    <div
                      className={`h-full ${
                        isUserVote ? 'bg-[#D32F2F]' : 'bg-[#111827]'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
            <div className="flex items-center justify-between pt-2 border-t border-[#E5E7EB] text-[11px] text-emerald-700 font-semibold">
              <span className="inline-flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> আপনার মতামত গৃহীত হয়েছে
              </span>
              <button
                type="button"
                onClick={() => setVotedOption(null)}
                className="text-[#6B7280] hover:text-[#111827] underline cursor-pointer"
              >
                পুনরায় দেখুন
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
