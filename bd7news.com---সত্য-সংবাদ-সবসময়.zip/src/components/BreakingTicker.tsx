import React from 'react';
import { Flame, ChevronRight } from 'lucide-react';
import { useNews } from '../context/NewsContext';

export const BreakingTicker: React.FC = () => {
  const { siteSettings, breakingHeadlines, navigateTo } = useNews();

  if (!siteSettings.breakingNewsEnabled) return null;

  const activeHeadlines = breakingHeadlines
    .filter((b) => b.active)
    .sort((a, b) => a.priority - b.priority);

  if (activeHeadlines.length === 0) return null;

  return (
    <div className="bg-[#FEF2F2] border-b border-[#FECACA] text-[#111827] overflow-hidden">
      <div className="max-w-[1320px] mx-auto flex items-stretch h-10">
        {/* Red Breaking Label */}
        <div className="bg-[#D32F2F] text-white px-3.5 sm:px-5 flex items-center gap-2 shrink-0 z-10 font-bold text-xs sm:text-sm tracking-wide">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-white"></span>
          </span>
          <Flame className="w-3.5 h-3.5 hidden sm:inline" />
          <span>ব্রেকিং</span>
        </div>

        {/* Scrolling Ticker Area */}
        <div className="flex-1 overflow-hidden flex items-center relative bg-[#FFF5F5]">
          <div className="animate-ticker flex items-center whitespace-nowrap py-1">
            {[...activeHeadlines, ...activeHeadlines].map((item, idx) => (
              <button
                key={`${item.id}-${idx}`}
                onClick={() => {
                  if (item.articleId) {
                    navigateTo({ type: 'article', articleId: item.articleId });
                  } else {
                    navigateTo({ type: 'latest' });
                  }
                }}
                className="inline-flex items-center gap-2.5 mx-6 text-xs sm:text-sm font-medium text-[#111827] hover:text-[#D32F2F] transition-colors cursor-pointer text-left"
              >
                <span className="w-1.5 h-1.5 bg-[#D32F2F] inline-block shrink-0" />
                <span className="font-editorial font-semibold">{item.headline}</span>
                <span className="text-[11px] text-[#6B7280] font-normal">
                  ({item.createdAtBn})
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Quick Link to Latest */}
        <button
          onClick={() => navigateTo({ type: 'latest' })}
          className="hidden md:flex items-center gap-1 px-3 bg-white border-l border-[#FECACA] text-xs font-semibold text-[#D32F2F] hover:bg-[#D32F2F] hover:text-white transition-colors shrink-0 cursor-pointer"
        >
          <span>সব ব্রেকিং</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
