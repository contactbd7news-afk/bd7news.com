import React, { useState } from 'react';
import {
  Download,
  FileCode,
  CheckCircle2,
  Copy,
  Layers,
  Sparkles,
  BookOpen,
  ExternalLink,
  FolderArchive,
} from 'lucide-react';
import { useNews } from '../context/NewsContext';
import { SiteSettings } from '../types/news';

// ============================================================================
// STANDARD PKZIP ARCHIVE GENERATOR (Creates valid .zip for WordPress Theme Upload)
// ============================================================================
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ bytes[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

interface ZipEntryInput {
  path: string; // e.g. 'bd7news-theme/style.css'
  data: Uint8Array;
}

function buildZipArchive(entries: ZipEntryInput[]): Blob {
  const encoder = new TextEncoder();
  const localFileParts: Uint8Array[] = [];
  const centralDirParts: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.path);
    const data = entry.data;
    const crc = crc32(data);
    const size = data.length;

    // Local file header (30 bytes + nameBytes)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true); // signature
    lv.setUint16(4, 20, true); // version needed
    lv.setUint16(6, 0x0800, true); // UTF-8 flag
    lv.setUint16(8, 0, true); // compression: 0 (STORE)
    lv.setUint16(10, 0x4800, true); // mod time
    lv.setUint16(12, 0x593b, true); // mod date
    lv.setUint32(14, crc, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    localFileParts.push(localHeader, data);

    // Central directory header (46 bytes + nameBytes)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true); // signature
    cv.setUint16(4, 20, true); // version made by
    cv.setUint16(6, 20, true); // version needed
    cv.setUint16(8, 0x0800, true); // UTF-8 flag
    cv.setUint16(10, 0, true); // compression: 0 (STORE)
    cv.setUint16(12, 0x4800, true);
    cv.setUint16(14, 0x593b, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    centralDirParts.push(centralHeader);
    offset += localHeader.length + data.length;
  }

  let centralSize = 0;
  for (const part of centralDirParts) centralSize += part.length;

  // End of central directory record (22 bytes)
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  return new Blob([...localFileParts, ...centralDirParts, eocd], {
    type: 'application/zip',
  });
}

// Generate 880x660 PNG Screenshot for WordPress Theme Appearance Screen
async function generateThemeScreenshotPng(siteSettings: SiteSettings): Promise<Uint8Array> {
  const canvas = document.createElement('canvas');
  canvas.width = 880;
  canvas.height = 660;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new Uint8Array();

  // White background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, 880, 660);

  // Top utility bar
  ctx.fillStyle = '#111827';
  ctx.fillRect(0, 0, 880, 36);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 13px sans-serif';
  ctx.fillText('শনিবার, ২৬ সেপ্টেম্বর ২০২৬ | ১১ আশ্বিন ১৪৩৩ বঙ্গাব্দ', 28, 23);

  // Masthead
  ctx.fillStyle = '#111827';
  ctx.font = '900 44px Georgia, serif';
  ctx.fillText('bd', 28, 92);
  ctx.fillStyle = '#D32F2F';
  ctx.fillText('7', 86, 92);
  ctx.fillStyle = '#111827';
  ctx.fillText('news', 114, 92);
  ctx.fillStyle = '#D32F2F';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText('.com', 228, 92);

  ctx.fillStyle = '#4B5563';
  ctx.font = 'bold 14px sans-serif';
  ctx.fillText(siteSettings.taglineBn || 'সত্য সংবাদ সবসময়', 28, 114);

  // Navbar
  ctx.fillStyle = '#111827';
  ctx.fillRect(0, 128, 880, 38);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 13px sans-serif';
  ctx.fillText('প্রচ্ছদ   সর্বশেষ   জাতীয়   সারাদেশ   রাজনীতি   আন্তর্জাতিক   খেলাধুলা   অর্থনীতি   প্রযুক্তি   চাকরি   আবহাওয়া', 28, 152);

  // Breaking news ticker
  ctx.fillStyle = '#FEF2F2';
  ctx.fillRect(28, 178, 824, 32);
  ctx.fillStyle = '#D32F2F';
  ctx.fillRect(28, 178, 110, 32);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('ব্রেকিং নিউজ', 44, 199);
  ctx.fillStyle = '#111827';
  ctx.fillText('• ঢাকা-চট্টগ্রাম অর্থনৈতিক করিডোরে নতুন হাইস্পিড লজিস্টিকস হাব স্থাপনের চূড়ান্ত অনুমোদন', 150, 199);

  // Hero Grid boxes
  ctx.fillStyle = '#E5E7EB';
  ctx.fillRect(28, 224, 520, 260);
  ctx.fillStyle = '#111827';
  ctx.fillRect(28, 410, 520, 74);
  ctx.fillStyle = '#D32F2F';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('প্রধান সংবাদ • জাতীয়', 44, 432);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 18px sans-serif';
  ctx.fillText('bd7news.com ওয়ার্ডপ্রেস নিউজ পোর্টাল থিম (WordPress Theme)', 44, 458);

  // Right sidebar boxes
  ctx.fillStyle = '#F9FAFB';
  ctx.fillRect(568, 224, 284, 400);
  ctx.strokeStyle = '#E5E7EB';
  ctx.strokeRect(568, 224, 284, 400);
  ctx.fillStyle = '#D32F2F';
  ctx.fillRect(568, 224, 284, 36);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 14px sans-serif';
  ctx.fillText('সর্বশেষ ও সর্বাধিক পঠিত সংবাদ', 584, 247);

  for (let i = 0; i < 5; i++) {
    const y = 285 + i * 64;
    ctx.fillStyle = '#D32F2F';
    ctx.font = 'bold 16px monospace';
    ctx.fillText(`০${i + 1}`, 584, y);
    ctx.fillStyle = '#111827';
    ctx.font = 'bold 13px sans-serif';
    ctx.fillText('বাংলাদেশের শীর্ষ অনলাইন নিউজ পোর্টাল সংবাদ শিরোনাম', 616, y);
    ctx.fillStyle = '#E5E7EB';
    ctx.fillRect(584, y + 18, 250, 1);
  }

  // Bottom 3 cards
  for (let c = 0; c < 3; c++) {
    const x = 28 + c * 178;
    ctx.fillStyle = '#F3F4F6';
    ctx.fillRect(x, 500, 164, 124);
    ctx.fillStyle = '#D32F2F';
    ctx.fillRect(x, 500, 164, 4);
    ctx.fillStyle = '#111827';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText('বিভাগীয় বিশেষ প্রতিবেদন', x + 10, 595);
  }

  const dataUrl = canvas.toDataURL('image/png');
  const base64 = dataUrl.split(',')[1];
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

// ============================================================================
// WORDPRESS THEME FILES GENERATOR
// ============================================================================
export function generateWordPressThemeFiles(siteSettings: SiteSettings): Record<string, string> {
  const siteName = siteSettings.siteName || 'bd7news.com';
  const taglineBn = siteSettings.taglineBn || 'সত্য সংবাদ সবসময়';
  const editorName = siteSettings.editorNameBn || 'মাহমুদুর রহমান চৌধুরী';
  const publisherName = siteSettings.publisherNameBn || 'বিডি৭ মিডিয়া লিমিটেড';
  const addressBn = siteSettings.addressBn || 'কারওয়ান বাজার বা/এ, ঢাকা-১২১৫';
  const phoneBn = siteSettings.phoneBn || '+৮৮০ ২ ৫৫০১২৩৪৫';
  const email = siteSettings.email || 'contactbd7news@gmail.com';

  const styleCss = `/*
Theme Name: BD7News Bangla News Portal
Theme URI: https://bd7news.com
Author: ${publisherName}
Author URI: https://bd7news.com
Description: বাংলাদেশের শীর্ষস্থানীয় আধুনিক বাংলা অনলাইন নিউজ পোর্টাল ওয়ার্ডপ্রেস থিম (${siteName} — "${taglineBn}")। এতে রয়েছে কাস্টম লোগো আপলোডার, ব্রেকিং নিউজ টিকার, লিড নিউজ গ্রিড, সর্বশেষ ও সর্বাধিক পঠিত ট্যাব, সারাদেশ (বিভাগ-জেলা-উপজেলা) সংবাদ ফিল্টার, ১১টি বিজ্ঞাপন ও Google AdSense স্লট এবং সম্পূর্ণ রেসপনসিভ নিউজপেপার লেআউট।
Version: 2.5.0
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: bd7news
Tags: news, blog, custom-logo, custom-menu, featured-images, theme-options, threaded-comments, two-columns
*/

@import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=Noto+Serif+Bengali:wght@400;500;600;700;800;900&family=Inter:wght@400;500;600;700;800&display=swap');

:root {
  --bd7-bg: #FFFFFF;
  --bd7-surface: #F9FAFB;
  --bd7-ink: #111827;
  --bd7-body: #1F2937;
  --bd7-muted: #4B5563;
  --bd7-red: #D32F2F;
  --bd7-red-dark: #B71C1C;
  --bd7-border: #E5E7EB;
  --font-editorial: 'Noto Serif Bengali', Georgia, serif;
  --font-ui: 'Hind Siliguri', 'Inter', sans-serif;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  background-color: var(--bd7-bg);
  color: var(--bd7-body);
  font-family: var(--font-ui);
  line-height: 1.65;
  -webkit-font-smoothing: antialiased;
}

a {
  color: inherit;
  text-decoration: none;
  transition: color 0.15s ease;
}

a:hover {
  color: var(--bd7-red);
}

img {
  max-width: 100%;
  height: auto;
  display: block;
}

.bd7-container {
  max-width: 1320px;
  margin: 0 auto;
  padding: 0 16px;
}

/* Top Utility Bar */
.bd7-topbar {
  background: var(--bd7-surface);
  border-bottom: 1px solid var(--bd7-border);
  font-size: 12px;
  color: var(--bd7-muted);
  padding: 8px 0;
}
.bd7-topbar-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;
}

/* Masthead & Custom Logo */
.bd7-masthead {
  padding: 18px 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: wrap;
}
.bd7-brand-logo img.custom-logo {
  max-height: ${siteSettings.logoHeight || 54}px;
  width: auto;
  object-fit: contain;
}
.bd7-text-logo {
  font-family: var(--font-editorial);
  font-weight: 900;
  font-size: 42px;
  color: var(--bd7-ink);
  line-height: 1;
  letter-spacing: -0.02em;
}
.bd7-text-logo .red {
  color: var(--bd7-red);
}
.bd7-text-logo .dotcom {
  font-size: 20px;
  color: var(--bd7-red);
  font-family: var(--font-ui);
}
.bd7-tagline {
  font-family: var(--font-editorial);
  font-size: 13px;
  font-weight: 600;
  color: var(--bd7-muted);
  margin-top: 4px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.bd7-tagline::before {
  content: "";
  display: inline-block;
  width: 24px;
  height: 2px;
  background: var(--bd7-red);
}

/* Sticky Navigation */
.bd7-navbar {
  position: sticky;
  top: 0;
  z-index: 50;
  background: #FFFFFF;
  border-top: 2px solid var(--bd7-ink);
  border-bottom: 1px solid var(--bd7-border);
}
.bd7-nav-list {
  list-style: none;
  display: flex;
  align-items: center;
  overflow-x: auto;
}
.bd7-nav-list li a {
  display: block;
  padding: 11px 15px;
  font-weight: 700;
  font-size: 14px;
  color: var(--bd7-ink);
  white-space: nowrap;
  border-right: 1px solid #F3F4F6;
}
.bd7-nav-list li a:hover,
.bd7-nav-list li.current-menu-item a {
  color: var(--bd7-red);
  background: var(--bd7-surface);
}

/* Breaking News Ticker */
.bd7-breaking-bar {
  background: #FEF2F2;
  border-bottom: 1px solid #FECACA;
  display: flex;
  align-items: center;
  height: 40px;
  overflow: hidden;
}
.bd7-breaking-label {
  background: var(--bd7-red);
  color: #FFFFFF;
  font-weight: 800;
  font-size: 13px;
  padding: 0 16px;
  height: 100%;
  display: flex;
  align-items: center;
  white-space: nowrap;
  flex-shrink: 0;
}
.bd7-breaking-marquee {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  padding: 0 16px;
  font-weight: 700;
  font-size: 14px;
  color: var(--bd7-ink);
}

/* Editorial Layout Grid */
.bd7-main-grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 24px;
  margin-top: 24px;
}
.bd7-col-8 { grid-column: span 8; }
.bd7-col-4 { grid-column: span 4; }
.bd7-col-12 { grid-column: span 12; }

@media (max-width: 991px) {
  .bd7-col-8, .bd7-col-4 {
    grid-column: span 12;
  }
}

/* Section Header */
.bd7-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 2px solid var(--bd7-ink);
  border-bottom: 1px solid var(--bd7-border);
  padding: 10px 0;
  margin-bottom: 20px;
}
.bd7-section-title {
  font-family: var(--font-editorial);
  font-size: 22px;
  font-weight: 800;
  color: var(--bd7-ink);
  border-left: 4px solid var(--bd7-red);
  padding-left: 10px;
  line-height: 1.2;
}

/* News Cards */
.bd7-hero-card {
  border-bottom: 1px solid var(--bd7-border);
  padding-bottom: 20px;
  margin-bottom: 20px;
}
.bd7-hero-card .post-thumb img {
  width: 100%;
  aspect-ratio: 16 / 9;
  object-fit: cover;
  margin-bottom: 14px;
}
.bd7-cat-kicker {
  display: inline-block;
  color: var(--bd7-red);
  font-weight: 700;
  font-size: 12px;
  text-transform: uppercase;
  margin-bottom: 6px;
}
.bd7-hero-title {
  font-family: var(--font-editorial);
  font-size: 30px;
  font-weight: 800;
  line-height: 1.3;
  color: var(--bd7-ink);
  margin-bottom: 10px;
}
.bd7-excerpt {
  color: var(--bd7-muted);
  font-size: 15px;
  margin-bottom: 10px;
}
.bd7-meta {
  font-size: 12px;
  color: #6B7280;
}

.bd7-cards-3col {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}
@media (max-width: 767px) {
  .bd7-cards-3col {
    grid-template-columns: 1fr;
  }
}
.bd7-news-card {
  border: 1px solid var(--bd7-border);
  background: #FFFFFF;
  padding: 12px;
}
.bd7-news-card img {
  width: 100%;
  aspect-ratio: 16 / 10;
  object-fit: cover;
  margin-bottom: 10px;
}
.bd7-card-title {
  font-family: var(--font-editorial);
  font-size: 17px;
  font-weight: 700;
  line-height: 1.38;
  color: var(--bd7-ink);
  margin-bottom: 6px;
}

/* Sidebar */
.bd7-sidebar-box {
  background: var(--bd7-surface);
  border: 1px solid var(--bd7-border);
  padding: 16px;
  margin-bottom: 24px;
}
.bd7-sidebar-list {
  list-style: none;
}
.bd7-sidebar-list li {
  padding: 10px 0;
  border-bottom: 1px solid var(--bd7-border);
  display: flex;
  gap: 12px;
  align-items: flex-start;
}
.bd7-rank-num {
  font-weight: 800;
  font-size: 18px;
  color: var(--bd7-red);
  min-width: 26px;
}

/* Advertisement Slot */
.bd7-ad-slot {
  background: var(--bd7-surface);
  border: 1px dashed #D1D5DB;
  padding: 12px;
  text-align: center;
  margin: 16px 0;
}
.bd7-ad-label {
  display: block;
  font-size: 10px;
  text-transform: uppercase;
  color: #9CA3AF;
  margin-bottom: 4px;
}

/* Single Article */
.bd7-single-headline {
  font-family: var(--font-editorial);
  font-size: 36px;
  font-weight: 800;
  line-height: 1.28;
  color: var(--bd7-ink);
  margin: 10px 0 14px;
}
.bd7-single-content {
  font-family: var(--font-editorial);
  font-size: 18px;
  line-height: 1.85;
  color: var(--bd7-body);
}
.bd7-single-content p {
  margin-bottom: 20px;
}

/* Footer */
.bd7-footer {
  background: var(--bd7-surface);
  border-top: 2px solid var(--bd7-ink);
  margin-top: 48px;
  padding: 40px 0 24px;
}
.bd7-footer-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 32px;
  padding-bottom: 28px;
  border-bottom: 1px solid var(--bd7-border);
}
@media (max-width: 767px) {
  .bd7-footer-grid {
    grid-template-columns: 1fr;
  }
}
`;

  const functionsPhp = `<?php
/**
 * BD7News Bangla News Portal Theme Functions and Definitions
 *
 * @package BD7News
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * 1. Theme Setup (Custom Logo, Thumbnails, Menus, HTML5)
 */
function bd7news_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_image_size( 'bd7news-hero', 1200, 675, true );
    add_image_size( 'bd7news-card', 600, 375, true );

    // Custom Logo Upload Support (Appearance -> Customize -> Site Identity)
    add_theme_support( 'custom-logo', array(
        'height'      => ${siteSettings.logoHeight || 60},
        'width'       => 280,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ) );

    register_nav_menus( array(
        'primary-menu' => __( 'প্রধান নেভিগেশন মেনু (Primary Menu)', 'bd7news' ),
        'footer-menu'  => __( 'ফুটার মেনু (Footer Links)', 'bd7news' ),
    ) );
}
add_action( 'after_setup_theme', 'bd7news_theme_setup' );

/**
 * 2. Enqueue Styles & Google Fonts
 */
function bd7news_enqueue_scripts() {
    wp_enqueue_style( 'bd7news-style', get_stylesheet_uri(), array(), '2.5.0' );
}
add_action( 'wp_enqueue_scripts', 'bd7news_enqueue_scripts' );

/**
 * 3. English to Bengali Number Converter Helper
 */
function bd7news_bn_number( $str ) {
    $en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'am', 'pm', 'AM', 'PM' );
    $bn = array( '০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', 'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর', 'পূর্বাহ্ণ', 'অপরাহ্ণ', 'পূর্বাহ্ণ', 'অপরাহ্ণ' );
    return str_replace( $en, $bn, (string) $str );
}

/**
 * 4. Track & Display Post Views (For সর্বাধিক পঠিত / Most Read)
 */
function bd7news_set_post_views( $postID ) {
    $count_key = 'bd7news_post_views_count';
    $count = get_post_meta( $postID, $count_key, true );
    if ( $count === '' ) {
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '1' );
    } else {
        $count++;
        update_post_meta( $postID, $count_key, $count );
    }
}

function bd7news_get_post_views( $postID ) {
    $count_key = 'bd7news_post_views_count';
    $count = get_post_meta( $postID, $count_key, true );
    if ( $count === '' ) {
        return '১২০';
    }
    return bd7news_bn_number( number_format_i18n( intval( $count ) ) );
}

/**
 * 5. Register Custom Taxonomies for সারাদেশ (Division / District / Upazila)
 */
function bd7news_register_location_taxonomies() {
    register_taxonomy( 'bd_location', 'post', array(
        'labels' => array(
            'name'          => 'সারাদেশ (বিভাগ, জেলা ও উপজেলা)',
            'singular_name' => 'এলাকা',
            'menu_name'     => 'সারাদেশ লোকেশন',
        ),
        'hierarchical'      => true,
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
        'rewrite'           => array( 'slug' => 'location' ),
    ) );
}
add_action( 'init', 'bd7news_register_location_taxonomies' );

/**
 * 6. Register Widget Areas & Ad Slots
 */
function bd7news_widgets_init() {
    register_sidebar( array(
        'name'          => 'মূল সাইডবার (Main Sidebar)',
        'id'            => 'sidebar-1',
        'before_widget' => '<div class="bd7-sidebar-box">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="bd7-section-title" style="margin-bottom:12px;">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'bd7news_widgets_init' );

/**
 * 7. WordPress Customizer Options (Breaking News, Editor Info & Google AdSense Slots)
 */
function bd7news_customize_register( $wp_customize ) {
    // Panel: BD7News Portal Settings
    $wp_customize->add_section( 'bd7news_portal_section', array(
        'title'    => __( 'BD7News পোর্টাল ও বিজ্ঞাপন সেটিংস', 'bd7news' ),
        'priority' => 30,
    ) );

    // Tagline Bangla
    $wp_customize->add_setting( 'bd7news_tagline_bn', array(
        'default'           => '${taglineBn}',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'bd7news_tagline_bn', array(
        'label'   => __( 'পোর্টাল ট্যাগলাইন (Tagline)', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'text',
    ) );

    // Breaking News Ticker Enable
    $wp_customize->add_setting( 'bd7news_breaking_enabled', array(
        'default'           => true,
        'sanitize_callback' => 'rest_sanitize_boolean',
    ) );
    $wp_customize->add_control( 'bd7news_breaking_enabled', array(
        'label'   => __( 'ব্রেকিং নিউজ টিকার চালু রাখুন', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'checkbox',
    ) );

    // Editor Name
    $wp_customize->add_setting( 'bd7news_editor_name', array(
        'default'           => '${editorName}',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'bd7news_editor_name', array(
        'label'   => __( 'প্রধান সম্পাদক (Chief Editor)', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'text',
    ) );

    // Publisher Name
    $wp_customize->add_setting( 'bd7news_publisher_name', array(
        'default'           => '${publisherName}',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'bd7news_publisher_name', array(
        'label'   => __( 'প্রকাশক (Publisher)', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'text',
    ) );

    // Office Address
    $wp_customize->add_setting( 'bd7news_address', array(
        'default'           => '${addressBn}',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'bd7news_address', array(
        'label'   => __( 'কার্যালয়ের ঠিকানা', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'text',
    ) );

    // Contact Email & Phone
    $wp_customize->add_setting( 'bd7news_contact_email', array(
        'default'           => '${email}',
        'sanitize_callback' => 'sanitize_email',
    ) );
    $wp_customize->add_control( 'bd7news_contact_email', array(
        'label'   => __( 'ইমেইল (Contact Email)', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'text',
    ) );

    // Header Ad Code (AdSense / HTML)
    $wp_customize->add_setting( 'bd7news_ad_header', array(
        'default' => '',
    ) );
    $wp_customize->add_control( 'bd7news_ad_header', array(
        'label'   => __( 'হেডার বিজ্ঞাপন কোড (Header Leaderboard AdSense/HTML)', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'textarea',
    ) );

    // Sidebar Ad Code
    $wp_customize->add_setting( 'bd7news_ad_sidebar', array(
        'default' => '',
    ) );
    $wp_customize->add_control( 'bd7news_ad_sidebar', array(
        'label'   => __( 'সাইডবার বিজ্ঞাপন কোড (Sidebar 300x250 AdSense/HTML)', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'textarea',
    ) );

    // In-Article Ad Code
    $wp_customize->add_setting( 'bd7news_ad_incontent', array(
        'default' => '',
    ) );
    $wp_customize->add_control( 'bd7news_ad_incontent', array(
        'label'   => __( 'সংবাদের ভেতরে বিজ্ঞাপন কোড (In-Article AdSense/HTML)', 'bd7news' ),
        'section' => 'bd7news_portal_section',
        'type'    => 'textarea',
    ) );
}
add_action( 'customize_register', 'bd7news_customize_register' );
`;

  const headerPhp = `<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="bd7-site-header">
    <!-- 1. Top Utility Bar -->
    <div class="bd7-topbar">
        <div class="bd7-container bd7-topbar-inner">
            <div>
                <strong>📅 <?php echo esc_html( bd7news_bn_number( date_i18n( 'l, j F Y' ) ) ); ?></strong>
                <span style="margin: 0 8px;">|</span>
                <span>🌤️ ঢাকা ৩০°সে • আজকের আবহাওয়া</span>
            </div>
            <div style="display:flex; align-items:center; gap:14px;">
                <a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>">🔍 অনুসন্ধান</a>
                <a href="<?php echo esc_url( admin_url() ); ?>" style="background:#111827; color:#fff; padding:3px 10px; font-weight:700;">অ্যাডমিন প্যানেল</a>
            </div>
        </div>
    </div>

    <!-- 2. Main Masthead (Logo & Header Advertisement) -->
    <div class="bd7-container bd7-masthead">
        <div class="bd7-brand-logo">
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="bd7-text-logo">
                    bd<span class="red">7</span>news<span class="dotcom">.com</span>
                </a>
            <?php endif; ?>
            <div class="bd7-tagline">
                <?php echo esc_html( get_theme_mod( 'bd7news_tagline_bn', '${taglineBn}' ) ); ?>
            </div>
        </div>

        <!-- Header Ad Slot -->
        <div class="bd7-header-ad">
            <?php
            $header_ad = get_theme_mod( 'bd7news_ad_header', '' );
            if ( ! empty( $header_ad ) ) {
                echo $header_ad; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } else {
                echo '<div class="bd7-ad-slot" style="min-width:320px;"><span class="bd7-ad-label">বিজ্ঞাপন • 728×90</span><strong>bd7news.com ডিজিটাল বিজ্ঞাপন স্লট</strong></div>';
            }
            ?>
        </div>
    </div>

    <!-- 3. Sticky Main Navigation Bar -->
    <nav class="bd7-navbar">
        <div class="bd7-container">
            <?php
            if ( has_nav_menu( 'primary-menu' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary-menu',
                    'menu_class'     => 'bd7-nav-list',
                    'container'      => false,
                ) );
            } else {
                ?>
                <ul class="bd7-nav-list">
                    <li class="current-menu-item"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">প্রচ্ছদ</a></li>
                    <?php
                    $categories = get_categories( array( 'number' => 12, 'hide_empty' => false ) );
                    foreach ( $categories as $cat ) {
                        echo '<li><a href="' . esc_url( get_category_link( $cat->term_id ) ) . '">' . esc_html( $cat->name ) . '</a></li>';
                    }
                    ?>
                </ul>
                <?php
            }
            ?>
        </div>
    </nav>

    <!-- 4. Breaking News Ticker -->
    <?php if ( get_theme_mod( 'bd7news_breaking_enabled', true ) ) : ?>
    <div class="bd7-breaking-bar">
        <div class="bd7-container" style="display:flex; align-items:center; width:100%; height:100%; padding:0;">
            <div class="bd7-breaking-label">ব্রেকিং নিউজ</div>
            <div class="bd7-breaking-marquee">
                <marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
                    <?php
                    $breaking_query = new WP_Query( array(
                        'posts_per_page'      => 6,
                        'post_status'         => 'publish',
                        'ignore_sticky_posts' => true,
                    ) );
                    if ( $breaking_query->have_posts() ) :
                        while ( $breaking_query->have_posts() ) :
                            $breaking_query->the_post();
                            echo '<a href="' . esc_url( get_permalink() ) . '" style="margin-right:36px;">🔴 ' . esc_html( get_the_title() ) . '</a>';
                        endwhile;
                        wp_reset_postdata();
                    endif;
                    ?>
                </marquee>
            </div>
        </div>
    </div>
    <?php endif; ?>
</header>
`;

  const footerPhp = `<footer class="bd7-footer">
    <div class="bd7-container">
        <div class="bd7-footer-grid">
            <!-- Col 1: Brand & Editorial Details -->
            <div>
                <?php if ( has_custom_logo() ) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="bd7-text-logo" style="font-size:32px;">
                        bd<span class="red">7</span>news<span class="dotcom">.com</span>
                    </a>
                <?php endif; ?>
                <p style="font-weight:700; color:#4B5563; margin:8px 0 14px;">
                    <?php echo esc_html( get_theme_mod( 'bd7news_tagline_bn', '${taglineBn}' ) ); ?>
                </p>
                <div style="font-size:13px; color:#4B5563; line-height:1.8;">
                    <p><strong>প্রধান সম্পাদক:</strong> <?php echo esc_html( get_theme_mod( 'bd7news_editor_name', '${editorName}' ) ); ?></p>
                    <p><strong>প্রকাশক:</strong> <?php echo esc_html( get_theme_mod( 'bd7news_publisher_name', '${publisherName}' ) ); ?></p>
                    <p>📍 <?php echo esc_html( get_theme_mod( 'bd7news_address', '${addressBn}' ) ); ?></p>
                    <p>📞 <?php echo esc_html( '${phoneBn}' ); ?> | ✉️ <?php echo esc_html( get_theme_mod( 'bd7news_contact_email', '${email}' ) ); ?></p>
                </div>
            </div>

            <!-- Col 2: Categories -->
            <div>
                <h4 style="font-family:var(--font-editorial); font-size:18px; font-weight:800; border-bottom:1px solid #E5E7EB; padding-bottom:8px; margin-bottom:12px;">
                    সংবাদ বিভাগসমূহ
                </h4>
                <div style="display:grid; grid-template-columns:repeat(2,1fr); gap:8px; font-size:14px;">
                    <?php
                    $footer_cats = get_categories( array( 'number' => 12, 'hide_empty' => false ) );
                    foreach ( $footer_cats as $fcat ) {
                        echo '<a href="' . esc_url( get_category_link( $fcat->term_id ) ) . '">• ' . esc_html( $fcat->name ) . '</a>';
                    }
                    ?>
                </div>
            </div>

            <!-- Col 3: Important Links -->
            <div>
                <h4 style="font-family:var(--font-editorial); font-size:18px; font-weight:800; border-bottom:1px solid #E5E7EB; padding-bottom:8px; margin-bottom:12px;">
                    গুরুত্বপূর্ণ লিংক ও নীতিমালা
                </h4>
                <?php
                if ( has_nav_menu( 'footer-menu' ) ) {
                    wp_nav_menu( array(
                        'theme_location' => 'footer-menu',
                        'container'      => false,
                    ) );
                } else {
                    ?>
                    <ul style="list-style:none; font-size:14px; line-height:2;">
                        <li><a href="<?php echo esc_url( home_url( '/about-us' ) ); ?>">আমাদের সম্পর্কে (About Us)</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">যোগাযোগ (Contact)</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>">গোপনীয়তা নীতি (Privacy Policy)</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/terms' ) ); ?>">ব্যবহারের শর্তাবলি (Terms of Use)</a></li>
                    </ul>
                    <?php
                }
                ?>
            </div>
        </div>

        <div style="padding-top:20px; text-align:center; font-size:13px; color:#6B7280;">
            &copy; <?php echo esc_html( bd7news_bn_number( date_i18n( 'Y' ) ) ); ?> <strong><?php bloginfo( 'name' ); ?></strong> — সর্বস্বত্ব সংরক্ষিত।
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
`;

  const indexPhp = `<?php
/**
 * The main homepage & archive template file for BD7News
 *
 * @package BD7News
 */

get_header();
?>

<main class="bd7-container">
    <div class="bd7-main-grid">
        <!-- Left 8 Columns: Lead Story + News Grid -->
        <div class="bd7-col-8">
            <div class="bd7-section-header">
                <h2 class="bd7-section-title">প্রধান সংবাদ ও সর্বশেষ আপডেট</h2>
            </div>

            <?php if ( have_posts() ) : ?>
                <?php
                $post_counter = 0;
                while ( have_posts() ) :
                    the_post();
                    $post_counter++;
                    $cats = get_the_category();
                    $cat_name = ! empty( $cats ) ? $cats[0]->name : 'সংবাদ';

                    if ( $post_counter === 1 ) :
                        ?>
                        <!-- Hero Lead Story -->
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'bd7-hero-card' ); ?>>
                            <?php if ( has_post_thumbnail() ) : ?>
                                <div class="post-thumb">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail( 'bd7news-hero' ); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <span class="bd7-cat-kicker"><?php echo esc_html( $cat_name ); ?></span>
                            <h1 class="bd7-hero-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h1>
                            <div class="bd7-excerpt">
                                <?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 32, '...' ) ); ?>
                            </div>
                            <div class="bd7-meta">
                                🕒 <?php echo esc_html( bd7news_bn_number( get_the_date( 'j F Y, g:i a' ) ) ); ?> • 👁️ <?php echo esc_html( bd7news_get_post_views( get_the_ID() ) ); ?> পাঠক
                            </div>
                        </article>

                        <div class="bd7-cards-3col">
                        <?php
                    else :
                        ?>
                        <!-- Sub Grid Story Card -->
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'bd7-news-card' ); ?>>
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'bd7news-card' ); ?>
                                </a>
                            <?php endif; ?>
                            <span class="bd7-cat-kicker"><?php echo esc_html( $cat_name ); ?></span>
                            <h3 class="bd7-card-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h3>
                            <div class="bd7-meta">
                                <?php echo esc_html( bd7news_bn_number( get_the_date( 'j F Y' ) ) ); ?>
                            </div>
                        </article>
                        <?php
                    endif;
                endwhile;
                if ( $post_counter >= 1 ) {
                    echo '</div><!-- .bd7-cards-3col -->';
                }
                ?>

                <div style="margin: 28px 0;">
                    <?php
                    the_posts_pagination( array(
                        'prev_text' => '← পূর্ববর্তী পাতা',
                        'next_text' => 'পরবর্তী পাতা →',
                    ) );
                    ?>
                </div>
            <?php else : ?>
                <div class="bd7-sidebar-box">
                    <h3>কোনো সংবাদ পাওয়া যায়নি।</h3>
                    <p>ওয়ার্ডপ্রেস ড্যাশবোর্ড থেকে নতুন পোস্ট (Posts → Add New) প্রকাশ করুন।</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Right 4 Columns: Sidebar -->
        <aside class="bd7-col-4">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</main>

<?php
get_footer();
`;

  const singlePhp = `<?php
/**
 * The template for displaying all single news articles
 *
 * @package BD7News
 */

get_header();
?>

<main class="bd7-container">
    <div class="bd7-main-grid">
        <div class="bd7-col-8">
            <?php
            while ( have_posts() ) :
                the_post();
                bd7news_set_post_views( get_the_ID() );
                $cats = get_the_category();
                $cat_name = ! empty( $cats ) ? $cats[0]->name : 'জাতীয়';
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <!-- Breadcrumb & Category -->
                    <div style="margin-bottom:8px;">
                        <span class="bd7-cat-kicker" style="font-size:14px;"><?php echo esc_html( $cat_name ); ?></span>
                    </div>

                    <!-- Headline -->
                    <h1 class="bd7-single-headline"><?php the_title(); ?></h1>

                    <!-- Author, Date & Top Social Share Bar -->
                    <div style="border-top:2px solid #111827; border-bottom:1px solid #E5E7EB; background:#F9FAFB; padding:12px 14px; margin-bottom:20px;">
                        <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:10px; font-size:13px; color:#4B5563; padding-bottom:10px; border-bottom:1px solid #E5E7EB;">
                            <div>
                                <strong>✍️ <?php the_author(); ?></strong> | প্রকাশিত: <?php echo esc_html( bd7news_bn_number( get_the_date( 'j F Y, g:i a' ) ) ); ?>
                            </div>
                            <div>
                                👁️ পাঠক ভিউ: <strong><?php echo esc_html( bd7news_get_post_views( get_the_ID() ) ); ?></strong> |
                                <button id="bd7-tts-btn" onclick="(function(btn){if(window.__bd7Audio){window.__bd7Audio.pause();window.__bd7Audio=null;btn.innerText='🔊 খবরটি শুনুন';return;}var txt=(document.querySelector('.bd7-single-headline').innerText+'। '+document.querySelector('.bd7-single-content').innerText).replace(/\s+/g,' ');var parts=txt.match(/.{1,150}(\s|।|$)/g)||[txt];var i=0;btn.innerText='⏹ থামুন';function next(){if(i>=parts.length||!window.__bd7Audio){window.__bd7Audio=null;btn.innerText='🔊 খবরটি শুনুন';return;}var a=new Audio();a.referrerPolicy='no-referrer';a.src='https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=bn&client=tw-ob&q='+encodeURIComponent(parts[i++].trim());window.__bd7Audio=a;a.onended=next;a.onerror=next;a.play();}window.__bd7Audio=new Audio();next();})(this)" style="cursor:pointer; border:1px solid #D1D5DB; background:#fff; padding:2px 8px; font-size:12px; font-weight:700; color:#D32F2F;">🔊 খবরটি শুনুন</button>
                                <button onclick="window.print()" style="cursor:pointer; border:1px solid #D1D5DB; background:#fff; padding:2px 8px; font-size:12px;">🖨️ প্রিন্ট</button>
                            </div>
                        </div>

                        <?php
                        $share_url   = rawurlencode( get_permalink() );
                        $share_title = rawurlencode( get_the_title() );
                        ?>
                        <div style="display:flex; flex-wrap:wrap; align-items:center; gap:6px; padding-top:10px;">
                            <strong style="font-size:12px; color:#111827; margin-right:4px;">শেয়ার করুন:</strong>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_attr( $share_url ); ?>" target="_blank" rel="noopener" style="background:#1877F2; color:#fff; padding:5px 10px; font-size:12px; font-weight:700;">Facebook</a>
                            <a href="fb-messenger://share/?link=<?php echo esc_attr( $share_url ); ?>" target="_blank" rel="noopener" style="background:#0084FF; color:#fff; padding:5px 10px; font-size:12px; font-weight:700;">Messenger</a>
                            <a href="https://api.whatsapp.com/send?text=<?php echo esc_attr( $share_title . '%20-%20' . $share_url ); ?>" target="_blank" rel="noopener" style="background:#25D366; color:#fff; padding:5px 10px; font-size:12px; font-weight:700;">WhatsApp</a>
                            <a href="https://twitter.com/intent/tweet?text=<?php echo esc_attr( $share_title ); ?>&url=<?php echo esc_attr( $share_url ); ?>" target="_blank" rel="noopener" style="background:#0F1419; color:#fff; padding:5px 10px; font-size:12px; font-weight:700;">X (Twitter)</a>
                            <a href="https://t.me/share/url?url=<?php echo esc_attr( $share_url ); ?>&text=<?php echo esc_attr( $share_title ); ?>" target="_blank" rel="noopener" style="background:#0088CC; color:#fff; padding:5px 10px; font-size:12px; font-weight:700;">Telegram</a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo esc_attr( $share_url ); ?>" target="_blank" rel="noopener" style="background:#0A66C2; color:#fff; padding:5px 10px; font-size:12px; font-weight:700;">LinkedIn</a>
                            <a href="mailto:?subject=<?php echo esc_attr( $share_title ); ?>&body=<?php echo esc_attr( $share_url ); ?>" style="background:#EA4335; color:#fff; padding:5px 10px; font-size:12px; font-weight:700;">Email</a>
                            <button onclick="navigator.clipboard.writeText(window.location.href);this.innerText='✓ কপি হয়েছে';" style="background:#111827; color:#fff; border:none; padding:5px 10px; font-size:12px; font-weight:700; cursor:pointer;">লিংক কপি</button>
                        </div>
                    </div>

                    <!-- Featured Image -->
                    <?php if ( has_post_thumbnail() ) : ?>
                        <figure style="margin-bottom:24px; background:#F9FAFB; border:1px solid #E5E7EB;">
                            <?php the_post_thumbnail( 'bd7news-hero', array( 'style' => 'width:100%; height:auto;' ) ); ?>
                            <?php if ( get_the_post_thumbnail_caption() ) : ?>
                                <figcaption style="padding:8px 12px; font-size:12px; color:#6B7280;">
                                    <?php echo esc_html( get_the_post_thumbnail_caption() ); ?>
                                </figcaption>
                            <?php endif; ?>
                        </figure>
                    <?php endif; ?>

                    <!-- Full Article Content -->
                    <div class="bd7-single-content">
                        <?php the_content(); ?>
                    </div>

                    <!-- In-Content Ad Slot -->
                    <?php
                    $incontent_ad = get_theme_mod( 'bd7news_ad_incontent', '' );
                    if ( ! empty( $incontent_ad ) ) {
                        echo '<div class="bd7-ad-slot">' . $incontent_ad . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    }
                    ?>

                    <!-- Tags -->
                    <div style="margin:24px 0; padding-top:16px; border-top:1px solid #E5E7EB;">
                        <?php the_tags( '<strong>ট্যাগসমূহ: </strong> ', ', ', '' ); ?>
                    </div>

                    <!-- Comments -->
                    <?php
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                    ?>
                </article>
            <?php endwhile; ?>
        </div>

        <aside class="bd7-col-4">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</main>

<?php
get_footer();
`;

  const sidebarPhp = `<?php
/**
 * The Sidebar containing Most Read, Latest News and Sidebar Advertisement
 *
 * @package BD7News
 */
?>

<!-- Latest News Box -->
<div class="bd7-sidebar-box">
    <div class="bd7-section-header" style="margin-bottom:12px;">
        <h3 class="bd7-section-title" style="font-size:18px;">সর্বশেষ সংবাদ</h3>
    </div>
    <ul class="bd7-sidebar-list">
        <?php
        $latest_sidebar = new WP_Query( array(
            'posts_per_page'      => 6,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => true,
        ) );
        $idx = 0;
        if ( $latest_sidebar->have_posts() ) :
            while ( $latest_sidebar->have_posts() ) :
                $latest_sidebar->the_post();
                $idx++;
                ?>
                <li>
                    <span class="bd7-rank-num"><?php echo esc_html( bd7news_bn_number( sprintf( '%02d', $idx ) ) ); ?></span>
                    <div>
                        <a href="<?php the_permalink(); ?>" style="font-family:var(--font-editorial); font-weight:700; font-size:15px; line-height:1.4; display:block;">
                            <?php the_title(); ?>
                        </a>
                        <span class="bd7-meta"><?php echo esc_html( bd7news_bn_number( get_the_date( 'j F Y' ) ) ); ?></span>
                    </div>
                </li>
                <?php
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    </ul>
</div>

<!-- Sidebar 300x250 Ad Slot -->
<div class="bd7-sidebar-box" style="text-align:center;">
    <?php
    $sidebar_ad = get_theme_mod( 'bd7news_ad_sidebar', '' );
    if ( ! empty( $sidebar_ad ) ) {
        echo $sidebar_ad; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    } else {
        echo '<div class="bd7-ad-slot"><span class="bd7-ad-label">বিজ্ঞাপন • 300×250</span><strong>সাইডবার স্পন্সর বিজ্ঞাপন স্লট</strong></div>';
    }
    ?>
</div>

<!-- Most Read Box -->
<div class="bd7-sidebar-box">
    <div class="bd7-section-header" style="margin-bottom:12px;">
        <h3 class="bd7-section-title" style="font-size:18px;">সর্বাধিক পঠিত</h3>
    </div>
    <ul class="bd7-sidebar-list">
        <?php
        $popular_posts = new WP_Query( array(
            'posts_per_page'      => 5,
            'meta_key'            => 'bd7news_post_views_count',
            'orderby'             => 'meta_value_num',
            'order'               => 'DESC',
            'ignore_sticky_posts' => true,
        ) );
        if ( ! $popular_posts->have_posts() ) {
            $popular_posts = new WP_Query( array( 'posts_per_page' => 5 ) );
        }
        $p_idx = 0;
        while ( $popular_posts->have_posts() ) :
            $popular_posts->the_post();
            $p_idx++;
            ?>
            <li>
                <span class="bd7-rank-num"><?php echo esc_html( bd7news_bn_number( sprintf( '%02d', $p_idx ) ) ); ?></span>
                <div>
                    <a href="<?php the_permalink(); ?>" style="font-family:var(--font-editorial); font-weight:700; font-size:15px; line-height:1.4; display:block;">
                        <?php the_title(); ?>
                    </a>
                </div>
            </li>
        <?php endwhile; wp_reset_postdata(); ?>
    </ul>
</div>

<!-- Prayer Times & Market Rates Box -->
<div class="bd7-sidebar-box">
    <div class="bd7-section-header" style="margin-bottom:12px;">
        <h3 class="bd7-section-title" style="font-size:18px;">নামাজের সময়সূচি (ঢাকা)</h3>
    </div>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px; font-size:12px;">
        <div style="background:#fff; border:1px solid #E5E7EB; padding:6px 10px; display:flex; justify-content:space-between;"><strong>ফজর</strong><span>৪:৩৪ ভোর</span></div>
        <div style="background:#fff; border:1px solid #E5E7EB; padding:6px 10px; display:flex; justify-content:space-between;"><strong>জোহর</strong><span>১১:৫৬ দুপুর</span></div>
        <div style="background:#fff; border:1px solid #E5E7EB; padding:6px 10px; display:flex; justify-content:space-between;"><strong>আসর</strong><span>৪:১৮ বিকেল</span></div>
        <div style="background:#fff; border:1px solid #E5E7EB; padding:6px 10px; display:flex; justify-content:space-between;"><strong>মাগরিব</strong><span>৫:৫৪ সন্ধ্যা</span></div>
        <div style="background:#fff; border:1px solid #E5E7EB; padding:6px 10px; display:flex; justify-content:space-between;"><strong>ইশা</strong><span>৭:০৯ রাত</span></div>
        <div style="background:#fff; border:1px solid #E5E7EB; padding:6px 10px; display:flex; justify-content:space-between;"><strong>সূর্যোদয়</strong><span>৫:৪৮ সকাল</span></div>
    </div>
</div>

<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
    <?php dynamic_sidebar( 'sidebar-1' ); ?>
<?php endif; ?>
`;

  const archivePhp = `<?php
/**
 * The template for displaying Category, Tag, Location and Date Archives
 *
 * @package BD7News
 */

get_header();
?>

<main class="bd7-container">
    <div class="bd7-main-grid">
        <div class="bd7-col-8">
            <div class="bd7-section-header">
                <h1 class="bd7-section-title"><?php the_archive_title(); ?></h1>
            </div>

            <?php if ( have_posts() ) : ?>
                <div class="bd7-cards-3col">
                    <?php
                    while ( have_posts() ) :
                        the_post();
                        ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'bd7-news-card' ); ?>>
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'bd7news-card' ); ?>
                                </a>
                            <?php endif; ?>
                            <h2 class="bd7-card-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            <div class="bd7-excerpt" style="font-size:13px;">
                                <?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 18, '...' ) ); ?>
                            </div>
                            <div class="bd7-meta">
                                <?php echo esc_html( bd7news_bn_number( get_the_date( 'j F Y' ) ) ); ?>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>

                <div style="margin:28px 0;">
                    <?php the_posts_pagination(); ?>
                </div>
            <?php else : ?>
                <p>এই বিভাগে এখনো কোনো সংবাদ প্রকাশিত হয়নি।</p>
            <?php endif; ?>
        </div>

        <aside class="bd7-col-4">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</main>

<?php
get_footer();
`;

  const searchPhp = `<?php
/**
 * The template for displaying Search Results pages
 *
 * @package BD7News
 */

get_header();
?>

<main class="bd7-container">
    <div class="bd7-main-grid">
        <div class="bd7-col-8">
            <div class="bd7-section-header">
                <h1 class="bd7-section-title">
                    অনুসন্ধান ফলাফল: “<?php echo esc_html( get_search_query() ); ?>”
                </h1>
            </div>

            <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="display:flex; gap:8px; margin-bottom:24px;">
                <input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="শিরোনাম বা বিষয় লিখে খুঁজুন..." style="flex:1; padding:10px 14px; border:1px solid #D1D5DB; font-size:14px;" />
                <button type="submit" style="background:#D32F2F; color:#fff; border:none; padding:10px 22px; font-weight:700; cursor:pointer;">খুঁজুন</button>
            </form>

            <?php if ( have_posts() ) : ?>
                <div class="bd7-cards-3col">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'bd7-news-card' ); ?>>
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'bd7news-card' ); ?></a>
                            <?php endif; ?>
                            <h2 class="bd7-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="bd7-meta"><?php echo esc_html( bd7news_bn_number( get_the_date( 'j F Y' ) ) ); ?></div>
                        </article>
                    <?php endwhile; ?>
                </div>
                <?php the_posts_pagination(); ?>
            <?php else : ?>
                <p>দুঃখিত, আপনার অনুসন্ধানের সাথে মিলে এমন কোনো সংবাদ পাওয়া যায়নি।</p>
            <?php endif; ?>
        </div>

        <aside class="bd7-col-4">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</main>

<?php
get_footer();
`;

  const pagePhp = `<?php
/**
 * The template for displaying all static pages (About Us, Contact, Privacy Policy)
 *
 * @package BD7News
 */

get_header();
?>

<main class="bd7-container">
    <div class="bd7-main-grid">
        <div class="bd7-col-8">
            <?php while ( have_posts() ) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h1 class="bd7-single-headline"><?php the_title(); ?></h1>
                    <div class="bd7-single-content">
                        <?php the_content(); ?>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>
        <aside class="bd7-col-4">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</main>

<?php
get_footer();
`;

  const readmeTxt = `========================================================================
BD7News Bangla News Portal — WordPress Theme (v2.5.0)
পোর্টাল: ${siteName} ("${taglineBn}")
========================================================================

ওয়ার্ডপ্রেসে থিমটি ইনস্টল করার নিয়ম (Step-by-Step Guide):

১. আপনার ওয়ার্ডপ্রেস অ্যাডমিন ড্যাশবোর্ডে লগইন করুন (যেমন: yourdomain.com/wp-admin)।
২. বাম পাশের মেনু থেকে "Appearance" -> "Themes"-এ ক্লিক করুন।
৩. উপরে "Add New Theme" বাটনে ক্লিক করে "Upload Theme"-এ ক্লিক করুন।
৪. আপনার ডাউনলোড করা "bd7news-wordpress-theme.zip" ফাইলটি সিলেক্ট করে "Install Now"-এ ক্লিক করুন।
৫. ইনস্টল সম্পন্ন হলে "Activate"-এ ক্লিক করুন।

লোগো আপলোড ও কাস্টমাইজেশন:
- ওয়ার্ডপ্রেস ড্যাশবোর্ডে "Appearance" -> "Customize" -> "Site Identity"-তে গিয়ে "Select Logo"-তে ক্লিক করে আপনার লোগো আপলোড করুন।
- "Appearance" -> "Customize" -> "BD7News পোর্টাল ও বিজ্ঞাপন সেটিংস"-এ গিয়ে ব্রেকিং নিউজ টিকার, প্রধান সম্পাদকের নাম, ঠিকানা এবং Google AdSense কোড বসাতে পারবেন।
`;

  return {
    'style.css': styleCss,
    'functions.php': functionsPhp,
    'header.php': headerPhp,
    'footer.php': footerPhp,
    'index.php': indexPhp,
    'single.php': singlePhp,
    'sidebar.php': sidebarPhp,
    'archive.php': archivePhp,
    'search.php': searchPhp,
    'page.php': pagePhp,
    'README-BN.txt': readmeTxt,
  };
}

export const WordPressThemeExporter: React.FC<{
  onSuccess?: (msg: string) => void;
}> = ({ onSuccess }) => {
  const { siteSettings, categories, articles } = useNews();
  const [selectedFile, setSelectedFile] = useState<string>('style.css');
  const [downloading, setDownloading] = useState(false);
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  const themeFiles = generateWordPressThemeFiles(siteSettings);
  const fileNames = Object.keys(themeFiles);

  const handleDownloadWxrXml = () => {
    const escapeXml = (str: string) =>
      str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');

    const catXml = categories
      .map(
        (cat, idx) => `
  <wp:category>
    <wp:term_id>${idx + 10}</wp:term_id>
    <wp:category_nicename>${escapeXml(cat.slug)}</wp:category_nicename>
    <wp:cat_name><![CDATA[${cat.nameBn}]]></wp:cat_name>
  </wp:category>`
      )
      .join('\n');

    const itemsXml = articles
      .slice(0, 35)
      .map(
        (art, idx) => `
  <item>
    <title><![CDATA[${art.headline}]]></title>
    <dc:creator><![CDATA[admin]]></dc:creator>
    <description><![CDATA[${art.summary}]]></description>
    <content:encoded><![CDATA[<p><strong>${art.subtitle || art.summary}</strong></p>${art.content
      .map((p) => `<p>${p}</p>`)
      .join('\n')}]]></content:encoded>
    <excerpt:encoded><![CDATA[${art.summary}]]></excerpt:encoded>
    <wp:post_id>${idx + 100}</wp:post_id>
    <wp:post_date>2026-09-26 12:00:00</wp:post_date>
    <wp:status>publish</wp:status>
    <wp:post_type>post</wp:post_type>
    <category domain="category" nicename="${escapeXml(art.category)}"><![CDATA[${art.categoryNameBn}]]></category>
    ${
      art.district
        ? `<category domain="bd_location" nicename="${escapeXml(art.district)}"><![CDATA[${art.district}]]></category>`
        : ''
    }
  </item>`
      )
      .join('\n');

    const wxrContent = `<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0"
  xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:wfw="http://wellformedweb.org/CommentAPI/"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:wp="http://wordpress.org/export/1.2/"
>
<channel>
  <title>${escapeXml(siteSettings.siteName)}</title>
  <link>https://bd7news.com</link>
  <description>${escapeXml(siteSettings.taglineBn)}</description>
  <language>bn-BD</language>
  <wp:wxr_version>1.2</wp:wxr_version>
  ${catXml}
  ${itemsXml}
</channel>
</rss>`;

    const blob = new Blob([wxrContent], { type: 'application/xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bd7news-wordpress-demo-content.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (onSuccess) {
      onSuccess('bd7news-wordpress-demo-content.xml সফলভাবে ডাউনলোড হয়েছে!');
    }
  };

  const handleDownloadZip = async () => {
    setDownloading(true);
    try {
      const encoder = new TextEncoder();
      const entries: ZipEntryInput[] = [];

      // Add all PHP/CSS/TXT files inside bd7news-theme/ folder
      for (const [filename, content] of Object.entries(themeFiles)) {
        entries.push({
          path: `bd7news-theme/${filename}`,
          data: encoder.encode(content),
        });
      }

      // Generate and add screenshot.png
      const screenshotBytes = await generateThemeScreenshotPng(siteSettings);
      if (screenshotBytes.length > 0) {
        entries.push({
          path: 'bd7news-theme/screenshot.png',
          data: screenshotBytes,
        });
      }

      const zipBlob = buildZipArchive(entries);
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'bd7news-wordpress-theme.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      if (onSuccess) {
        onSuccess('bd7news-wordpress-theme.zip সফলভাবে ডাউনলোড হয়েছে!');
      }
    } finally {
      setDownloading(false);
    }
  };

  const handleCopyCode = (filename: string) => {
    navigator.clipboard.writeText(themeFiles[filename] || '');
    setCopiedFile(filename);
    if (onSuccess) {
      onSuccess(`${filename} ফাইলের কোড কপি করা হয়েছে!`);
    }
    setTimeout(() => setCopiedFile(null), 2500);
  };

  return (
    <div className="bg-white border border-[#E5E7EB] p-5 sm:p-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111827] text-white p-5 sm:p-6 border-l-4 border-[#D32F2F] flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 bg-[#D32F2F] text-white text-[11px] font-bold px-2.5 py-0.5 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" /> WordPress Theme Generator (v2.5)
          </div>
          <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-white">
            bd7news.com পূর্ণাঙ্গ ওয়ার্ডপ্রেস থিম (Installable .ZIP Package)
          </h2>
          <p className="text-xs sm:text-sm text-gray-300 max-w-2xl">
            এক ক্লিকেই আপনার ওয়েবসাইটের সম্পূর্ণ ওয়ার্ডপ্রেস থিম (<code>bd7news-wordpress-theme.zip</code>) ডাউনলোড করুন এবং সরাসরি আপনার ওয়ার্ডপ্রেস ড্যাশবোর্ডে (<strong>Appearance → Themes → Add New → Upload Theme</strong>) আপলোড করে অ্যাক্টিভেট করুন।
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={downloading}
            className="bg-[#D32F2F] hover:bg-[#B71C1C] text-white font-bold text-sm px-5 py-3.5 flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>
              {downloading
                ? 'ZIP তৈরি হচ্ছে...'
                : 'WordPress Theme (.ZIP) ডাউনলোড'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleDownloadWxrXml}
            className="bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-xs px-4 py-3.5 flex items-center justify-center gap-2 transition-all cursor-pointer"
            title="ওয়ার্ডপ্রেসে সকল ক্যাটাগরি ও ডেমো সংবাদ ইমপোর্ট করার XML ফাইল"
          >
            <FileCode className="w-4 h-4 text-[#D32F2F]" />
            <span>ডেমো সংবাদ ও ক্যাটাগরি (.XML)</span>
          </button>
        </div>
      </div>

      {/* Included Features Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-3.5 bg-[#F9FAFB] border border-[#E5E7EB]">
          <div className="text-xs font-bold text-[#D32F2F] mb-1">
            ✓ কাস্টম লোগো ও মাস্টহেড
          </div>
          <p className="text-xs text-[#4B5563]">
            WP Customizer (<code>Site Identity</code>) থেকে সরাসরি লোগো ও ফেভিকন আপলোড সাপোর্ট।
          </p>
        </div>
        <div className="p-3.5 bg-[#F9FAFB] border border-[#E5E7EB]">
          <div className="text-xs font-bold text-[#D32F2F] mb-1">
            ✓ ব্রেকিং নিউজ ও সর্বাধিক পঠিত
          </div>
          <p className="text-xs text-[#4B5563]">
            অটোমেটিক ব্রেকিং নিউজ স্ক্রলিং টিকার এবং পাঠক ভিউ কাউন্টার (Most Read)।
          </p>
        </div>
        <div className="p-3.5 bg-[#F9FAFB] border border-[#E5E7EB]">
          <div className="text-xs font-bold text-[#D32F2F] mb-1">
            ✓ সারাদেশ লোকেশন ট্যাক্সোনমি
          </div>
          <p className="text-xs text-[#4B5563]">
            বিভাগ, জেলা ও উপজেলার সংবাদের জন্য বিল্ট-ইন কাস্টম ট্যাক্সোনমি (<code>bd_location</code>)।
          </p>
        </div>
        <div className="p-3.5 bg-[#F9FAFB] border border-[#E5E7EB]">
          <div className="text-xs font-bold text-[#D32F2F] mb-1">
            ✓ Google AdSense রেডি
          </div>
          <p className="text-xs text-[#4B5563]">
            হেডার, সাইডবার এবং সংবাদের ভেতরে বিজ্ঞাপনের জন্য কাস্টমাইজার অ্যাড কোড বক্স।
          </p>
        </div>
      </div>

      {/* Step-by-Step WordPress Installation Guide */}
      <div className="bg-[#FEF2F2] border border-[#FECACA] p-4 sm:p-5">
        <h3 className="font-editorial font-bold text-base text-[#111827] flex items-center gap-2 mb-2.5">
          <BookOpen className="w-4 h-4 text-[#D32F2F]" />
          <span>ওয়ার্ডপ্রেসে থিমটি যেভাবে ইনস্টল করবেন (৪টি সহজ ধাপ):</span>
        </h3>
        <ol className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs text-[#1F2937]">
          <li className="bg-white p-3 border border-[#FECACA]">
            <strong className="text-[#D32F2F] block mb-1">ধাপ ১: ZIP ডাউনলোড</strong>
            ওপরের লাল বাটনে ক্লিক করে <code>bd7news-wordpress-theme.zip</code> ফাইলটি আপনার কম্পিউটার বা মোবাইলে ডাউনলোড করুন।
          </li>
          <li className="bg-white p-3 border border-[#FECACA]">
            <strong className="text-[#D32F2F] block mb-1">ধাপ ২: WP Admin-এ যান</strong>
            আপনার ওয়ার্ডপ্রেস ড্যাশবোর্ডে গিয়ে <strong>Appearance → Themes → Add New Theme</strong>-এ ক্লিক করুন।
          </li>
          <li className="bg-white p-3 border border-[#FECACA]">
            <strong className="text-[#D32F2F] block mb-1">ধাপ ৩: Upload ও Activate</strong>
            <strong>Upload Theme</strong> বাটনে ক্লিক করে <code>.zip</code> ফাইলটি আপলোড করুন এবং <strong>Activate</strong> করুন।
          </li>
          <li className="bg-white p-3 border border-[#FECACA]">
            <strong className="text-[#D32F2F] block mb-1">ধাপ ৪: লোগো ও মেনু সেটআপ</strong>
            <strong>Appearance → Customize</strong>-এ গিয়ে আপনার লোগো, মেনু এবং বিজ্ঞাপন কোড সেট করুন।
          </li>
        </ol>
      </div>

      {/* Interactive Theme Source Code Inspector */}
      <div className="border border-[#E5E7EB]">
        <div className="bg-[#F9FAFB] border-b border-[#E5E7EB] px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <FolderArchive className="w-4 h-4 text-[#D32F2F]" />
            <span className="text-xs font-bold text-[#111827]">
              থিমের ভেতরের ফাইলসমূহ (PHP ও CSS সোর্স কোড প্রিভিউ)
            </span>
          </div>
          <button
            type="button"
            onClick={() => handleCopyCode(selectedFile)}
            className="inline-flex items-center gap-1.5 bg-[#111827] hover:bg-[#D32F2F] text-white text-xs font-bold px-3 py-1.5 transition-colors cursor-pointer self-start"
          >
            {copiedFile === selectedFile ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>কপি হয়েছে!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>{selectedFile} কপি করুন</span>
              </>
            )}
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center overflow-x-auto bg-[#F3F4F6] border-b border-[#E5E7EB] px-2 pt-2 gap-1">
          {fileNames.map((fname) => (
            <button
              key={fname}
              type="button"
              onClick={() => setSelectedFile(fname)}
              className={`px-3 py-2 text-xs font-mono-num font-bold flex items-center gap-1.5 border-t border-x transition-colors cursor-pointer shrink-0 ${
                selectedFile === fname
                  ? 'bg-white text-[#D32F2F] border-[#E5E7EB]'
                  : 'bg-transparent text-[#4B5563] border-transparent hover:bg-white/60'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>{fname}</span>
            </button>
          ))}
        </div>

        {/* Code Viewer */}
        <pre className="bg-[#111827] text-gray-100 p-4 text-xs font-mono-num overflow-x-auto max-h-[420px] leading-relaxed">
          <code>{themeFiles[selectedFile]}</code>
        </pre>
      </div>
    </div>
  );
};
