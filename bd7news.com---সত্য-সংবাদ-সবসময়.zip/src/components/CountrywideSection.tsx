import React, { useState, useMemo } from 'react';
import {
  MapPin,
  Search,
  RotateCcw,
  Clock,
  Building2,
} from 'lucide-react';
import { BD_DIVISIONS } from '../data/bdLocations';
import { useNews, toBengaliNumber } from '../context/NewsContext';
import { MostReadWidget, SectionHeader } from './NewsCard';
import { AdSlot } from './AdSlot';
import { Article } from '../types/news';

// Helper to render location badge on a card
export const LocationBadge: React.FC<{ article: Article }> = ({ article }) => {
  if (!article.division && !article.district && !article.upazila) return null;
  const parts = [article.division, article.district, article.upazila].filter(
    Boolean
  );
  return (
    <span className="inline-flex items-center gap-1 bg-[#FEF2F2] text-[#D32F2F] border border-[#FECACA] px-2 py-0.5 text-[11px] font-bold">
      <MapPin className="w-3 h-3 shrink-0" />
      <span>{parts.join(' • ')}</span>
    </span>
  );
};

// Helper to find parent Division & District for any Upazila
function findLocationByUpazila(upazilaName: string): {
  division: string;
  district: string;
} | null {
  for (const div of BD_DIVISIONS) {
    for (const dist of div.districts) {
      if (dist.upazilas.includes(upazilaName)) {
        return { division: div.nameBn, district: dist.nameBn };
      }
    }
  }
  return null;
}

// ============================================================================
// 1. HOMEPAGE SECTION: "সারাদেশ: বিভাগ, জেলা ও উপজেলার সংবাদ"
// ============================================================================
export const CountrywideHomepageSection: React.FC = () => {
  const { publishedArticles, navigateTo } = useNews();

  const [selectedDivision, setSelectedDivision] = useState<string>('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [selectedUpazila, setSelectedUpazila] = useState<string>('');

  const activeDivisionObj = useMemo(
    () => BD_DIVISIONS.find((d) => d.nameBn === selectedDivision),
    [selectedDivision]
  );

  // Cascading districts based on selectedDivision
  const availableDistricts = useMemo(() => {
    if (!selectedDivision) {
      return BD_DIVISIONS.flatMap((d) => d.districts);
    }
    return activeDivisionObj ? activeDivisionObj.districts : [];
  }, [selectedDivision, activeDivisionObj]);

  // Upazilas for selectedDistrict, OR all upazilas in selectedDivision
  const availableUpazilas = useMemo(() => {
    if (selectedDistrict) {
      const distObj = availableDistricts.find(
        (d) => d.nameBn === selectedDistrict
      );
      return distObj ? distObj.upazilas : [];
    }
    return availableDistricts.flatMap((d) => d.upazilas);
  }, [selectedDistrict, availableDistricts]);

  // Pool of countrywide / regional articles
  const countrywideArticles = useMemo(() => {
    return publishedArticles.filter(
      (a) =>
        a.category === 'countrywide' ||
        Boolean(a.division) ||
        Boolean(a.district) ||
        Boolean(a.upazila) ||
        a.subcategory === 'জেলা সংবাদ'
    );
  }, [publishedArticles]);

  // Filtered articles based on Division / District / Upazila selection
  const filteredArticles = useMemo(() => {
    return countrywideArticles.filter((art) => {
      if (selectedDivision && art.division !== selectedDivision) {
        const matchesText =
          art.headline.includes(selectedDivision) ||
          art.summary.includes(selectedDivision) ||
          art.subcategory.includes(selectedDivision);
        if (!matchesText) return false;
      }
      if (selectedDistrict && art.district !== selectedDistrict) {
        const matchesText =
          art.headline.includes(selectedDistrict) ||
          art.summary.includes(selectedDistrict);
        if (!matchesText) return false;
      }
      if (selectedUpazila && art.upazila !== selectedUpazila) {
        const matchesText =
          art.headline.includes(selectedUpazila) ||
          art.summary.includes(selectedUpazila);
        if (!matchesText) return false;
      }
      return true;
    });
  }, [
    countrywideArticles,
    selectedDivision,
    selectedDistrict,
    selectedUpazila,
  ]);

  const displayArticles =
    filteredArticles.length > 0 ? filteredArticles : countrywideArticles;
  const featuredLocal = displayArticles[0];
  const secondaryLocals = displayArticles.slice(1, 5);
  const moreLocals = displayArticles.slice(5, 9);

  const handleReset = () => {
    setSelectedDivision('');
    setSelectedDistrict('');
    setSelectedUpazila('');
  };

  const handleSelectUpazila = (upz: string, distName?: string) => {
    setSelectedUpazila(upz);
    if (!upz) return;
    if (distName) {
      setSelectedDistrict(distName);
      const parentDiv = BD_DIVISIONS.find((d) =>
        d.districts.some((dist) => dist.nameBn === distName)
      );
      if (parentDiv) setSelectedDivision(parentDiv.nameBn);
    } else {
      const found = findLocationByUpazila(upz);
      if (found) {
        if (!selectedDivision) setSelectedDivision(found.division);
        if (!selectedDistrict) setSelectedDistrict(found.district);
      }
    }
  };

  return (
    <section className="mb-12 bg-white border-y-2 border-[#111827] py-6">
      {/* Top Header & Division Tabs */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 mb-5 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-2.5">
          <span className="w-3 h-7 bg-[#D32F2F] inline-block shrink-0" />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-[#111827]">
                সারাদেশ: বিভাগ, জেলা ও উপজেলার সংবাদ
              </h2>
              <span className="bg-[#FEF2F2] text-[#D32F2F] border border-[#FECACA] text-[11px] font-bold px-2 py-0.5">
                ৬৪ জেলা • ৪৯৫ উপজেলা
              </span>
            </div>
            <p className="text-xs text-[#6B7280] mt-0.5">
              আপনার বিভাগ, জেলা ও উপজেলা নির্বাচন করে স্থানীয় জনপদের সর্বশেষ খবর পড়ুন
            </p>
          </div>
        </div>

        {/* 8 Division Quick Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={handleReset}
            className={`px-3 py-1.5 text-xs font-bold border whitespace-nowrap transition-colors cursor-pointer ${
              !selectedDivision
                ? 'bg-[#111827] text-white border-[#111827]'
                : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:border-[#111827]'
            }`}
          >
            সব বিভাগ
          </button>
          {BD_DIVISIONS.map((div) => (
            <button
              key={div.id}
              onClick={() => {
                setSelectedDivision(div.nameBn);
                setSelectedDistrict('');
                setSelectedUpazila('');
              }}
              className={`px-3 py-1.5 text-xs font-bold border whitespace-nowrap transition-colors cursor-pointer ${
                selectedDivision === div.nameBn
                  ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                  : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:border-[#111827]'
              }`}
            >
              {div.nameBn}
            </button>
          ))}
        </div>
      </div>

      {/* "আমার এলাকার খবর" — Cascading Division -> District -> Upazila Finder Bar */}
      <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 mb-6 rounded-[2px]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-editorial font-bold text-[#111827] shrink-0">
            <MapPin className="w-4 h-4 text-[#D32F2F]" />
            <span>আমার এলাকার খবর খুঁজুন:</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 lg:flex lg:items-center gap-2.5 flex-1">
            {/* 1. Division Select */}
            <select
              value={selectedDivision}
              onChange={(e) => {
                setSelectedDivision(e.target.value);
                setSelectedDistrict('');
                setSelectedUpazila('');
              }}
              className="bg-white border border-[#D1D5DB] focus:border-[#111827] px-3 py-2 text-xs font-bold text-[#111827] outline-none"
            >
              <option value="">১. বিভাগ নির্বাচন করুন (সব বিভাগ)</option>
              {BD_DIVISIONS.map((div) => (
                <option key={div.id} value={div.nameBn}>
                  {div.nameBn} বিভাগ ({toBengaliNumber(div.districts.length)} জেলা)
                </option>
              ))}
            </select>

            {/* 2. District Select */}
            <select
              value={selectedDistrict}
              onChange={(e) => {
                const distVal = e.target.value;
                setSelectedDistrict(distVal);
                setSelectedUpazila('');
                if (distVal && !selectedDivision) {
                  const parentDiv = BD_DIVISIONS.find((d) =>
                    d.districts.some((dist) => dist.nameBn === distVal)
                  );
                  if (parentDiv) setSelectedDivision(parentDiv.nameBn);
                }
              }}
              className="bg-white border border-[#D1D5DB] focus:border-[#111827] px-3 py-2 text-xs font-bold text-[#111827] outline-none"
            >
              <option value="">
                ২. জেলা নির্বাচন করুন ({toBengaliNumber(availableDistricts.length)} জেলা)
              </option>
              {availableDistricts.map((dist) => (
                <option key={dist.nameBn} value={dist.nameBn}>
                  {dist.nameBn} জেলা ({toBengaliNumber(dist.upazilas.length)} উপজেলা)
                </option>
              ))}
            </select>

            {/* 3. Upazila Select (Always enabled; shows all upazilas in selected District or Division) */}
            <select
              value={selectedUpazila}
              onChange={(e) => handleSelectUpazila(e.target.value)}
              className="bg-white border border-[#D1D5DB] focus:border-[#111827] px-3 py-2 text-xs font-bold text-[#111827] outline-none"
            >
              <option value="">
                {selectedDistrict
                  ? `৩. ${selectedDistrict} জেলার সকল উপজেলা (${toBengaliNumber(availableUpazilas.length)})`
                  : selectedDivision
                  ? `৩. ${selectedDivision} বিভাগের সকল উপজেলা (${toBengaliNumber(availableUpazilas.length)})`
                  : `৩. উপজেলা নির্বাচন করুন (${toBengaliNumber(availableUpazilas.length)})`}
              </option>
              {selectedDistrict
                ? availableUpazilas.map((upz) => (
                    <option key={upz} value={upz}>
                      {upz} উপজেলা
                    </option>
                  ))
                : availableDistricts.map((dist) => (
                    <optgroup key={dist.nameBn} label={`${dist.nameBn} জেলা`}>
                      {dist.upazilas.map((upz) => (
                        <option key={`${dist.nameBn}-${upz}`} value={upz}>
                          {upz} ({dist.nameBn})
                        </option>
                      ))}
                    </optgroup>
                  ))}
            </select>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {(selectedDivision || selectedDistrict || selectedUpazila) && (
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-1 px-3 py-2 bg-white border border-[#D1D5DB] hover:border-[#111827] text-xs font-bold text-[#4B5563] cursor-pointer"
                title="রিসেট করুন"
              >
                <RotateCcw className="w-3.5 h-3.5" /> রিসেট
              </button>
            )}
            <button
              onClick={() =>
                navigateTo({
                  type: 'countrywide',
                  division: selectedDivision || undefined,
                  district: selectedDistrict || undefined,
                  upazila: selectedUpazila || undefined,
                })
              }
              className="inline-flex items-center gap-1.5 bg-[#D32F2F] hover:bg-[#B71C1C] text-white text-xs font-bold px-4 py-2 transition-colors cursor-pointer"
            >
              <Search className="w-3.5 h-3.5" />
              <span>সব জেলা-উপজেলার খবর</span>
            </button>
          </div>
        </div>

        {/* When a Division is selected: Show ALL Districts AND ALL Upazilas inside that Division */}
        {selectedDivision && activeDivisionObj && (
          <div className="mt-4 pt-3.5 border-t border-[#E5E7EB] space-y-3">
            {/* Row 1: Districts of the selected Division */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-extrabold text-[#111827] mr-1">
                {selectedDivision} বিভাগের জেলাসমূহ ({toBengaliNumber(activeDivisionObj.districts.length)}):
              </span>
              <button
                type="button"
                onClick={() => {
                  setSelectedDistrict('');
                  setSelectedUpazila('');
                }}
                className={`px-2.5 py-1 text-xs font-bold border transition-colors cursor-pointer ${
                  !selectedDistrict
                    ? 'bg-[#111827] text-white border-[#111827]'
                    : 'bg-white text-[#374151] border-[#D1D5DB] hover:border-[#111827]'
                }`}
              >
                সব জেলা ({toBengaliNumber(activeDivisionObj.districts.length)})
              </button>
              {activeDivisionObj.districts.map((dist) => (
                <button
                  key={dist.nameBn}
                  type="button"
                  onClick={() => {
                    setSelectedDistrict(dist.nameBn);
                    setSelectedUpazila('');
                  }}
                  className={`px-2.5 py-1 text-xs font-bold border transition-colors cursor-pointer ${
                    selectedDistrict === dist.nameBn
                      ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                      : 'bg-white text-[#374151] border-[#D1D5DB] hover:border-[#111827]'
                  }`}
                >
                  {dist.nameBn} ({toBengaliNumber(dist.upazilas.length)})
                </button>
              ))}
            </div>

            {/* Row 2: All Upazilas inside the selected District OR all Upazilas across all Districts of the Division */}
            {selectedDistrict ? (
              <div className="bg-white border border-[#E5E7EB] p-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs font-extrabold text-[#D32F2F] mr-1">
                    {selectedDistrict} জেলার সকল উপজেলা ({toBengaliNumber(availableUpazilas.length)}টি):
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedUpazila('')}
                    className={`px-2.5 py-1 text-xs font-bold border cursor-pointer ${
                      !selectedUpazila
                        ? 'bg-[#111827] text-white border-[#111827]'
                        : 'bg-[#F9FAFB] text-[#4B5563] border-[#D1D5DB]'
                    }`}
                  >
                    সব উপজেলা
                  </button>
                  {availableUpazilas.map((upz) => (
                    <button
                      key={upz}
                      type="button"
                      onClick={() => setSelectedUpazila(upz)}
                      className={`px-2.5 py-1 text-xs font-bold border transition-colors cursor-pointer ${
                        selectedUpazila === upz
                          ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                          : 'bg-[#FEF2F2] text-[#111827] border-[#FECACA] hover:border-[#D32F2F]'
                      }`}
                    >
                      {upz}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-white border border-[#E5E7EB] p-3.5 space-y-2.5 max-h-72 overflow-y-auto">
                <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-1.5">
                  <span className="text-xs font-extrabold text-[#111827]">
                    {selectedDivision} বিভাগের জেলাভিত্তিক সকল উপজেলা ({toBengaliNumber(availableUpazilas.length)}টি):
                  </span>
                  <span className="text-[11px] text-[#6B7280]">
                    যেকোনো উপজেলায় ক্লিক করে খবর দেখুন
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {activeDivisionObj.districts.map((dist) => (
                    <div
                      key={dist.nameBn}
                      className="bg-[#F9FAFB] border border-[#E5E7EB] p-2.5"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedDistrict(dist.nameBn);
                          setSelectedUpazila('');
                        }}
                        className="text-xs font-extrabold text-[#D32F2F] hover:underline mb-1.5 block cursor-pointer"
                      >
                        📍 {dist.nameBn} জেলা ({toBengaliNumber(dist.upazilas.length)} উপজেলা):
                      </button>
                      <div className="flex flex-wrap gap-1">
                        {dist.upazilas.map((upz) => (
                          <button
                            key={upz}
                            type="button"
                            onClick={() => handleSelectUpazila(upz, dist.nameBn)}
                            className={`px-2 py-0.5 text-[11px] font-semibold border transition-colors cursor-pointer ${
                              selectedUpazila === upz
                                ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                                : 'bg-white text-[#1F2937] border-[#D1D5DB] hover:border-[#D32F2F] hover:text-[#D32F2F]'
                            }`}
                          >
                            {upz}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Filtered Status Notification if specific area has no exact match */}
      {filteredArticles.length === 0 &&
        (selectedDivision || selectedDistrict || selectedUpazila) && (
          <div className="mb-5 bg-amber-50 border border-amber-200 px-4 py-2.5 flex items-center justify-between text-xs text-amber-900">
            <span>
              নির্বাচিত এলাকার ({[selectedDivision, selectedDistrict, selectedUpazila].filter(Boolean).join(' > ')}) তাৎক্ষণিক সংবাদের পাশাপাশি সারাদেশের গুরুত্বপূর্ণ জেলা-উপজেলার সংবাদ নিচে দেখানো হচ্ছে।
            </span>
            <button
              onClick={handleReset}
              className="font-bold text-[#D32F2F] underline ml-2 cursor-pointer"
            >
              সব দেখুন
            </button>
          </div>
        )}

      {/* Main 12-Column Countrywide News Grid (Right Sidebar Division/District/Upazila Box Removed) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 6 Cols: Featured Division/District/Upazila Story */}
        {featuredLocal && (
          <div
            onClick={() =>
              navigateTo({ type: 'article', articleId: featuredLocal.id })
            }
            className="lg:col-span-6 group cursor-pointer bg-white border border-[#E5E7EB] hover:border-[#111827] p-4 rounded-[2px] flex flex-col justify-between transition-colors"
          >
            <div>
              <div className="relative aspect-16/9 w-full overflow-hidden bg-[#F3F4F6] mb-3.5">
                <img
                  src={featuredLocal.featuredImage}
                  alt={featuredLocal.headline}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2 mb-2">
                <LocationBadge article={featuredLocal} />
                <span className="text-xs text-[#6B7280] flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {featuredLocal.timeAgoBn}
                </span>
              </div>

              <h3 className="font-editorial font-bold text-xl sm:text-2xl text-[#111827] group-hover:text-[#D32F2F] leading-[1.38] mb-2.5 transition-colors">
                {featuredLocal.headline}
              </h3>

              <p className="text-sm text-[#4B5563] leading-relaxed line-clamp-3">
                {featuredLocal.summary}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#6B7280]">
              <span>{featuredLocal.reporter}</span>
              <span className="font-bold text-[#D32F2F]">বিস্তারিত পড়ুন →</span>
            </div>
          </div>
        )}

        {/* Right 6 Cols: 4 District/Upazila Cards */}
        <div className="lg:col-span-6 divide-y divide-[#E5E7EB] bg-white border border-[#E5E7EB] p-4 rounded-[2px]">
          {secondaryLocals.map((art) => (
            <article
              key={art.id}
              onClick={() => navigateTo({ type: 'article', articleId: art.id })}
              className="group cursor-pointer py-3.5 first:pt-0 last:pb-0 flex items-start gap-3.5"
            >
              <div className="w-32 sm:w-36 aspect-16/10 shrink-0 overflow-hidden bg-[#F3F4F6] border border-[#E5E7EB]">
                <img
                  src={art.featuredImage}
                  alt={art.headline}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="min-w-0 flex-1">
                <div className="mb-1">
                  <LocationBadge article={art} />
                </div>
                <h4 className="font-editorial font-bold text-sm sm:text-base text-[#111827] group-hover:text-[#D32F2F] leading-snug line-clamp-2 transition-colors">
                  {art.headline}
                </h4>
                <span className="text-[11px] text-[#6B7280] mt-1 block">
                  {art.reporter} • {art.timeAgoBn}
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Bottom 4-Card Strip of Other Divisions */}
      {moreLocals.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-5 border-t border-[#E5E7EB]">
          {moreLocals.map((art) => (
            <div
              key={art.id}
              onClick={() => navigateTo({ type: 'article', articleId: art.id })}
              className="group cursor-pointer bg-[#F9FAFB] hover:bg-white border border-[#E5E7EB] hover:border-[#111827] p-3.5 transition-colors"
            >
              <div className="mb-1.5">
                <LocationBadge article={art} />
              </div>
              <h4 className="font-editorial font-bold text-sm sm:text-base text-[#111827] group-hover:text-[#D32F2F] leading-snug line-clamp-2 mb-1">
                {art.headline}
              </h4>
              <span className="text-[11px] text-[#6B7280]">
                {art.reporter} • {art.timeAgoBn}
              </span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};

// ============================================================================
// 2. DEDICATED FULL PAGE: "সারাদেশ (বিভাগ • জেলা • উপজেলা সংবাদ)"
// ============================================================================
interface CountrywidePageProps {
  initialDivision?: string;
  initialDistrict?: string;
  initialUpazila?: string;
}

export const CountrywidePage: React.FC<CountrywidePageProps> = ({
  initialDivision = '',
  initialDistrict = '',
  initialUpazila = '',
}) => {
  const { publishedArticles, navigateTo } = useNews();

  const [selectedDivision, setSelectedDivision] = useState<string>(initialDivision);
  const [selectedDistrict, setSelectedDistrict] = useState<string>(initialDistrict);
  const [selectedUpazila, setSelectedUpazila] = useState<string>(initialUpazila);
  const [searchKeyword, setSearchKeyword] = useState<string>('');

  const activeDivisionObj = useMemo(
    () => BD_DIVISIONS.find((d) => d.nameBn === selectedDivision),
    [selectedDivision]
  );

  const availableDistricts = useMemo(() => {
    if (!selectedDivision) return BD_DIVISIONS.flatMap((d) => d.districts);
    return activeDivisionObj ? activeDivisionObj.districts : [];
  }, [selectedDivision, activeDivisionObj]);

  const activeDistrictObj = useMemo(
    () => availableDistricts.find((d) => d.nameBn === selectedDistrict),
    [availableDistricts, selectedDistrict]
  );

  const availableUpazilas = useMemo(() => {
    if (activeDistrictObj) return activeDistrictObj.upazilas;
    return availableDistricts.flatMap((d) => d.upazilas);
  }, [activeDistrictObj, availableDistricts]);

  const handleSelectUpazila = (upz: string, distName?: string) => {
    setSelectedUpazila(upz);
    if (!upz) return;
    if (distName) {
      setSelectedDistrict(distName);
      const parentDiv = BD_DIVISIONS.find((d) =>
        d.districts.some((dist) => dist.nameBn === distName)
      );
      if (parentDiv) setSelectedDivision(parentDiv.nameBn);
    } else {
      const found = findLocationByUpazila(upz);
      if (found) {
        if (!selectedDivision) setSelectedDivision(found.division);
        if (!selectedDistrict) setSelectedDistrict(found.district);
      }
    }
  };

  const allLocalArticles = useMemo(() => {
    return publishedArticles.filter(
      (a) =>
        a.category === 'countrywide' ||
        Boolean(a.division) ||
        Boolean(a.district) ||
        Boolean(a.upazila) ||
        a.category === 'national'
    );
  }, [publishedArticles]);

  const filteredArticles = useMemo(() => {
    return allLocalArticles.filter((art) => {
      if (selectedDivision) {
        const matchDiv =
          art.division === selectedDivision ||
          art.subcategory.includes(selectedDivision) ||
          art.headline.includes(selectedDivision) ||
          art.summary.includes(selectedDivision);
        if (!matchDiv) return false;
      }
      if (selectedDistrict) {
        const matchDist =
          art.district === selectedDistrict ||
          art.headline.includes(selectedDistrict) ||
          art.summary.includes(selectedDistrict);
        if (!matchDist) return false;
      }
      if (selectedUpazila) {
        const matchUpz =
          art.upazila === selectedUpazila ||
          art.headline.includes(selectedUpazila) ||
          art.summary.includes(selectedUpazila);
        if (!matchUpz) return false;
      }
      if (searchKeyword.trim()) {
        const q = searchKeyword.toLowerCase();
        const matchKw =
          art.headline.toLowerCase().includes(q) ||
          art.summary.toLowerCase().includes(q) ||
          (art.district && art.district.includes(q)) ||
          (art.upazila && art.upazila.includes(q));
        if (!matchKw) return false;
      }
      return true;
    });
  }, [
    allLocalArticles,
    selectedDivision,
    selectedDistrict,
    selectedUpazila,
    searchKeyword,
  ]);

  const handleReset = () => {
    setSelectedDivision('');
    setSelectedDistrict('');
    setSelectedUpazila('');
    setSearchKeyword('');
  };

  return (
    <div className="max-w-[1320px] mx-auto px-4 py-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-[#6B7280] mb-3">
        <button
          onClick={() => navigateTo({ type: 'home' })}
          className="hover:text-[#D32F2F] cursor-pointer"
        >
          প্রচ্ছদ
        </button>
        <span>/</span>
        <span
          onClick={handleReset}
          className="font-bold text-[#D32F2F] cursor-pointer"
        >
          সারাদেশ (বিভাগ • জেলা • উপজেলা)
        </span>
        {selectedDivision && (
          <>
            <span>/</span>
            <span className="font-bold text-[#111827]">
              {selectedDivision} বিভাগ
            </span>
          </>
        )}
        {selectedDistrict && (
          <>
            <span>/</span>
            <span className="font-bold text-[#111827]">
              {selectedDistrict} জেলা
            </span>
          </>
        )}
        {selectedUpazila && (
          <>
            <span>/</span>
            <span className="font-bold text-[#D32F2F]">
              {selectedUpazila} উপজেলা
            </span>
          </>
        )}
      </div>

      {/* Masthead Banner for Countrywide Page */}
      <div className="bg-white border-2 border-[#111827] p-5 sm:p-6 mb-6 rounded-[2px]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E5E7EB] pb-4 mb-4">
          <div className="flex items-center gap-3">
            <span className="w-3.5 h-9 bg-[#D32F2F] inline-block" />
            <div>
              <h1 className="font-editorial font-extrabold text-2xl sm:text-3xl text-[#111827]">
                সারাদেশের সংবাদ — বিভাগ, জেলা ও উপজেলা
              </h1>
              <p className="text-xs sm:text-sm text-[#6B7280]">
                বাংলাদেশের ৮টি বিভাগ, ৬৪টি জেলা এবং সকল উপজেলার তৃণমূল জনপদের সর্বশেষ খবর
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="bg-[#FEF2F2] text-[#D32F2F] border border-[#FECACA] px-3 py-1.5 text-xs font-bold flex items-center gap-1.5">
              <Building2 className="w-4 h-4" />
              {[selectedDivision, selectedDistrict, selectedUpazila]
                .filter(Boolean)
                .join(' • ') || 'সমগ্র বাংলাদেশ'}
            </span>
          </div>
        </div>

        {/* 8 Division Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 mb-4 border-b border-[#E5E7EB]">
          <button
            onClick={handleReset}
            className={`px-4 py-2 text-xs sm:text-sm font-bold border whitespace-nowrap transition-colors cursor-pointer ${
              !selectedDivision
                ? 'bg-[#111827] text-white border-[#111827]'
                : 'bg-[#F9FAFB] text-[#111827] border-[#E5E7EB] hover:border-[#111827]'
            }`}
          >
            সব বিভাগ (৮)
          </button>
          {BD_DIVISIONS.map((div) => (
            <button
              key={div.id}
              onClick={() => {
                setSelectedDivision(div.nameBn);
                setSelectedDistrict('');
                setSelectedUpazila('');
              }}
              className={`px-4 py-2 text-xs sm:text-sm font-bold border whitespace-nowrap transition-colors cursor-pointer ${
                selectedDivision === div.nameBn
                  ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                  : 'bg-[#F9FAFB] text-[#111827] border-[#E5E7EB] hover:border-[#111827]'
              }`}
            >
              {div.nameBn} বিভাগ ({toBengaliNumber(div.districts.length)} জেলা)
            </button>
          ))}
        </div>

        {/* Cascading Selector Grid: Division -> District -> Upazila + Keyword */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div>
            <label className="block text-[11px] font-bold text-[#6B7280] mb-1">
              বিভাগ (Division)
            </label>
            <select
              value={selectedDivision}
              onChange={(e) => {
                setSelectedDivision(e.target.value);
                setSelectedDistrict('');
                setSelectedUpazila('');
              }}
              className="w-full bg-[#F9FAFB] border border-[#D1D5DB] px-3 py-2 text-xs font-bold text-[#111827] outline-none"
            >
              <option value="">সকল বিভাগ</option>
              {BD_DIVISIONS.map((div) => (
                <option key={div.id} value={div.nameBn}>
                  {div.nameBn} বিভাগ ({toBengaliNumber(div.districts.length)} জেলা)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-[#6B7280] mb-1">
              জেলা (District)
            </label>
            <select
              value={selectedDistrict}
              onChange={(e) => {
                const distVal = e.target.value;
                setSelectedDistrict(distVal);
                setSelectedUpazila('');
                if (distVal && !selectedDivision) {
                  const parentDiv = BD_DIVISIONS.find((d) =>
                    d.districts.some((dist) => dist.nameBn === distVal)
                  );
                  if (parentDiv) setSelectedDivision(parentDiv.nameBn);
                }
              }}
              className="w-full bg-[#F9FAFB] border border-[#D1D5DB] px-3 py-2 text-xs font-bold text-[#111827] outline-none"
            >
              <option value="">
                সকল জেলা ({toBengaliNumber(availableDistricts.length)})
              </option>
              {availableDistricts.map((dist) => (
                <option key={dist.nameBn} value={dist.nameBn}>
                  {dist.nameBn} জেলা ({toBengaliNumber(dist.upazilas.length)} উপজেলা)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-[#6B7280] mb-1">
              উপজেলা / থানা (Upazila)
            </label>
            <select
              value={selectedUpazila}
              onChange={(e) => handleSelectUpazila(e.target.value)}
              className="w-full bg-[#F9FAFB] border border-[#D1D5DB] px-3 py-2 text-xs font-bold text-[#111827] outline-none"
            >
              <option value="">
                {selectedDistrict
                  ? `${selectedDistrict}-এর সকল উপজেলা (${toBengaliNumber(availableUpazilas.length)})`
                  : selectedDivision
                  ? `${selectedDivision} বিভাগের সকল উপজেলা (${toBengaliNumber(availableUpazilas.length)})`
                  : `সকল উপজেলা (${toBengaliNumber(availableUpazilas.length)})`}
              </option>
              {selectedDistrict
                ? availableUpazilas.map((upz) => (
                    <option key={upz} value={upz}>
                      {upz} উপজেলা
                    </option>
                  ))
                : availableDistricts.map((dist) => (
                    <optgroup key={dist.nameBn} label={`${dist.nameBn} জেলা`}>
                      {dist.upazilas.map((upz) => (
                        <option key={`${dist.nameBn}-${upz}`} value={upz}>
                          {upz} ({dist.nameBn})
                        </option>
                      ))}
                    </optgroup>
                  ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-[#6B7280] mb-1">
              এলাকা বা বিষয় খুঁজুন
            </label>
            <input
              type="text"
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              placeholder="জেলা/উপজেলার নাম লিখুন..."
              className="w-full bg-[#F9FAFB] border border-[#D1D5DB] px-3 py-2 text-xs text-[#111827] outline-none"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleReset}
              className="w-full bg-[#111827] hover:bg-[#D32F2F] text-white text-xs font-bold py-2 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> ফিল্টার রিসেট করুন
            </button>
          </div>
        </div>

        {/* Interactive District & All Upazilas Directory when Division is selected */}
        {selectedDivision && activeDivisionObj && (
          <div className="mt-4 pt-4 border-t border-[#E5E7EB] space-y-3.5">
            {/* Districts Row */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-extrabold text-[#111827] mr-1">
                {selectedDivision} বিভাগের জেলাসমূহ ({toBengaliNumber(activeDivisionObj.districts.length)}):
              </span>
              <button
                type="button"
                onClick={() => {
                  setSelectedDistrict('');
                  setSelectedUpazila('');
                }}
                className={`px-2.5 py-1 text-xs font-bold border transition-colors cursor-pointer ${
                  !selectedDistrict
                    ? 'bg-[#111827] text-white border-[#111827]'
                    : 'bg-white text-[#374151] border-[#D1D5DB] hover:border-[#111827]'
                }`}
              >
                সব জেলা ({toBengaliNumber(activeDivisionObj.districts.length)})
              </button>
              {activeDivisionObj.districts.map((dist) => (
                <button
                  key={dist.nameBn}
                  type="button"
                  onClick={() => {
                    setSelectedDistrict(dist.nameBn);
                    setSelectedUpazila('');
                  }}
                  className={`px-2.5 py-1 text-xs font-bold border transition-colors cursor-pointer ${
                    selectedDistrict === dist.nameBn
                      ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                      : 'bg-white text-[#374151] border-[#D1D5DB] hover:border-[#111827]'
                  }`}
                >
                  {dist.nameBn} ({toBengaliNumber(dist.upazilas.length)})
                </button>
              ))}
            </div>

            {/* Upazilas Section: Shows either selected District's upazilas OR all Upazilas of the Division grouped by District */}
            {selectedDistrict ? (
              <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-3.5">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs font-extrabold text-[#D32F2F] mr-1">
                    {selectedDistrict} জেলার সকল উপজেলা ({toBengaliNumber(availableUpazilas.length)}টি):
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedUpazila('')}
                    className={`px-2.5 py-1 text-xs font-bold border cursor-pointer ${
                      !selectedUpazila
                        ? 'bg-[#111827] text-white border-[#111827]'
                        : 'bg-white text-[#374151] border-[#D1D5DB]'
                    }`}
                  >
                    সব উপজেলা
                  </button>
                  {availableUpazilas.map((upz) => (
                    <button
                      key={upz}
                      type="button"
                      onClick={() => setSelectedUpazila(upz)}
                      className={`px-2.5 py-1 text-xs font-bold border transition-colors cursor-pointer ${
                        selectedUpazila === upz
                          ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                          : 'bg-white text-[#111827] border-[#D1D5DB] hover:border-[#D32F2F] hover:text-[#D32F2F]'
                      }`}
                    >
                      {upz}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-2">
                  <span className="text-xs sm:text-sm font-extrabold text-[#111827]">
                    {selectedDivision} বিভাগের অন্তর্গত সকল জেলা ও উপজেলার তালিকা ({toBengaliNumber(availableUpazilas.length)}টি উপজেলা):
                  </span>
                  <span className="text-[11px] text-[#6B7280]">
                    উপজেলায় ক্লিক করে সরাসরি সংবাদ দেখুন
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {activeDivisionObj.districts.map((dist) => (
                    <div
                      key={dist.nameBn}
                      className="bg-white border border-[#E5E7EB] p-3"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedDistrict(dist.nameBn);
                          setSelectedUpazila('');
                        }}
                        className="text-xs font-extrabold text-[#D32F2F] hover:underline mb-2 block cursor-pointer"
                      >
                        📍 {dist.nameBn} জেলা ({toBengaliNumber(dist.upazilas.length)}টি উপজেলা)
                      </button>
                      <div className="flex flex-wrap gap-1">
                        {dist.upazilas.map((upz) => (
                          <button
                            key={upz}
                            type="button"
                            onClick={() => handleSelectUpazila(upz, dist.nameBn)}
                            className={`px-2 py-0.5 text-[11px] font-semibold border transition-colors cursor-pointer ${
                              selectedUpazila === upz
                                ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                                : 'bg-[#F9FAFB] text-[#1F2937] border-[#E5E7EB] hover:border-[#D32F2F] hover:text-[#D32F2F]'
                            }`}
                          >
                            {upz}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Content & Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8">
          <SectionHeader
            titleBn={
              [selectedDivision, selectedDistrict, selectedUpazila]
                .filter(Boolean)
                .join(' • ') || 'সারাদেশের সর্বশেষ সংবাদ'
            }
            subtitleBn={`মোট ${toBengaliNumber(
              filteredArticles.length > 0
                ? filteredArticles.length
                : allLocalArticles.length
            )}টি প্রতিবেদন পাওয়া গেছে`}
          />

          {filteredArticles.length === 0 && (
            <div className="mb-6 bg-amber-50 border border-amber-200 p-4 text-xs text-amber-900">
              নির্বাচিত উপজেলা/জেলার জন্য এই মুহূর্তে আলাদা প্রতিবেদন যুক্ত করা হয়নি। নিচে সারাদেশের অন্যান্য জেলা ও উপজেলার সর্বশেষ প্রতিবেদন দেখানো হচ্ছে। (অ্যাডমিন প্যানেল থেকে যেকোনো জেলা-উপজেলার খবর যোগ করতে পারবেন)।
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {(filteredArticles.length > 0
              ? filteredArticles
              : allLocalArticles
            ).map((art) => (
              <article
                key={art.id}
                onClick={() =>
                  navigateTo({ type: 'article', articleId: art.id })
                }
                className="group cursor-pointer bg-white border border-[#E5E7EB] hover:border-[#111827] rounded-[2px] overflow-hidden flex flex-col justify-between transition-colors"
              >
                <div>
                  <div className="aspect-16/9 w-full overflow-hidden bg-[#F3F4F6]">
                    <img
                      src={art.featuredImage}
                      alt={art.headline}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <LocationBadge article={art} />
                      <span className="text-[11px] text-[#6B7280]">
                        {art.timeAgoBn}
                      </span>
                    </div>
                    <h3 className="font-editorial font-bold text-base sm:text-lg text-[#111827] group-hover:text-[#D32F2F] leading-snug mb-2 transition-colors">
                      {art.headline}
                    </h3>
                    <p className="text-xs text-[#4B5563] line-clamp-2 leading-relaxed">
                      {art.summary}
                    </p>
                  </div>
                </div>
                <div className="px-4 py-2.5 bg-[#F9FAFB] border-t border-[#E5E7EB] flex items-center justify-between text-[11px] text-[#6B7280]">
                  <span>{art.reporter}</span>
                  <span className="font-bold text-[#D32F2F]">বিস্তারিত →</span>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-4 space-y-6">
          <AdSlot slot="sidebar-ad" />
          <MostReadWidget />
        </aside>
      </div>
    </div>
  );
};
