import React, { useEffect, useRef, useState } from 'react';
import {
  Download,
  Image as ImageIcon,
  Upload,
  Sparkles,
  X,
  Sliders,
  Type,
  UserCheck,
  RefreshCw,
  CheckCircle2,
  Copy,
} from 'lucide-react';
import { Article } from '../types/news';
import { useNews } from '../context/NewsContext';

export type KalbelaTemplateStyle =
  | 'kalbela-classic'
  | 'kalbela-breaking'
  | 'kalbela-quote'
  | 'kalbela-gold';

interface PhotocardGeneratorProps {
  article?: Article;
  isModal?: boolean;
  onClose?: () => void;
}

// Helper to split headline automatically into a yellow highlight lead + main white text
function splitHeadlineForHighlight(headline: string): {
  highlight: string;
  main: string;
} {
  const clean = headline.trim();
  // If headline has a colon or dash, split there
  const colonIdx = clean.indexOf(':');
  if (colonIdx > 3 && colonIdx < 45) {
    return {
      highlight: clean.slice(0, colonIdx + 1).trim(),
      main: clean.slice(colonIdx + 1).trim(),
    };
  }
  const words = clean.split(/\s+/);
  if (words.length >= 6) {
    const splitPoint = Math.min(4, Math.ceil(words.length * 0.38));
    return {
      highlight: words.slice(0, splitPoint).join(' '),
      main: words.slice(splitPoint).join(' '),
    };
  }
  return {
    highlight: '',
    main: clean,
  };
}

// Canvas word-wrap helper
function wrapCanvasText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const words = text.trim().split(/\s+/);
  const lines: string[] = [];
  let current = '';

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const test = current ? `${current} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = test;
    }
  }
  if (current) lines.push(current);
  return lines;
}

export const PhotocardGeneratorModal: React.FC<PhotocardGeneratorProps> = ({
  article,
  isModal = true,
  onClose,
}) => {
  const { publishedArticles, siteSettings } = useNews();
  const defaultArticle = article || publishedArticles[0];

  const [selectedArticleId, setSelectedArticleId] = useState<string>(
    defaultArticle?.id || ''
  );

  const initialSplit = splitHeadlineForHighlight(
    defaultArticle?.headline ||
      'ঢাকা-চট্টগ্রাম অর্থনৈতিক করিডোরে নতুন হাইস্পিড লজিস্টিকস হাব স্থাপনের চূড়ান্ত অনুমোদন'
  );

  const [template, setTemplate] =
    useState<KalbelaTemplateStyle>('kalbela-classic');
  const [categoryBadge, setCategoryBadge] = useState<string>(
    defaultArticle?.categoryNameBn || 'জাতীয়'
  );
  const [dateBadge, setDateBadge] = useState<string>('২৬ সেপ্টেম্বর ২০২৬');
  const [highlightText, setHighlightText] = useState<string>(
    initialSplit.highlight
  );
  const [mainHeadline, setMainHeadline] = useState<string>(initialSplit.main);
  const [speakerName, setSpeakerName] = useState<string>(
    defaultArticle?.pullQuote
      ? defaultArticle.reporter
      : ''
  );
  const [speakerRole, setSpeakerRole] = useState<string>('');
  const [footerCallout, setFooterCallout] = useState<string>(
    'বিস্তারিত কমেন্টে'
  );
  const [photoUrl, setPhotoUrl] = useState<string>(
    defaultArticle?.featuredImage || ''
  );
  const [photoZoom, setPhotoZoom] = useState<number>(105);
  const [photoOffsetY, setPhotoOffsetY] = useState<number>(0);
  const [fontSizeScale, setFontSizeScale] = useState<number>(52);
  const [copiedImg, setCopiedImg] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [loadedPhoto, setLoadedPhoto] = useState<HTMLImageElement | null>(null);
  const [loadedLogo, setLoadedLogo] = useState<HTMLImageElement | null>(null);

  // When user picks another article in Admin studio mode
  const handleSelectArticle = (artId: string) => {
    setSelectedArticleId(artId);
    const found = publishedArticles.find((a) => a.id === artId);
    if (found) {
      const sp = splitHeadlineForHighlight(found.headline);
      setHighlightText(sp.highlight);
      setMainHeadline(sp.main);
      setCategoryBadge(found.categoryNameBn);
      setPhotoUrl(found.featuredImage);
      setSpeakerName('');
      setSpeakerRole('');
    }
  };

  // Load main news photo safely for Canvas
  useEffect(() => {
    if (!photoUrl) {
      setLoadedPhoto(null);
      return;
    }
    let active = true;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (active) setLoadedPhoto(img);
    };
    img.onerror = () => {
      if (active) setLoadedPhoto(null);
    };
    img.src = photoUrl;
    return () => {
      active = false;
    };
  }, [photoUrl]);

  // Load custom site logo if uploaded
  useEffect(() => {
    if (!siteSettings.logoUrl) {
      setLoadedLogo(null);
      return;
    }
    let active = true;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (active) setLoadedLogo(img);
    };
    img.onerror = () => {
      if (active) setLoadedLogo(null);
    };
    img.src = siteSettings.logoUrl;
    return () => {
      active = false;
    };
  }, [siteSettings.logoUrl]);

  // Handle custom image upload from user's device
  const handleUploadPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhotoUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Draw the Kalbela-style 1080x1080 Photocard on Canvas whenever state changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 1080;
    const H = 1080;
    ctx.clearRect(0, 0, W, H);

    // Colors by template
    const isBreaking = template === 'kalbela-breaking';
    const isQuote = template === 'kalbela-quote';
    const isGold = template === 'kalbela-gold';

    const primaryRed = isGold
      ? '#B45309'
      : isBreaking
      ? '#C8102E'
      : '#D32F2F';
    const darkBg = isGold
      ? '#0F141C'
      : isBreaking
      ? '#1F0508'
      : '#120507';
    const accentYellow = '#FFE600';

    // 1. BASE BACKGROUND
    ctx.fillStyle = darkBg;
    ctx.fillRect(0, 0, W, H);

    // 2. DRAW NEWS PHOTOGRAPH
    if (isBreaking) {
      // Framed Photo inside Crimson Border
      const frameGrad = ctx.createLinearGradient(0, 0, W, H);
      frameGrad.addColorStop(0, '#990B1E');
      frameGrad.addColorStop(0.5, '#3B040A');
      frameGrad.addColorStop(1, '#140305');
      ctx.fillStyle = frameGrad;
      ctx.fillRect(0, 0, W, H);

      // Photo Box: x=44, y=126, w=992, h=510
      const px = 44;
      const py = 126;
      const pw = 992;
      const ph = 510;

      ctx.save();
      ctx.beginPath();
      ctx.rect(px, py, pw, ph);
      ctx.clip();

      if (loadedPhoto) {
        const scale = Math.max(pw / loadedPhoto.width, ph / loadedPhoto.height) * (photoZoom / 100);
        const dw = loadedPhoto.width * scale;
        const dh = loadedPhoto.height * scale;
        const dx = px + (pw - dw) / 2;
        const dy = py + (ph - dh) / 2 + photoOffsetY * 2;
        ctx.drawImage(loadedPhoto, dx, dy, dw, dh);
      } else {
        ctx.fillStyle = '#27272A';
        ctx.fillRect(px, py, pw, ph);
      }

      // Subtle inner bottom shadow inside photo frame
      const innerGrad = ctx.createLinearGradient(0, py + ph - 160, 0, py + ph);
      innerGrad.addColorStop(0, 'rgba(0,0,0,0)');
      innerGrad.addColorStop(1, 'rgba(0,0,0,0.75)');
      ctx.fillStyle = innerGrad;
      ctx.fillRect(px, py + ph - 160, pw, 160);
      ctx.restore();

      // Crisp yellow/white border around photo
      ctx.lineWidth = 4;
      ctx.strokeStyle = accentYellow;
      ctx.strokeRect(px, py, pw, ph);
    } else {
      // Full-bleed upper photo (Kalbela Classic / Quote / Gold)
      const photoH = 680;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, W, photoH);
      ctx.clip();

      if (loadedPhoto) {
        const scale =
          Math.max(W / loadedPhoto.width, photoH / loadedPhoto.height) *
          (photoZoom / 100);
        const dw = loadedPhoto.width * scale;
        const dh = loadedPhoto.height * scale;
        const dx = (W - dw) / 2;
        const dy = (photoH - dh) / 2 + photoOffsetY * 2;
        ctx.drawImage(loadedPhoto, dx, dy, dw, dh);
      } else {
        const fallbackGrad = ctx.createLinearGradient(0, 0, W, photoH);
        fallbackGrad.addColorStop(0, '#1F2937');
        fallbackGrad.addColorStop(1, '#111827');
        ctx.fillStyle = fallbackGrad;
        ctx.fillRect(0, 0, W, photoH);
      }

      // Top dark vignette so logo & date are always readable
      const topVig = ctx.createLinearGradient(0, 0, 0, 155);
      topVig.addColorStop(0, 'rgba(0,0,0,0.75)');
      topVig.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = topVig;
      ctx.fillRect(0, 0, W, 155);

      // Kalbela signature dramatic bottom gradient transition into the dark crimson/charcoal card body
      const botVig = ctx.createLinearGradient(0, 320, 0, photoH);
      botVig.addColorStop(0, 'rgba(18, 5, 7, 0)');
      botVig.addColorStop(0.55, 'rgba(18, 5, 7, 0.72)');
      botVig.addColorStop(1, darkBg);
      ctx.fillStyle = botVig;
      ctx.fillRect(0, 320, W, photoH - 320);
      ctx.restore();
    }

    // 3. TOP BAR: KALBELA-STYLE ANGLED CATEGORY/DATE RIBBON + LOGO BADGE
    // Top thin accent strip
    ctx.fillStyle = primaryRed;
    ctx.fillRect(0, 0, W, 12);
    ctx.fillStyle = accentYellow;
    ctx.fillRect(0, 12, 340, 4);

    // Left Date & Category Ribbon
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(44, 34);
    ctx.lineTo(390, 34);
    ctx.lineTo(368, 96);
    ctx.lineTo(44, 96);
    ctx.closePath();
    ctx.fillStyle = primaryRed;
    ctx.fill();

    // Yellow left bar on ribbon
    ctx.fillStyle = accentYellow;
    ctx.fillRect(44, 34, 10, 62);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 25px "Hind Siliguri", "Noto Serif Bengali", sans-serif';
    ctx.fillText(`${categoryBadge}  •  ${dateBadge}`, 72, 74);
    ctx.restore();

    // Right Brand Logo Pill Box (White card with red bottom accent like Kalbela)
    const logoBoxW = 295;
    const logoBoxH = 74;
    const logoBoxX = W - 44 - logoBoxW;
    const logoBoxY = 28;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(logoBoxX, logoBoxY, logoBoxW, logoBoxH);
    ctx.fillStyle = primaryRed;
    ctx.fillRect(logoBoxX, logoBoxY + logoBoxH - 6, logoBoxW, 6);

    if (loadedLogo) {
      const maxLW = logoBoxW - 32;
      const maxLH = logoBoxH - 20;
      const lScale = Math.min(
        maxLW / loadedLogo.width,
        maxLH / loadedLogo.height
      );
      const lw = loadedLogo.width * lScale;
      const lh = loadedLogo.height * lScale;
      ctx.drawImage(
        loadedLogo,
        logoBoxX + (logoBoxW - lw) / 2,
        logoBoxY + (logoBoxH - 6 - lh) / 2,
        lw,
        lh
      );
    } else {
      // Draw bd7news.com editorial wordmark
      ctx.font = '900 40px Georgia, serif';
      ctx.fillStyle = '#111827';
      ctx.fillText('bd', logoBoxX + 30, logoBoxY + 50);
      ctx.fillStyle = '#D32F2F';
      ctx.fillText('7', logoBoxX + 84, logoBoxY + 50);
      ctx.fillStyle = '#111827';
      ctx.fillText('news', logoBoxX + 110, logoBoxY + 50);
      ctx.font = 'bold 22px sans-serif';
      ctx.fillStyle = '#D32F2F';
      ctx.fillText('.com', logoBoxX + 214, logoBoxY + 50);
    }

    // 4. KALBELA SIGNATURE MIDDLE ACCENT DIVIDER / QUOTE ICON
    const dividerY = isBreaking ? 636 : 565;

    if (isQuote) {
      // Giant Kalbela Quote Badge
      ctx.save();
      ctx.fillStyle = accentYellow;
      ctx.beginPath();
      ctx.arc(96, dividerY, 44, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#111827';
      ctx.font = '900 78px Georgia, serif';
      ctx.fillText('“', 70, dividerY + 28);
      ctx.restore();

      // Horizontal red-gold line next to quote circle
      ctx.fillStyle = primaryRed;
      ctx.fillRect(156, dividerY - 4, W - 200, 8);
    } else {
      // Angled Kalbela Kicker Ribbon Bar
      ctx.save();
      // Full width subtle line
      ctx.fillStyle = 'rgba(255,255,255,0.16)';
      ctx.fillRect(44, dividerY, W - 88, 3);

      // Angled crimson + yellow bar on left
      ctx.beginPath();
      ctx.moveTo(44, dividerY - 22);
      ctx.lineTo(290, dividerY - 22);
      ctx.lineTo(272, dividerY + 22);
      ctx.lineTo(44, dividerY + 22);
      ctx.closePath();
      ctx.fillStyle = primaryRed;
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(298, dividerY - 22);
      ctx.lineTo(322, dividerY - 22);
      ctx.lineTo(304, dividerY + 22);
      ctx.lineTo(280, dividerY + 22);
      ctx.closePath();
      ctx.fillStyle = accentYellow;
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 24px "Hind Siliguri", sans-serif';
      ctx.fillText(
        isBreaking ? 'ব্রেকিং নিউজ' : siteSettings.taglineBn || 'সত্য সংবাদ সবসময়',
        64,
        dividerY + 8
      );
      ctx.restore();
    }

    // 5. KALBELA DUAL-TONE HEADLINE (Yellow Highlight + Crisp White Main Text)
    let textCursorY = dividerY + 78;
    const maxTextWidth = W - 104; // 52px padding each side

    // 5A. Yellow Highlight Lead Line(s)
    if (highlightText.trim()) {
      ctx.font = `800 ${fontSizeScale}px "Hind Siliguri", "Noto Serif Bengali", sans-serif`;
      const hLines = wrapCanvasText(ctx, highlightText.trim(), maxTextWidth);

      for (const hLine of hLines.slice(0, 2)) {
        // Draw dark drop shadow for crispness
        ctx.fillStyle = 'rgba(0,0,0,0.65)';
        ctx.fillText(hLine, 54, textCursorY + 3);

        // Kalbela bright yellow highlight text
        ctx.fillStyle = accentYellow;
        ctx.fillText(hLine, 52, textCursorY);
        textCursorY += fontSizeScale + 18;
      }
    }

    // 5B. Main White Headline Line(s)
    if (mainHeadline.trim()) {
      ctx.font = `800 ${fontSizeScale}px "Hind Siliguri", "Noto Serif Bengali", sans-serif`;
      const mLines = wrapCanvasText(ctx, mainHeadline.trim(), maxTextWidth);

      for (const mLine of mLines.slice(0, 4)) {
        if (textCursorY > 925) break;
        ctx.fillStyle = 'rgba(0,0,0,0.65)';
        ctx.fillText(mLine, 54, textCursorY + 3);

        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(mLine, 52, textCursorY);
        textCursorY += fontSizeScale + 18;
      }
    }

    // 6. OPTIONAL SPEAKER / ATTRIBUTION PILL (বক্তার নাম ও পদবি - কালবেলা স্টাইল)
    if (speakerName.trim()) {
      const pillY = Math.min(textCursorY + 6, 905);
      ctx.save();
      ctx.fillStyle = 'rgba(255, 230, 0, 0.14)';
      ctx.fillRect(52, pillY - 34, W - 104, 52);

      ctx.fillStyle = accentYellow;
      ctx.fillRect(52, pillY - 34, 8, 52);

      ctx.font = 'bold 27px "Hind Siliguri", sans-serif';
      ctx.fillStyle = accentYellow;
      const speakerLabel = speakerRole.trim()
        ? `— ${speakerName.trim()}, ${speakerRole.trim()}`
        : `— ${speakerName.trim()}`;
      ctx.fillText(speakerLabel, 76, pillY);
      ctx.restore();
    }

    // 7. KALBELA SIGNATURE BOTTOM FOOTER RIBBON (y = 980 to 1080)
    const footY = 982;
    const footH = H - footY;

    // Dark base bar
    ctx.fillStyle = '#090D16';
    ctx.fillRect(0, footY, W, footH);

    // Top yellow-red border above footer
    ctx.fillStyle = accentYellow;
    ctx.fillRect(0, footY, W, 4);

    // Left Angled Crimson Red Callout Box ("বিস্তারিত কমেন্টে")
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, footY + 4);
    ctx.lineTo(430, footY + 4);
    ctx.lineTo(398, H);
    ctx.lineTo(0, H);
    ctx.closePath();
    ctx.fillStyle = primaryRed;
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 30px "Hind Siliguri", sans-serif';
    ctx.fillText(`▸ ${footerCallout}`, 44, footY + 62);
    ctx.restore();

    // Right Social & Website Bar
    ctx.fillStyle = accentYellow;
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText('🌐 www.bd7news.com', 445, footY + 61);

    ctx.fillStyle = '#E5E7EB';
    ctx.font = 'bold 24px sans-serif';
    ctx.fillText('  |   f /bd7news', 760, footY + 60);
  }, [
    template,
    categoryBadge,
    dateBadge,
    highlightText,
    mainHeadline,
    speakerName,
    speakerRole,
    footerCallout,
    loadedPhoto,
    loadedLogo,
    photoZoom,
    photoOffsetY,
    fontSizeScale,
    siteSettings.taglineBn,
  ]);

  const handleDownloadPng = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `bd7news-photocard-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleCopyImage = async () => {
    const canvas = canvasRef.current;
    if (!canvas || !navigator.clipboard || !('ClipboardItem' in window)) return;
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      try {
        await navigator.clipboard.write([
          new ClipboardItem({ 'image/png': blob }),
        ]);
        setCopiedImg(true);
        setTimeout(() => setCopiedImg(false), 2500);
      } catch {}
    }, 'image/png');
  };

  const studioContent = (
    <div className="bg-white border-2 border-[#111827] w-full max-w-6xl mx-auto shadow-2xl overflow-hidden">
      {/* Studio Top Bar */}
      <div className="bg-[#111827] text-white px-5 py-3.5 flex items-center justify-between border-b-2 border-[#D32F2F]">
        <div className="flex items-center gap-2.5">
          <span className="bg-[#D32F2F] text-white text-[11px] font-bold px-2.5 py-0.5 uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> ফটোকার্ড ডাউনলোড
          </span>
          <h2 className="font-editorial font-extrabold text-lg sm:text-xl text-white">
            সোশ্যাল মিডিয়া ফটোকার্ড ডাউনলোড
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleDownloadPng}
            className="bg-[#D32F2F] hover:bg-[#B71C1C] text-white font-bold text-xs px-4 py-2 flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-4 h-4" /> ফটোকার্ড ডাউনলোড
          </button>
          {isModal && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 bg-white/10 hover:bg-[#D32F2F] text-white transition-colors cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12">
        {/* LEFT COLUMN: LIVE 1080x1080 CANVAS PREVIEW (6 Cols) */}
        <div className="lg:col-span-6 bg-[#18181B] p-4 sm:p-6 flex flex-col items-center justify-center border-b lg:border-b-0 lg:border-r border-[#E5E7EB]">
          <div className="w-full max-w-[460px] aspect-square shadow-2xl border border-gray-700 bg-black overflow-hidden">
            <canvas
              ref={canvasRef}
              width={1080}
              height={1080}
              className="w-full h-full object-contain block"
            />
          </div>

          <div className="w-full max-w-[460px] mt-4 flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs text-gray-300 font-mono-num">
              রেজোলিউশন: ১০৮০ × ১০৮০ px (HD Square)
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopyImage}
                className="bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-3.5 py-2 flex items-center gap-1.5 cursor-pointer"
              >
                {copiedImg ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>ইমেজ কপি হয়েছে!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>কপি ইমেজ</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleDownloadPng}
                className="bg-[#FFE600] hover:bg-yellow-400 text-[#111827] text-xs font-extrabold px-4 py-2 flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4" /> ফটোকার্ড ডাউনলোড
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: KALBELA CUSTOMIZATION CONTROLS (6 Cols) */}
        <div className="lg:col-span-6 p-5 sm:p-6 space-y-4 max-h-[82vh] overflow-y-auto">
          {/* Article Selector (when used inside Admin CMS or switching news) */}
          {!article && (
            <div className="bg-[#F9FAFB] p-3.5 border border-[#E5E7EB]">
              <label className="block text-xs font-bold text-[#111827] mb-1.5">
                সংবাদ নির্বাচন করুন (অটো-ফিল ফটোকার্ড):
              </label>
              <select
                value={selectedArticleId}
                onChange={(e) => handleSelectArticle(e.target.value)}
                className="w-full border border-[#D1D5DB] bg-white px-3 py-2 text-xs font-bold text-[#111827] outline-none"
              >
                {publishedArticles.map((art) => (
                  <option key={art.id} value={art.id}>
                    [{art.categoryNameBn}] {art.headline}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* 1. Template Switcher (4 Styles) */}
          <div>
            <label className="block text-xs font-bold text-[#111827] mb-2">
              ১. ফটোকার্ড ডিজাইন স্টাইল নির্বাচন করুন:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                {
                  id: 'kalbela-classic',
                  label: 'ক্লাসিক কার্ড',
                  desc: 'লাল-হলুদ সিগনেচার',
                },
                {
                  id: 'kalbela-breaking',
                  label: 'ব্রেকিং কার্ড',
                  desc: 'ক্রিমসন বর্ডার ফ্রেম',
                },
                {
                  id: 'kalbela-quote',
                  label: 'বক্তব্য / কোট কার্ড',
                  desc: 'বক্তার উক্তি ও নাম',
                },
                {
                  id: 'kalbela-gold',
                  label: 'ডার্ক এডিটোরিয়াল',
                  desc: 'বিশেষ প্রতিবেদন',
                },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTemplate(t.id as KalbelaTemplateStyle)}
                  className={`p-2.5 border text-left transition-all cursor-pointer ${
                    template === t.id
                      ? 'bg-[#111827] text-white border-[#D32F2F] ring-2 ring-[#D32F2F]/30'
                      : 'bg-[#F9FAFB] text-[#111827] border-[#E5E7EB] hover:border-[#111827]'
                  }`}
                >
                  <div className="text-xs font-extrabold">{t.label}</div>
                  <div
                    className={`text-[10px] ${
                      template === t.id ? 'text-[#FFE600]' : 'text-[#6B7280]'
                    }`}
                  >
                    {t.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Yellow Highlight Lead + Main White Headline */}
          <div className="space-y-3 bg-[#F9FAFB] p-4 border border-[#E5E7EB]">
            <div>
              <label className="flex items-center justify-between text-xs font-bold text-[#111827] mb-1">
                <span className="flex items-center gap-1.5">
                  <Type className="w-3.5 h-3.5 text-[#D32F2F]" />
                  হলুদ হাইলাইট অংশ (প্রথম লাইন হাইলাইট)
                </span>
                <span className="bg-[#111827] text-[#FFE600] px-2 py-0.5 text-[10px]">
                  #FFE600 Yellow
                </span>
              </label>
              <input
                type="text"
                value={highlightText}
                onChange={(e) => setHighlightText(e.target.value)}
                placeholder="যেমন: ঢাকা-চট্টগ্রাম অর্থনৈতিক করিডোরে"
                className="w-full border border-[#D1D5DB] bg-white px-3 py-2 text-sm font-bold text-[#111827] outline-none focus:border-[#D32F2F]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#111827] mb-1">
                মূল শিরোনাম (সাদা বোল্ড টেক্সট)
              </label>
              <textarea
                rows={2}
                value={mainHeadline}
                onChange={(e) => setMainHeadline(e.target.value)}
                placeholder="সংবাদের মূল শিরোনাম লিখুন..."
                className="w-full border border-[#D1D5DB] bg-white px-3 py-2 text-sm font-bold text-[#111827] outline-none focus:border-[#D32F2F]"
              />
            </div>

            {/* Font size slider */}
            <div className="flex items-center gap-3 pt-1">
              <span className="text-xs font-bold text-[#4B5563] shrink-0">
                শিরোনাম ফন্ট সাইজ:
              </span>
              <input
                type="range"
                min={38}
                max={64}
                value={fontSizeScale}
                onChange={(e) => setFontSizeScale(Number(e.target.value))}
                className="flex-1 accent-[#D32F2F] cursor-pointer"
              />
              <span className="text-xs font-mono-num font-bold text-[#111827]">
                {fontSizeScale}px
              </span>
            </div>
          </div>

          {/* 3. Speaker / Quote Attribution & Category/Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1 text-xs font-bold text-[#111827] mb-1">
                <UserCheck className="w-3.5 h-3.5 text-[#D32F2F]" /> বক্তার নাম (ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={speakerName}
                onChange={(e) => setSpeakerName(e.target.value)}
                placeholder="যেমন: ড. মুহাম্মদ ইউনূস"
                className="w-full border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none focus:border-[#111827]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111827] mb-1">
                বক্তার পদবি / পরিচয় (ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={speakerRole}
                onChange={(e) => setSpeakerRole(e.target.value)}
                placeholder="যেমন: প্রধান উপদেষ্টা"
                className="w-full border border-[#D1D5DB] px-3 py-1.5 text-xs outline-none focus:border-[#111827]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111827] mb-1">
                ক্যাটাগরি ব্যাজ
              </label>
              <input
                type="text"
                value={categoryBadge}
                onChange={(e) => setCategoryBadge(e.target.value)}
                className="w-full border border-[#D1D5DB] px-3 py-1.5 text-xs font-bold outline-none focus:border-[#111827]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#111827] mb-1">
                তারিখ ও ফুটার কলআউট
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={dateBadge}
                  onChange={(e) => setDateBadge(e.target.value)}
                  className="w-1/2 border border-[#D1D5DB] px-2.5 py-1.5 text-xs outline-none"
                />
                <select
                  value={footerCallout}
                  onChange={(e) => setFooterCallout(e.target.value)}
                  className="w-1/2 border border-[#D1D5DB] px-2 py-1.5 text-xs font-bold bg-white outline-none"
                >
                  <option value="বিস্তারিত কমেন্টে">বিস্তারিত কমেন্টে</option>
                  <option value="বিস্তারিত প্রথম কমেন্টে">
                    বিস্তারিত প্রথম কমেন্টে
                  </option>
                  <option value="বিস্তারিত ওয়েবসাইটে">বিস্তারিত ওয়েবসাইটে</option>
                </select>
              </div>
            </div>
          </div>

          {/* 4. Photo Upload, Zoom & Position Controls */}
          <div className="bg-[#F9FAFB] p-4 border border-[#E5E7EB] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#111827] flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-[#D32F2F]" />
                সংবাদের ছবি পরিবর্তন ও পজিশন
              </span>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleUploadPhoto}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 bg-[#111827] hover:bg-[#D32F2F] text-white text-xs font-bold px-3 py-1.5 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" /> নতুন ছবি আপলোড করুন
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <div className="flex justify-between text-[11px] font-semibold text-[#4B5563] mb-1">
                  <span>ছবি জুম (Zoom):</span>
                  <span>{photoZoom}%</span>
                </div>
                <input
                  type="range"
                  min={100}
                  max={165}
                  value={photoZoom}
                  onChange={(e) => setPhotoZoom(Number(e.target.value))}
                  className="w-full accent-[#D32F2F] cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between text-[11px] font-semibold text-[#4B5563] mb-1">
                  <span>উপর-নিচ পজিশন:</span>
                  <span>{photoOffsetY}px</span>
                </div>
                <input
                  type="range"
                  min={-120}
                  max={120}
                  value={photoOffsetY}
                  onChange={(e) => setPhotoOffsetY(Number(e.target.value))}
                  className="w-full accent-[#D32F2F] cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  if (!isModal) {
    return studioContent;
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      {studioContent}
    </div>
  );
};
