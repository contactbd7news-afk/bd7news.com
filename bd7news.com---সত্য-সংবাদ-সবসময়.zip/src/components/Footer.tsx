import React, { useState } from 'react';
import {
  Home,
  Clock,
  Grid,
  Play,
  Menu,
  X,
  Mail,
  Phone,
  MapPin,
  ShieldCheck,
} from 'lucide-react';
import { useNews } from '../context/NewsContext';

export const Footer: React.FC = () => {
  const { siteSettings, categories, navigateTo, activeView } = useNews();
  const [activeInfoModal, setActiveInfoModal] = useState<string | null>(null);
  const [mobileCategoriesSheet, setMobileCategoriesSheet] = useState(false);

  const infoPages: Record<string, { title: string; body: string }> = {
    about: {
      title: 'আমাদের সম্পর্কে (About Us)',
      body: 'bd7news.com ("সত্য সংবাদ সবসময়") বাংলাদেশের অন্যতম আধুনিক, বস্তুনিষ্ঠ ও নির্ভরযোগ্য অনলাইন নিউজ পোর্টাল। দেশ ও জনগণের স্বার্থকে সর্বোচ্চ অগ্রাধিকার দিয়ে আমরা ২৪ ঘণ্টা জাতীয়, রাজনীতি, অর্থনীতি, আন্তর্জাতিক, খেলাধুলা ও প্রযুক্তির সঠিক সংবাদ পাঠকের কাছে পৌঁছে দিচ্ছি।',
    },
    contact: {
      title: 'যোগাযোগ (Contact)',
      body: `প্রধান কার্যালয়: ${siteSettings.addressBn}। ফোন: ${siteSettings.phoneBn}। ইমেইল: ${siteSettings.email}। বার্তা ও বিজ্ঞাপন বিভাগের সাথে সার্বক্ষণিক যোগাযোগের জন্য ইমেইল করুন।`,
    },
    privacy: {
      title: 'গোপনীয়তা নীতি (Privacy Policy)',
      body: 'bd7news.com পাঠকদের ব্যক্তিগত তথ্যের গোপনীয়তা রক্ষায় প্রতিশ্রুতিবদ্ধ। পাঠকের অনুমতি ব্যতীত কোনো ব্যক্তিগত তথ্য তৃতীয় পক্ষের সাথে বিনিময় করা হয় না। কুকিজ ও অ্যানালিটিক্স কেবল পাঠকদের পাঠ-অভিজ্ঞতা উন্নয়নের কাজে ব্যবহৃত হয়।',
    },
    terms: {
      title: 'ব্যবহারের শর্তাবলি (Terms & Conditions)',
      body: 'bd7news.com-এ প্রকাশিত সকল সংবাদ, ছবি, ভিডিও ও কলামের স্বত্ব বিডি৭ মিডিয়া লিমিটেড কর্তৃক সংরক্ষিত। কর্তৃপক্ষের লিখিত অনুমতি ছাড়া কোনো কন্টেন্ট বাণিজ্যিক উদ্দেশ্যে পুনঃপ্রকাশ করা আইনত দণ্ডনীয়।',
    },
    editorial: {
      title: 'সম্পাদকীয় নীতিমালা (Editorial Policy)',
      body: 'আমরা কোনো গুজব বা যাচাইবিহীন তথ্য প্রকাশ করি না। প্রতিটি সংবাদের ক্ষেত্রে সংশ্লিষ্ট পক্ষগুলোর বক্তব্য ও তথ্যসূত্র ক্রস-চেক করে নিরপেক্ষ ও দায়িত্বশীল সাংবাদিকতা নিশ্চিত করাই আমাদের মূল অঙ্গীকার।',
    },
    disclaimer: {
      title: 'দায়মুক্তি (Disclaimer)',
      body: 'মতামত বা কলাম বিভাগে প্রকাশিত লেখার দায়ভার সম্পূর্ণ লেখকের নিজস্ব; তা সবসময় bd7news.com-এর সম্পাদকীয় অবস্থান প্রতিফলিত নাও করতে পারে।',
    },
    advertisement: {
      title: 'বিজ্ঞাপন (Advertisement)',
      body: 'bd7news.com-এর টপ ব্যানার, হোমপেজ লিডারবোর্ড, সাইডবার এবং ইন-আর্টিকেল স্লটে আপনার প্রতিষ্ঠানের বিজ্ঞাপন প্রচার করতে যোগাযোগ করুন: ads@bd7news.com অথবা সরাসরি আমাদের বিজ্ঞাপন বিভাগে কল করুন।',
    },
    sitemap: {
      title: 'সাইটম্যাপ (Sitemap)',
      body: 'প্রচ্ছদ, সর্বশেষ সংবাদ, জাতীয়, রাজনীতি, আন্তর্জাতিক, খেলাধুলা, ক্রিকেট, ফুটবল, বিনোদন, অর্থনীতি, প্রযুক্তি, জীবনযাপন, ধর্ম, ভিডিও সংবাদ, ছবিতে আজ, মতামত এবং বিশেষ প্রতিবেদন। XML Sitemap: https://bd7news.com/sitemap.xml',
    },
  };

  return (
    <>
      <footer className="bg-[#F9FAFB] border-t-2 border-[#111827] text-[#111827] mt-12 pb-16 md:pb-0">
        <div className="max-w-[1320px] mx-auto px-4 py-10">
          {/* Top Brand & Editorial Info Row */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-8 border-b border-[#E5E7EB]">
            {/* Col 1: Logo & Tagline */}
            <div className="md:col-span-4">
              <div
                onClick={() => navigateTo({ type: 'home' })}
                className="cursor-pointer inline-block"
              >
                {siteSettings.footerLogoUrl || siteSettings.logoUrl ? (
                  <div>
                    <img
                      src={siteSettings.footerLogoUrl || siteSettings.logoUrl}
                      alt={siteSettings.siteName}
                      style={{
                        height: `${Math.min(siteSettings.logoHeight || 48, 64)}px`,
                      }}
                      className="w-auto max-w-[260px] object-contain"
                    />
                    {(siteSettings.showTaglineWithLogo ?? true) && (
                      <p className="font-editorial font-bold text-sm text-[#4B5563] mt-1.5">
                        {siteSettings.taglineBn}
                      </p>
                    )}
                  </div>
                ) : (
                  <div>
                    <div className="flex items-baseline gap-1">
                      <span className="font-editorial font-extrabold text-3xl text-[#111827]">
                        bd<span className="text-[#D32F2F]">7</span>news
                      </span>
                      <span className="font-bold text-lg text-[#D32F2F]">.com</span>
                    </div>
                    <p className="font-editorial font-bold text-sm text-[#4B5563] mt-1">
                      {siteSettings.taglineBn}
                    </p>
                  </div>
                )}
              </div>

              <div className="mt-4 space-y-1.5 text-xs text-[#4B5563]">
                <p>
                  <strong className="text-[#111827]">প্রধান সম্পাদক:</strong>{' '}
                  {siteSettings.editorNameBn}
                </p>
                <p>
                  <strong className="text-[#111827]">প্রকাশক:</strong>{' '}
                  {siteSettings.publisherNameBn}
                </p>
                <p className="flex items-start gap-1.5 pt-1">
                  <MapPin className="w-3.5 h-3.5 text-[#D32F2F] shrink-0 mt-0.5" />
                  <span>{siteSettings.addressBn}</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-[#D32F2F] shrink-0" />
                  <span>{siteSettings.phoneBn}</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#D32F2F] shrink-0" />
                  <span>{siteSettings.email}</span>
                </p>
              </div>
            </div>

            {/* Col 2: News Categories */}
            <div className="md:col-span-4">
              <h4 className="font-editorial font-bold text-base text-[#111827] border-b border-[#E5E7EB] pb-2 mb-3">
                সংবাদ বিভাগসমূহ
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-2 gap-x-4 text-xs sm:text-sm">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() =>
                      navigateTo({ type: 'category', categorySlug: cat.slug })
                    }
                    className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium transition-colors cursor-pointer"
                  >
                    {cat.nameBn}
                  </button>
                ))}
              </div>
            </div>

            {/* Col 3: Important Links & Social Media */}
            <div className="md:col-span-4">
              <h4 className="font-editorial font-bold text-base text-[#111827] border-b border-[#E5E7EB] pb-2 mb-3">
                নীতিমালা ও প্রয়োজনীয় লিংক
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs sm:text-sm mb-5">
                <button
                  onClick={() => setActiveInfoModal('about')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  About Us (আমাদের সম্পর্কে)
                </button>
                <button
                  onClick={() => setActiveInfoModal('contact')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  Contact (যোগাযোগ)
                </button>
                <button
                  onClick={() => setActiveInfoModal('privacy')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  Privacy Policy
                </button>
                <button
                  onClick={() => setActiveInfoModal('terms')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  Terms & Conditions
                </button>
                <button
                  onClick={() => setActiveInfoModal('editorial')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  Editorial Policy
                </button>
                <button
                  onClick={() => setActiveInfoModal('disclaimer')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  Disclaimer
                </button>
                <button
                  onClick={() => setActiveInfoModal('advertisement')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  Advertisement (বিজ্ঞাপন)
                </button>
                <button
                  onClick={() => setActiveInfoModal('sitemap')}
                  className="text-left text-[#4B5563] hover:text-[#D32F2F] font-medium cursor-pointer"
                >
                  Sitemap (সাইটম্যাপ)
                </button>
              </div>

              {/* Social Links: Facebook | YouTube | X | Instagram */}
              <div className="flex flex-wrap items-center gap-2">
                <a
                  href={siteSettings.facebookUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-white border border-[#D1D5DB] hover:border-[#1877F2] hover:text-[#1877F2] text-xs font-bold transition-colors"
                >
                  Facebook
                </a>
                <a
                  href={siteSettings.youtubeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-white border border-[#D1D5DB] hover:border-[#FF0000] hover:text-[#FF0000] text-xs font-bold transition-colors"
                >
                  YouTube
                </a>
                <a
                  href={siteSettings.xUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-white border border-[#D1D5DB] hover:border-[#111827] hover:text-[#111827] text-xs font-bold transition-colors"
                >
                  X
                </a>
                <a
                  href={siteSettings.instagramUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-white border border-[#D1D5DB] hover:border-[#E4405F] hover:text-[#E4405F] text-xs font-bold transition-colors"
                >
                  Instagram
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Copyright Row */}
          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#6B7280]">
            <p className="font-editorial font-bold text-sm text-[#111827]">
              © 2026 bd7news.com — সর্বস্বত্ব সংরক্ষিত
            </p>
            <div className="flex items-center gap-4">
              <a
                href="/sitemap.xml"
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#D32F2F]"
              >
                XML Sitemap
              </a>
              <span>•</span>
              <a
                href="/robots.txt"
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#D32F2F]"
              >
                robots.txt
              </a>
              <span>•</span>
              <button
                onClick={() =>
                  navigateTo({ type: 'admin', tab: 'dashboard' })
                }
                className="inline-flex items-center gap-1 text-[#111827] hover:text-[#D32F2F] font-semibold cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5" /> CMS Login
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* Policy / Sitemap Info Modal */}
      {activeInfoModal && infoPages[activeInfoModal] && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white border-2 border-[#111827] max-w-lg w-full p-6 relative shadow-2xl">
            <button
              onClick={() => setActiveInfoModal(null)}
              className="absolute top-4 right-4 p-1 border border-[#E5E7EB] text-[#6B7280] hover:text-[#111827]"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="text-xs font-bold text-[#D32F2F] uppercase mb-1">
              bd7news.com — সত্য সংবাদ সবসময়
            </div>
            <h3 className="font-editorial font-bold text-xl text-[#111827] pb-3 mb-3 border-b border-[#E5E7EB]">
              {infoPages[activeInfoModal].title}
            </h3>
            <p className="font-editorial text-sm sm:text-base text-[#374151] leading-relaxed mb-5">
              {infoPages[activeInfoModal].body}
            </p>
            <button
              onClick={() => setActiveInfoModal(null)}
              className="w-full bg-[#111827] text-white text-xs font-bold py-2.5 cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}

      {/* DEDICATED MOBILE BOTTOM NAVIGATION BAR: Home | Latest | Categories | Video | Menu */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#D1D5DB] md:hidden h-14 grid grid-cols-5 shadow-lg">
        <button
          onClick={() => navigateTo({ type: 'home' })}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold ${
            activeView.type === 'home' ? 'text-[#D32F2F]' : 'text-[#4B5563]'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Home</span>
        </button>

        <button
          onClick={() => navigateTo({ type: 'latest' })}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold ${
            activeView.type === 'latest' ? 'text-[#D32F2F]' : 'text-[#4B5563]'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Latest</span>
        </button>

        <button
          onClick={() => setMobileCategoriesSheet(!mobileCategoriesSheet)}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold ${
            mobileCategoriesSheet || activeView.type === 'category'
              ? 'text-[#D32F2F]'
              : 'text-[#4B5563]'
          }`}
        >
          <Grid className="w-4 h-4" />
          <span>Categories</span>
        </button>

        <button
          onClick={() => navigateTo({ type: 'video' })}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold ${
            activeView.type === 'video' ? 'text-[#D32F2F]' : 'text-[#4B5563]'
          }`}
        >
          <Play className="w-4 h-4" />
          <span>Video</span>
        </button>

        <button
          onClick={() => navigateTo({ type: 'admin', tab: 'dashboard' })}
          className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-bold ${
            activeView.type === 'admin' ? 'text-[#D32F2F]' : 'text-[#4B5563]'
          }`}
        >
          <Menu className="w-4 h-4" />
          <span>Menu/CMS</span>
        </button>
      </div>

      {/* Mobile Categories Quick Sheet */}
      {mobileCategoriesSheet && (
        <div className="fixed inset-0 z-50 bg-black/50 md:hidden flex items-end">
          <div className="bg-white w-full p-5 border-t-2 border-[#111827] max-h-[75vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#E5E7EB]">
              <h4 className="font-editorial font-bold text-lg text-[#111827]">
                সকল সংবাদ বিভাগ
              </h4>
              <button
                onClick={() => setMobileCategoriesSheet(false)}
                className="p-1 border border-[#E5E7EB]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    navigateTo({ type: 'category', categorySlug: cat.slug });
                    setMobileCategoriesSheet(false);
                  }}
                  className="p-3 bg-[#F9FAFB] border border-[#E5E7EB] text-left font-editorial font-bold text-sm text-[#111827]"
                >
                  {cat.nameBn}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
