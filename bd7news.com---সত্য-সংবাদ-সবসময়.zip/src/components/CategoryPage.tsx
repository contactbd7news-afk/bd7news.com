import React, { useState, useEffect } from 'react';
import {
  Camera,
  Play,
  Pause,
  ChevronLeft,
  ChevronRight,
  Film,
  Images,
  ZoomIn,
  ZoomOut,
  Download,
  Eye,
  Maximize2,
  X,
} from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';
import { NewsCard, MostReadWidget, SectionHeader } from './NewsCard';
import { AdSlot } from './AdSlot';

interface CategoryPageProps {
  categorySlug: string;
  initialSubcategory?: string;
}

export const CategoryPage: React.FC<CategoryPageProps> = ({
  categorySlug,
  initialSubcategory,
}) => {
  const { publishedArticles, categories, navigateTo, matchScores } = useNews();
  const [selectedSub, setSelectedSub] = useState<string>(
    initialSubcategory || 'ALL'
  );
  const [visibleCount, setVisibleCount] = useState<number>(6);

  const categoryConfig = categories.find((c) => c.slug === categorySlug);
  const categoryTitleBn =
    categorySlug === 'latest'
      ? 'সর্বশেষ সংবাদ'
      : categoryConfig?.nameBn || 'সংবাদ বিভাগ';

  // Filter articles for this category
  const categoryArticles =
    categorySlug === 'latest'
      ? publishedArticles
      : categorySlug === 'sports'
      ? publishedArticles.filter(
          (a) =>
            a.category === 'sports' ||
            a.category === 'cricket' ||
            a.category === 'football'
        )
      : publishedArticles.filter((a) => a.category === categorySlug);

  const subFilteredArticles =
    selectedSub === 'ALL'
      ? categoryArticles
      : categoryArticles.filter(
          (a) => a.subcategory.toLowerCase() === selectedSub.toLowerCase()
        );

  const displayPool =
    subFilteredArticles.length > 0 ? subFilteredArticles : categoryArticles;

  const featuredStory = displayPool[0] || publishedArticles[0];
  const gridStories = displayPool.slice(1, 5);
  const listStories = [
    ...displayPool.slice(5),
    ...publishedArticles.filter((a) => a.category !== categorySlug),
  ];

  return (
    <div className="max-w-[1320px] mx-auto px-4 py-6">
      {/* Category Header & Subcategory Filter Bar */}
      <div className="border-b-2 border-[#111827] pb-4 mb-6">
        <div className="flex items-center gap-2 text-xs text-[#6B7280] mb-2">
          <button
            onClick={() => navigateTo({ type: 'home' })}
            className="hover:text-[#D32F2F] cursor-pointer"
          >
            প্রচ্ছদ
          </button>
          <span>/</span>
          <span className="font-bold text-[#D32F2F]">{categoryTitleBn}</span>
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-3.5 h-8 bg-[#D32F2F] inline-block" />
            <h1 className="font-editorial font-extrabold text-3xl sm:text-4xl text-[#111827]">
              {categoryTitleBn}
            </h1>
          </div>

          {/* Subcategory Pills */}
          {categoryConfig && categoryConfig.subcategories.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setSelectedSub('ALL')}
                className={`px-3.5 py-1.5 text-xs font-bold border whitespace-nowrap transition-colors cursor-pointer ${
                  selectedSub === 'ALL'
                    ? 'bg-[#111827] text-white border-[#111827]'
                    : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:border-[#111827]'
                }`}
              >
                সব ({toBengaliNumber(categoryArticles.length)})
              </button>
              {categoryConfig.subcategories.map((sub) => (
                <button
                  key={sub}
                  onClick={() => setSelectedSub(sub)}
                  className={`px-3.5 py-1.5 text-xs font-bold border whitespace-nowrap transition-colors cursor-pointer ${
                    selectedSub === sub
                      ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                      : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:border-[#111827]'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Live Match Score Strip if Sports / Cricket / Football */}
      {(categorySlug === 'sports' ||
        categorySlug === 'cricket' ||
        categorySlug === 'football') && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {matchScores
            .filter((m) =>
              categorySlug === 'sports' ? true : m.sport === categorySlug
            )
            .slice(0, 3)
            .map((match) => (
              <div
                key={match.id}
                className="bg-[#0F172A] text-white border border-slate-800 p-4 rounded-[2px]"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                  <span>{match.tournament}</span>
                  <span className="bg-[#D32F2F] text-white px-2 py-0.5 font-bold">
                    {match.statusTextBn}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm font-bold mb-1">
                  <span>{match.team1}</span>
                  <span className="text-[#10B981] font-mono-num">
                    {match.team1Score}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm font-bold mb-2">
                  <span>{match.team2}</span>
                  <span className="text-slate-300 font-mono-num">
                    {match.team2Score}
                  </span>
                </div>
                <p className="text-xs text-amber-300 border-t border-slate-800 pt-2">
                  {match.summaryBn}
                </p>
              </div>
            ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left 8 Cols: Featured Story + News Grid + Latest News List + Pagination */}
        <div className="lg:col-span-8">
          {/* Featured Story */}
          {featuredStory && (
            <div className="pb-6 mb-6 border-b border-[#E5E7EB]">
              <NewsCard article={featuredStory} variant="hero" />
            </div>
          )}

          {/* News Grid */}
          {gridStories.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pb-6 mb-6 border-b border-[#E5E7EB]">
              {gridStories.map((art) => (
                <NewsCard key={art.id} article={art} variant="vertical" />
              ))}
            </div>
          )}

          {/* In-category Banner Ad */}
          <AdSlot slot="between-section" />

          {/* Latest News List */}
          <div className="mt-6">
            <SectionHeader titleBn={`${categoryTitleBn} — ধারাবাহিক সংবাদ`} />
            <div className="bg-white border border-[#E5E7EB] px-4 sm:px-5 rounded-[2px] divide-y divide-[#E5E7EB]">
              {listStories.slice(0, visibleCount).map((art) => (
                <NewsCard
                  key={art.id}
                  article={art}
                  variant="horizontal-feed"
                />
              ))}
            </div>

            {/* Pagination / Load More */}
            <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#F9FAFB] border border-[#E5E7EB] p-4">
              <span className="text-xs text-[#6B7280]">
                মোট {toBengaliNumber(listStories.length)}টি সংবাদের মধ্যে{' '}
                {toBengaliNumber(Math.min(visibleCount, listStories.length))}টি দেখানো হচ্ছে
              </span>
              {visibleCount < listStories.length && (
                <button
                  onClick={() => setVisibleCount((prev) => prev + 5)}
                  className="px-6 py-2 bg-[#111827] hover:bg-[#D32F2F] text-white font-editorial font-bold text-sm transition-colors cursor-pointer"
                >
                  আরও সংবাদ লোড করুন +
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Sidebar + Most Read + Ad Slots */}
        <aside className="lg:col-span-4 space-y-6">
          <AdSlot slot="sidebar-ad" />
          <MostReadWidget />
          <AdSlot slot="sidebar-ad" />
        </aside>
      </div>
    </div>
  );
};

// Dedicated Video & Photo Gallery Full Page Views
export const MediaHubPage: React.FC<{ mode: 'video' | 'photo-gallery' }> = ({
  mode,
}) => {
  const { publishedArticles, photoGalleries, navigateTo } = useNews();
  const [selectedGalleryIndex, setSelectedGalleryIndex] = useState(0);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [photoFilterCat, setPhotoFilterCat] = useState<string>('ALL');
  const [autoSlideshow, setAutoSlideshow] = useState<boolean>(false);
  const [photoZoom, setPhotoZoom] = useState<number>(1);
  const [fullscreenPhotoModal, setFullscreenPhotoModal] = useState<boolean>(false);

  // Video Hub states
  const videoArticles = publishedArticles.filter((a) => a.category === 'video');
  const [selectedVideoId, setSelectedVideoId] = useState<string>(
    videoArticles[0]?.id || ''
  );
  const [videoSubFilter, setVideoSubFilter] = useState<string>('ALL');
  const [isPlayingVideo, setIsPlayingVideo] = useState<boolean>(false);
  const [videoProgress, setVideoProgress] = useState<number>(22);

  const filteredGalleries =
    photoFilterCat === 'ALL'
      ? photoGalleries
      : photoGalleries.filter((g) => g.categoryBn === photoFilterCat);
  const displayGalleries =
    filteredGalleries.length > 0 ? filteredGalleries : photoGalleries;
  const activeGal =
    displayGalleries[selectedGalleryIndex] || displayGalleries[0];

  useEffect(() => {
    if (!autoSlideshow || !activeGal || activeGal.photos.length <= 1) return;
    const timer = setInterval(() => {
      setSelectedPhotoIndex((p) => (p + 1) % activeGal.photos.length);
    }, 3200);
    return () => clearInterval(timer);
  }, [autoSlideshow, activeGal]);

  useEffect(() => {
    if (!isPlayingVideo) return;
    const timer = setInterval(() => {
      setVideoProgress((p) => (p >= 100 ? 0 : p + 1));
    }, 600);
    return () => clearInterval(timer);
  }, [isPlayingVideo]);

  if (mode === 'video') {
    const videoCats = [
      'ALL',
      ...Array.from(
        new Set(videoArticles.map((v) => v.subcategory || 'ভিডিও প্রতিবেদন'))
      ),
    ];
    const filteredVids =
      videoSubFilter === 'ALL'
        ? videoArticles
        : videoArticles.filter(
            (v) => (v.subcategory || 'ভিডিও প্রতিবেদন') === videoSubFilter
          );
    const displayVids =
      filteredVids.length > 0 ? filteredVids : videoArticles;
    const activeVideo =
      videoArticles.find((v) => v.id === selectedVideoId) ||
      displayVids[0] ||
      videoArticles[0];

    return (
      <div className="max-w-[1320px] mx-auto px-4 py-6">
        {/* Top Cinema Theater */}
        <div className="bg-gradient-to-b from-[#090D16] via-[#111827] to-[#0B0F19] text-white border-t-4 border-[#D32F2F] p-5 sm:p-8 rounded-[2px] mb-8 shadow-xl">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-[#D32F2F] flex items-center justify-center rounded-[2px]">
                <Film className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2.5">
                  <h1 className="font-editorial font-extrabold text-2xl sm:text-3xl">
                    ভিডিও গ্যালারি — bd7news মাল্টিমিডিয়া
                  </h1>
                  <span className="bg-[#D32F2F]/20 text-[#FCA5A5] border border-[#D32F2F]/40 text-xs font-bold px-2.5 py-0.5">
                    HD 1080p
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                  সরেজমিন প্রতিবেদন, খেলার মাঠ, সময়ের ক্যামেরা ও বিশেষ টকশো
                </p>
              </div>
            </div>

            {/* Category Switcher + Photo Gallery Link */}
            <div className="flex flex-wrap items-center gap-2">
              {videoCats.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setVideoSubFilter(cat)}
                  className={`px-3.5 py-1.5 text-xs font-bold border transition-colors cursor-pointer ${
                    videoSubFilter === cat
                      ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                      : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-500'
                  }`}
                >
                  {cat === 'ALL' ? `সব ভিডিও (${toBengaliNumber(videoArticles.length)})` : cat}
                </button>
              ))}
              <button
                onClick={() => navigateTo({ type: 'photo-gallery' })}
                className="px-3.5 py-1.5 bg-white/10 hover:bg-white/20 text-amber-300 text-xs font-bold border border-white/15 flex items-center gap-1.5 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" /> ফটো গ্যালারি দেখুন
              </button>
            </div>
          </div>

          {/* Active Video Theater Stage (7 Cols) + Playlist (5 Cols) */}
          {activeVideo && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-7 bg-[#060911] border border-slate-800 p-4 sm:p-5 rounded-[2px]">
                <div className="relative aspect-16/9 bg-black border border-slate-800 overflow-hidden mb-4">
                  <img
                    src={activeVideo.featuredImage}
                    alt={activeVideo.headline}
                    className={`w-full h-full object-cover transition-all duration-700 ${
                      isPlayingVideo ? 'scale-105 opacity-45' : 'opacity-80'
                    }`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent flex flex-col items-center justify-center p-6 text-center">
                    <button
                      onClick={() => setIsPlayingVideo((p) => !p)}
                      className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#D32F2F] hover:bg-red-600 text-white flex items-center justify-center shadow-2xl border-4 border-white/25 cursor-pointer mb-3"
                    >
                      {isPlayingVideo ? (
                        <Pause className="w-8 h-8" />
                      ) : (
                        <Play className="w-8 h-8 fill-current ml-1" />
                      )}
                    </button>
                    <span className="text-xs font-bold text-amber-400">
                      {isPlayingVideo
                        ? '▶ এখন চলছে — মাল্টিমিডিয়া প্লেয়ার'
                        : 'ভিডিওটি চালু করতে ক্লিক করুন'}
                    </span>
                  </div>

                  {/* Scrubber Bar */}
                  <div className="absolute bottom-0 left-0 right-0 bg-black/85 px-4 py-2 flex items-center gap-3 border-t border-slate-800">
                    <button
                      onClick={() => setIsPlayingVideo((p) => !p)}
                      className="text-white hover:text-[#D32F2F] cursor-pointer"
                    >
                      {isPlayingVideo ? (
                        <Pause className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4 fill-current" />
                      )}
                    </button>
                    <div
                      onClick={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const pct = Math.max(
                          0,
                          Math.min(
                            100,
                            Math.round(((e.clientX - rect.left) / rect.width) * 100)
                          )
                        );
                        setVideoProgress(pct);
                      }}
                      className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden cursor-pointer"
                    >
                      <div
                        style={{ width: `${videoProgress}%` }}
                        className="h-full bg-[#D32F2F]"
                      />
                    </div>
                    <span className="text-[11px] font-mono-num text-slate-300">
                      {activeVideo.videoDuration || '০৫:৩০'}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 mb-2">
                  <span>
                    <strong className="text-[#FCA5A5]">{activeVideo.subcategory || 'ভিডিও'}</strong> •{' '}
                    {activeVideo.reporter} • {activeVideo.publishedAt}
                  </span>
                  <span className="flex items-center gap-1 text-amber-300">
                    <Eye className="w-3.5 h-3.5" />
                    {toBengaliNumber(activeVideo.views)} ভিউ
                  </span>
                </div>

                <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-white mb-2">
                  {activeVideo.headline}
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed mb-4">
                  {activeVideo.summary}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
                  <button
                    onClick={() => setIsPlayingVideo((p) => !p)}
                    className="px-4 py-2 bg-[#D32F2F] hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {isPlayingVideo ? (
                      <>
                        <Pause className="w-3.5 h-3.5" /> বিরতি দিন
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" /> ভিডিও চালান
                      </>
                    )}
                  </button>
                  <button
                    onClick={() =>
                      navigateTo({ type: 'article', articleId: activeVideo.id })
                    }
                    className="px-4 py-2 bg-white text-[#111827] hover:bg-amber-300 text-xs font-bold cursor-pointer"
                  >
                    বিস্তারিত সংবাদ প্রতিবেদন পড়ুন →
                  </button>
                </div>
              </div>

              {/* Right 5 Cols: Playlist Queue */}
              <div className="lg:col-span-5 bg-[#060911] border border-slate-800 rounded-[2px] overflow-hidden flex flex-col">
                <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                  <span className="font-editorial font-bold text-base text-white">
                    ভিডিও কিউ ({toBengaliNumber(displayVids.length)}টি ভিডিও)
                  </span>
                  <span className="text-xs text-amber-400">ক্লিক করে দেখুন</span>
                </div>
                <div className="divide-y divide-slate-800 max-h-[460px] overflow-y-auto">
                  {displayVids.map((vid, idx) => {
                    const isCurr = vid.id === activeVideo.id;
                    return (
                      <div
                        key={vid.id}
                        onClick={() => {
                          setSelectedVideoId(vid.id);
                          setIsPlayingVideo(true);
                          setVideoProgress(12);
                        }}
                        className={`p-3.5 flex items-start gap-3 cursor-pointer transition-colors ${
                          isCurr
                            ? 'bg-[#D32F2F]/20 border-l-4 border-l-[#D32F2F]'
                            : 'hover:bg-slate-900'
                        }`}
                      >
                        <span className="text-xs font-mono-num font-bold text-slate-500 pt-1 w-5">
                          {isCurr ? '▶' : toBengaliNumber(idx + 1)}
                        </span>
                        <div className="relative w-32 aspect-16/9 shrink-0 overflow-hidden bg-slate-900 border border-slate-700">
                          <img
                            src={vid.featuredImage}
                            alt={vid.headline}
                            className="w-full h-full object-cover"
                          />
                          <span className="absolute bottom-1 right-1 bg-black/90 text-white text-[10px] font-mono-num px-1.5 py-0.5">
                            {vid.videoDuration}
                          </span>
                        </div>
                        <div className="min-w-0 flex-1">
                          <span className="text-[11px] font-bold text-[#FCA5A5]">
                            {vid.subcategory || 'ভিডিও'}
                          </span>
                          <h4 className="font-editorial font-bold text-sm text-white line-clamp-2 leading-snug mt-0.5">
                            {vid.headline}
                          </h4>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* All Videos Grid Below */}
        <SectionHeader
          titleBn="সকল ভিডিও প্রতিবেদন আর্কাইভ"
          subtitleBn="যেকোনো ভিডিও কার্ডে ক্লিক করলে ওপরের থিয়েটারে চালু হবে"
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayVids.map((vid) => (
            <div
              key={vid.id}
              onClick={() => {
                setSelectedVideoId(vid.id);
                setIsPlayingVideo(true);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-[#111827] text-white p-4 rounded-[2px] border border-gray-800 hover:border-[#D32F2F] transition-all cursor-pointer"
            >
              <NewsCard article={vid} variant="video" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const galleryCategories = [
    'ALL',
    ...Array.from(new Set(photoGalleries.map((g) => g.categoryBn))),
  ];
  const safePhotoIdx =
    activeGal && selectedPhotoIndex < activeGal.photos.length
      ? selectedPhotoIndex
      : 0;

  return (
    <div className="max-w-[1320px] mx-auto px-4 py-6">
      {/* Photo Gallery Header & Category Filter */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b-2 border-[#111827] pb-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-[#111827] text-white flex items-center justify-center rounded-[2px]">
            <Camera className="w-6 h-6 text-[#D32F2F]" />
          </div>
          <div>
            <h1 className="font-editorial font-extrabold text-2xl sm:text-3xl text-[#111827]">
              ছবিতে আজ — ফটো গ্যালারি ও আলোকচিত্র প্রদর্শনী
            </h1>
            <p className="text-xs sm:text-sm text-[#4B5563]">
              দেশ-বিদেশের বাছাইকৃত আলোকচিত্র অ্যালবাম ও সরেজমিন ছবির গল্প
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {galleryCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setPhotoFilterCat(cat);
                setSelectedGalleryIndex(0);
                setSelectedPhotoIndex(0);
              }}
              className={`px-3.5 py-1.5 text-xs font-bold border transition-colors cursor-pointer ${
                photoFilterCat === cat
                  ? 'bg-[#111827] text-white border-[#111827]'
                  : 'bg-white text-[#374151] border-[#D1D5DB] hover:border-[#111827]'
              }`}
            >
              {cat === 'ALL'
                ? `সব অ্যালবাম (${toBengaliNumber(photoGalleries.length)})`
                : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Exhibition Stage */}
      {activeGal && (
        <div className="bg-[#0B0F19] text-white border-2 border-[#111827] p-5 sm:p-7 rounded-[2px] mb-10 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 mb-4 border-b border-gray-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-[#D32F2F] text-white text-xs font-bold px-2.5 py-0.5">
                  {activeGal.categoryBn}
                </span>
                <span className="text-xs text-amber-400 font-bold">
                  ছবি {toBengaliNumber(safePhotoIdx + 1)} /{' '}
                  {toBengaliNumber(activeGal.photos.length)}
                </span>
                <span className="text-xs text-gray-400">
                  • {activeGal.dateBn}
                </span>
              </div>
              <h2 className="font-editorial font-extrabold text-xl sm:text-2xl mt-1 text-white">
                {activeGal.titleBn}
              </h2>
            </div>

            {/* Exhibition Controls */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setAutoSlideshow((p) => !p)}
                className={`px-3.5 py-1.5 text-xs font-bold border flex items-center gap-1.5 cursor-pointer ${
                  autoSlideshow
                    ? 'bg-amber-400 text-[#111827] border-amber-400'
                    : 'bg-gray-900 text-gray-200 border-gray-700 hover:bg-gray-800'
                }`}
              >
                {autoSlideshow ? (
                  <>
                    <Pause className="w-3.5 h-3.5" /> স্লাইডশো থামান
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" /> অটো স্লাইডশো
                  </>
                )}
              </button>
              <button
                onClick={() =>
                  setPhotoZoom((z) => (z >= 1.75 ? 1 : +(z + 0.25).toFixed(2)))
                }
                className="px-3 py-1.5 bg-gray-900 hover:bg-gray-800 text-gray-200 text-xs font-bold border border-gray-700 flex items-center gap-1 cursor-pointer"
              >
                {photoZoom > 1 ? (
                  <>
                    <ZoomOut className="w-3.5 h-3.5 text-amber-400" /> জুম রিসেট
                  </>
                ) : (
                  <>
                    <ZoomIn className="w-3.5 h-3.5" /> জুম করুন
                  </>
                )}
              </button>
              <button
                onClick={() => setFullscreenPhotoModal(true)}
                className="px-3 py-1.5 bg-[#D32F2F] hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" /> পূর্ণ পর্দা
              </button>
            </div>
          </div>

          {/* Photo Canvas */}
          <div className="relative aspect-16/9 bg-black overflow-hidden mb-4 border border-gray-800">
            <img
              src={
                activeGal.photos[safePhotoIdx]?.url || activeGal.coverImage
              }
              alt={activeGal.titleBn}
              style={{ transform: `scale(${photoZoom})` }}
              className="w-full h-full object-contain transition-transform duration-300"
            />
            {activeGal.photos.length > 1 && (
              <>
                <button
                  onClick={() =>
                    setSelectedPhotoIndex((p) =>
                      p === 0 ? activeGal.photos.length - 1 : p - 1
                    )
                  }
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/80 hover:bg-[#D32F2F] text-white border border-white/20 cursor-pointer"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  onClick={() =>
                    setSelectedPhotoIndex((p) =>
                      p === activeGal.photos.length - 1 ? 0 : p + 1
                    )
                  }
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/80 hover:bg-[#D32F2F] text-white border border-white/20 cursor-pointer"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </>
            )}
          </div>

          {/* Caption + Filmstrip Thumbnails */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pt-2">
            <p className="font-editorial text-sm sm:text-base text-amber-200">
              📷 {activeGal.photos[safePhotoIdx]?.captionBn}
            </p>
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
              {activeGal.photos.map((ph, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPhotoZoom(1);
                    setSelectedPhotoIndex(idx);
                  }}
                  className={`relative w-20 aspect-16/10 overflow-hidden border-2 transition-all cursor-pointer shrink-0 ${
                    idx === safePhotoIdx
                      ? 'border-[#D32F2F] scale-105'
                      : 'border-gray-700 opacity-55 hover:opacity-100'
                  }`}
                >
                  <img
                    src={ph.url}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-0.5 right-0.5 bg-black/80 text-white text-[9px] font-bold px-1">
                    {toBengaliNumber(idx + 1)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* All Photo Albums Grid */}
      <SectionHeader
        titleBn="সকল ফটো অ্যালবাম"
        subtitleBn="যেকোনো অ্যালবামে ক্লিক করে সবগুলো ছবি ও ক্যাপশন দেখুন"
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayGalleries.map((gal, idx) => {
          const isSelected = activeGal?.id === gal.id;
          return (
            <div
              key={gal.id}
              onClick={() => {
                setSelectedGalleryIndex(idx);
                setSelectedPhotoIndex(0);
                setPhotoZoom(1);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`group cursor-pointer border-2 p-4 rounded-[2px] transition-all ${
                isSelected
                  ? 'border-[#D32F2F] bg-[#FEF2F2] shadow-md'
                  : 'border-[#E5E7EB] bg-white hover:border-[#111827]'
              }`}
            >
              <div className="aspect-16/10 overflow-hidden mb-3 bg-gray-900 relative">
                <img
                  src={gal.coverImage}
                  alt={gal.titleBn}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-2.5 left-2.5 bg-[#D32F2F] text-white text-xs font-bold px-2.5 py-0.5">
                  {gal.categoryBn}
                </span>
                <span className="absolute bottom-2.5 right-2.5 bg-black/85 text-white text-xs font-bold px-2.5 py-1 flex items-center gap-1">
                  <Images className="w-3.5 h-3.5 text-amber-400" />
                  {toBengaliNumber(gal.photos.length)}টি ছবি
                </span>
              </div>

              {/* Mini 3-Photo Strip inside Album Card */}
              <div className="grid grid-cols-3 gap-1.5 mb-3">
                {gal.photos.slice(0, 3).map((p, i) => (
                  <div
                    key={i}
                    className="aspect-16/10 overflow-hidden bg-gray-100 border border-gray-200"
                  >
                    <img
                      src={p.url}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>

              <span className="text-[11px] text-[#6B7280] block mb-1">
                প্রকাশ: {gal.dateBn}
              </span>
              <h4 className="font-editorial font-bold text-base sm:text-lg text-[#111827] group-hover:text-[#D32F2F] leading-snug line-clamp-2">
                {gal.titleBn}
              </h4>
            </div>
          );
        })}
      </div>

      {/* Fullscreen Lightbox Modal on Photo Gallery Page */}
      {fullscreenPhotoModal && activeGal && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4">
          <div className="max-w-5xl w-full bg-[#0B0F19] border border-gray-800 text-white p-5 relative">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-800">
              <div>
                <span className="text-xs font-bold text-amber-400">
                  {activeGal.categoryBn} • ছবি {toBengaliNumber(safePhotoIdx + 1)} /{' '}
                  {toBengaliNumber(activeGal.photos.length)}
                </span>
                <h3 className="font-editorial font-bold text-lg sm:text-xl text-white">
                  {activeGal.titleBn}
                </h3>
              </div>
              <button
                onClick={() => setFullscreenPhotoModal(false)}
                className="p-1.5 bg-[#D32F2F] hover:bg-red-700 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="relative aspect-16/9 bg-black overflow-hidden mb-3">
              <img
                src={activeGal.photos[safePhotoIdx]?.url || activeGal.coverImage}
                alt={activeGal.titleBn}
                className="w-full h-full object-contain"
              />
            </div>
            <p className="text-sm text-amber-200 font-editorial">
              📷 {activeGal.photos[safePhotoIdx]?.captionBn}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
