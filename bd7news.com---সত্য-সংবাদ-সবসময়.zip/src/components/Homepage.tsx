import React, { useState, useEffect } from 'react';
import {
  Clock,
  ChevronRight,
  Play,
  Pause,
  Camera,
  Quote,
  Radio,
  Trophy,
  Flame,
  TrendingUp,
  X,
  ChevronLeft,
  Maximize2,
  ZoomIn,
  ZoomOut,
  Download,
  Volume2,
  Film,
  Images,
  Eye,
  Share2,
} from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';
import { NewsCard, MostReadWidget, SectionHeader } from './NewsCard';
import { AdSlot } from './AdSlot';
import { CountrywideHomepageSection } from './CountrywideSection';
import { WeatherHomepageSection } from './WeatherSection';
import { DailyUtilitiesWidget } from './DailyUtilitiesWidget';
import { PhotoGalleryItem, Article } from '../types/news';

export const Homepage: React.FC = () => {
  const {
    publishedArticles,
    homepageSections,
    matchScores,
    photoGalleries,
    opinions,
    navigateTo,
  } = useNews();

  // Sports section tab state
  const [sportsTab, setSportsTab] = useState<'cricket' | 'football' | 'other'>('cricket');

  // Dedicated Cricket & Football filter pills
  const [cricketFilter, setCricketFilter] = useState<string>('ALL');
  const [footballFilter, setFootballFilter] = useState<string>('ALL');

  // Interactive Photo Gallery Lightbox State
  const [activeGallery, setActiveGallery] = useState<PhotoGalleryItem | null>(null);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number>(0);
  const [lightboxZoom, setLightboxZoom] = useState<number>(1);
  const [isSlideshowPlaying, setIsSlideshowPlaying] = useState<boolean>(false);

  // Homepage In-Place Photo Gallery Slider State
  const [homeGalleryCategory, setHomeGalleryCategory] = useState<string>('ALL');
  const [homeActiveGalleryId, setHomeActiveGalleryId] = useState<string>('');
  const [homeSlideIndex, setHomeSlideIndex] = useState<number>(0);
  const [homeAutoSlide, setHomeAutoSlide] = useState<boolean>(false);

  // Interactive Video Section & Modal State
  const [videoCategoryFilter, setVideoCategoryFilter] = useState<string>('ALL');
  const [selectedHomeVideoId, setSelectedHomeVideoId] = useState<string>('');
  const [isHomeVideoPlaying, setIsHomeVideoPlaying] = useState<boolean>(false);
  const [activeVideoArticle, setActiveVideoArticle] = useState<Article | null>(null);
  const [videoModalProgress, setVideoModalProgress] = useState<number>(18);
  const [isModalVideoPlaying, setIsModalVideoPlaying] = useState<boolean>(true);

  // Auto-advance homepage photo slider when enabled
  useEffect(() => {
    if (!homeAutoSlide) return;
    const currentGal =
      photoGalleries.find((g) => g.id === homeActiveGalleryId) || photoGalleries[0];
    if (!currentGal || currentGal.photos.length <= 1) return;
    const timer = setInterval(() => {
      setHomeSlideIndex((prev) => (prev + 1) % currentGal.photos.length);
    }, 3500);
    return () => clearInterval(timer);
  }, [homeAutoSlide, homeActiveGalleryId, photoGalleries]);

  // Auto-advance lightbox slideshow when enabled
  useEffect(() => {
    if (!isSlideshowPlaying || !activeGallery) return;
    const timer = setInterval(() => {
      setActivePhotoIndex((prev) => (prev + 1) % activeGallery.photos.length);
    }, 3200);
    return () => clearInterval(timer);
  }, [isSlideshowPlaying, activeGallery]);

  // Simulate video progress bar when modal video is playing
  useEffect(() => {
    if (!activeVideoArticle || !isModalVideoPlaying) return;
    const timer = setInterval(() => {
      setVideoModalProgress((prev) => (prev >= 100 ? 0 : prev + 1));
    }, 600);
    return () => clearInterval(timer);
  }, [activeVideoArticle, isModalVideoPlaying]);

  // Latest News "আরও সংবাদ" load more count
  const [latestVisibleCount, setLatestVisibleCount] = useState<number>(6);

  // Hero Section Interactive State (Lead Story Switcher & Right Column Tabs)
  const [activeLeadIdx, setActiveLeadIdx] = useState<number>(0);
  const [heroRightTab, setHeroRightTab] = useState<'featured' | 'latest' | 'popular'>('featured');

  // Sort sections according to CMS Homepage Control
  const orderedSections = [...homepageSections]
    .filter((s) => s.enabled)
    .sort((a, b) => a.order - b.order);

  // Hero story & secondary hero cards
  const primaryHeroArticle =
    publishedArticles.find((a) => a.isHero) || publishedArticles[0];
  const heroLeadCandidates = [
    primaryHeroArticle,
    ...publishedArticles
      .filter((a) => a.id !== primaryHeroArticle?.id && (a.isFeatured || a.isBreaking))
      .slice(0, 3),
  ].filter(Boolean) as Article[];

  const heroArticle =
    heroLeadCandidates[activeLeadIdx] || primaryHeroArticle;

  const remainingAfterHero = publishedArticles.filter(
    (a) => a.id !== heroArticle?.id
  );

  const rightStackArticles =
    heroRightTab === 'popular'
      ? [...remainingAfterHero].sort((a, b) => b.views - a.views).slice(0, 5)
      : heroRightTab === 'latest'
      ? remainingAfterHero.slice(0, 5)
      : [...remainingAfterHero]
          .sort(
            (a, b) =>
              Number(Boolean(b.isFeatured || b.isBreaking)) -
              Number(Boolean(a.isFeatured || a.isBreaking))
          )
          .slice(0, 5);

  const belowHeroTimeline = remainingAfterHero.slice(4, 9);

  // Category helpers
  const getByCategory = (slug: string) =>
    publishedArticles.filter((a) => a.category === slug);

  const nationalArticles = getByCategory('national');
  const politicsArticles = getByCategory('politics');
  const internationalArticles = getByCategory('international');
  const economyArticles = getByCategory('economy');
  const technologyArticles = getByCategory('technology');
  const jobsArticles = getByCategory('jobs');
  const entertainmentArticles = getByCategory('entertainment');
  const lifestyleArticles = getByCategory('lifestyle');
  const religionArticles = getByCategory('religion');

  const cricketArticles = getByCategory('cricket');
  const footballArticles = getByCategory('football');
  const videoArticles = getByCategory('video');
  const specialReports = getByCategory('special-report');
  const trendingArticles = publishedArticles.filter((a) => a.isTrending).slice(0, 6);

  // Render functions for each section key so CMS drag/reorder works dynamically
  const renderSection = (sectionKey: string) => {
    switch (sectionKey) {
      // =====================================================================
      // SECTION 1 — HERO NEWS GRID (FLAGSHIP FRONT-PAGE EDITION)
      // =====================================================================
      case 'hero':
        if (!heroArticle) return null;
        return (
          <section key="hero" className="mb-10">
            {/* Top Trending Topics & Live Edition Bar */}
            <div className="bg-[#F9FAFB] border border-[#E5E7EB] px-3.5 py-2 mb-5 flex flex-wrap items-center justify-between gap-3 rounded-[2px]">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="inline-flex items-center gap-1.5 font-extrabold text-[#111827] pr-2 border-r border-[#D1D5DB]">
                  <TrendingUp className="w-3.5 h-3.5 text-[#D32F2F]" />
                  <span>আলোচিত প্রসঙ্গ:</span>
                </span>
                {[
                  'ঢাকা-চট্টগ্রাম করিডোর',
                  'মেট্রোরেল এমআরটি-৫',
                  'বঙ্গোপসাগর লঘুচাপ',
                  'সর্বদলীয় সংলাপ',
                  'বাংলাদেশ ক্রিকেট',
                  'প্রবাসী আয়',
                ].map((topic) => (
                  <button
                    key={topic}
                    type="button"
                    onClick={() => navigateTo({ type: 'search', query: topic })}
                    className="text-xs font-semibold text-[#374151] hover:text-[#D32F2F] transition-colors cursor-pointer"
                  >
                    #{topic}
                  </button>
                ))}
              </div>

              {/* Lead Story Switcher Controls */}
              {heroLeadCandidates.length > 1 && (
                <div className="flex items-center gap-1.5 ml-auto">
                  <span className="text-[11px] font-bold text-[#6B7280] mr-1 hidden sm:inline">
                    প্রচ্ছদ লিড:
                  </span>
                  {heroLeadCandidates.map((cand, idx) => (
                    <button
                      key={cand.id}
                      type="button"
                      onClick={() => setActiveLeadIdx(idx)}
                      className={`w-6 h-6 text-xs font-extrabold transition-colors cursor-pointer ${
                        activeLeadIdx === idx
                          ? 'bg-[#D32F2F] text-white'
                          : 'bg-white text-[#111827] border border-[#D1D5DB] hover:border-[#111827]'
                      }`}
                      title={cand.headline}
                    >
                      {toBengaliNumber(idx + 1)}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Main 12-Column Editorial Hero Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-6 border-b border-[#E5E7EB]">
              {/* Left (7 cols): Flagship Lead Story + Lead Switcher Strip + 2 Sub-Hero Cards */}
              <div className="lg:col-span-7 lg:pr-6 lg:border-r lg:border-[#E5E7EB] flex flex-col justify-between">
                <div>
                  {/* Main Hero Card */}
                  <div className="border-t-4 border-[#111827] pt-3.5">
                    <NewsCard article={heroArticle} variant="hero" />
                  </div>

                  {/* Quick Lead Switcher Strip (4 Top Stories with Active Highlight) */}
                  {heroLeadCandidates.length > 1 && (
                    <div className="mt-4 pt-3.5 border-t border-[#E5E7EB]">
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {heroLeadCandidates.map((cand, idx) => {
                          const isCurrent = activeLeadIdx === idx;
                          return (
                            <button
                              key={cand.id}
                              type="button"
                              onClick={() => setActiveLeadIdx(idx)}
                              className={`text-left p-2.5 border transition-all cursor-pointer rounded-[2px] ${
                                isCurrent
                                  ? 'bg-[#FEF2F2] border-[#D32F2F] border-t-2'
                                  : 'bg-[#F9FAFB] border-[#E5E7EB] hover:bg-white hover:border-[#111827]'
                              }`}
                            >
                              <div className="flex items-center justify-between text-[10px] font-bold mb-1">
                                <span
                                  className={
                                    isCurrent ? 'text-[#D32F2F]' : 'text-[#6B7280]'
                                  }
                                >
                                  লিড ০{toBengaliNumber(idx + 1)} • {cand.categoryNameBn}
                                </span>
                              </div>
                              <p
                                className={`font-editorial font-bold text-xs leading-snug line-clamp-2 ${
                                  isCurrent ? 'text-[#D32F2F]' : 'text-[#111827]'
                                }`}
                              >
                                {cand.headline}
                              </p>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* 2 Sub-Hero Cards Below Lead */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5 pt-5 border-t border-[#E5E7EB]">
                  {remainingAfterHero.slice(0, 2).map((art) => (
                    <NewsCard key={art.id} article={art} variant="sub-hero" />
                  ))}
                </div>
              </div>

              {/* Right (5 cols): Flagship "প্রধান সংবাদসমূহ" Panel with Interactive Filter Tabs */}
              <div className="lg:col-span-5 flex flex-col justify-between">
                <div className="bg-white border border-[#E5E7EB] border-t-4 border-t-[#D32F2F] p-4 sm:p-5 rounded-[2px]">
                  {/* Header + Interactive Filter Tabs */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-[#111827] pb-3 mb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-5 bg-[#D32F2F] inline-block" />
                      <h2 className="font-editorial font-extrabold text-lg sm:text-xl text-[#111827]">
                        প্রধান সংবাদসমূহ
                      </h2>
                    </div>

                    {/* Interactive Segmented Tabs */}
                    <div className="flex items-center bg-[#F3F4F6] p-0.5 border border-[#E5E7EB]">
                      {[
                        { key: 'featured', label: 'নির্বাচিত' },
                        { key: 'latest', label: 'সর্বশেষ' },
                        { key: 'popular', label: 'জনপ্রিয়' },
                      ].map((t) => (
                        <button
                          key={t.key}
                          type="button"
                          onClick={() => setHeroRightTab(t.key as any)}
                          className={`px-2.5 py-1 text-xs font-bold transition-colors cursor-pointer ${
                            heroRightTab === t.key
                              ? 'bg-[#111827] text-white'
                              : 'text-[#4B5563] hover:text-[#D32F2F]'
                          }`}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 5 Rich Numbered Top Story Cards */}
                  <div className="divide-y divide-[#E5E7EB]">
                    {rightStackArticles.map((art, idx) => (
                      <NewsCard
                        key={art.id}
                        article={art}
                        variant="compact-right"
                        rank={idx + 1}
                      />
                    ))}
                  </div>

                  {/* Bottom Link to All Latest News */}
                  <div className="mt-3 pt-3 border-t border-[#E5E7EB] flex items-center justify-between">
                    <span className="text-xs text-[#6B7280]">
                      হালনাগাদ: এইমাত্র
                    </span>
                    <button
                      type="button"
                      onClick={() => navigateTo({ type: 'latest' })}
                      className="text-xs font-extrabold text-[#D32F2F] hover:text-[#111827] inline-flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <span>সকল প্রধান সংবাদ দেখুন</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Sidebar Ad Slot inside Hero Right Column */}
                <div className="mt-5">
                  <AdSlot slot="sidebar-ad" />
                </div>
              </div>
            </div>

            {/* Below Hero: Latest News Timeline / Live Update Strip */}
            <div className="bg-[#F9FAFB] border border-[#E5E7EB] border-l-4 border-l-[#D32F2F] p-4 mt-5 rounded-[2px]">
              <div className="flex items-center justify-between gap-2 mb-3 pb-2 border-b border-[#E5E7EB]">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#D32F2F]" />
                  <span className="font-editorial font-extrabold text-sm sm:text-base text-[#111827]">
                    সংবাদ টাইমলাইন (সর্বশেষ আপডেট)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => navigateTo({ type: 'latest' })}
                  className="text-xs font-bold text-[#D32F2F] hover:underline cursor-pointer"
                >
                  সব আপডেট →
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 divide-y sm:divide-y-0 sm:divide-x divide-[#E5E7EB]">
                {belowHeroTimeline.map((art, i) => (
                  <div
                    key={art.id}
                    onClick={() =>
                      navigateTo({ type: 'article', articleId: art.id })
                    }
                    className={`group cursor-pointer ${
                      i > 0 ? 'pt-3 sm:pt-0 sm:pl-4' : ''
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-[11px] text-[#6B7280] mb-1">
                      <span className="bg-[#111827] text-white font-mono-num font-bold text-[10px] px-1.5 py-0.2">
                        ০{toBengaliNumber(i + 1)}
                      </span>
                      <span className="font-bold text-[#D32F2F]">
                        {art.timeAgoBn}
                      </span>
                      <span>•</span>
                      <span>{art.categoryNameBn}</span>
                    </div>
                    <h4 className="font-editorial font-bold text-sm text-[#111827] group-hover:text-[#D32F2F] leading-snug line-clamp-2 transition-colors">
                      {art.headline}
                    </h4>
                  </div>
                ))}
              </div>
            </div>

            {/* Homepage Banner Ad Slot & Mobile Banner Ad Slot */}
            <AdSlot slot="homepage-banner" />
            <AdSlot slot="mobile-banner" />
          </section>
        );

      // =====================================================================
      // SECTION 2, 8 & 9 — LATEST NEWS ("সর্বশেষ সংবাদ") + MOST READ ("সর্বাধিক পঠিত") + TRENDING ("আলোচিত")
      // =====================================================================
      case 'latest_and_most_read':
        return (
          <section key="latest_and_most_read" className="mb-12">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left 8 Cols: SECTION 2 — LATEST NEWS ("সর্বশেষ সংবাদ") + SECTION 9 — TRENDING ("আলোচিত") */}
              <div className="lg:col-span-8">
                <SectionHeader
                  titleBn="সর্বশেষ সংবাদ"
                  subtitleBn="সারাদেশ ও বিশ্বের তাৎক্ষণিক সংবাদের ধারাবাহিক প্রবাহ"
                  onSeeMore={() => navigateTo({ type: 'latest' })}
                />

                <div className="bg-white border border-[#E5E7EB] px-4 sm:px-5 rounded-[2px] divide-y divide-[#E5E7EB]">
                  {publishedArticles
                    .slice(0, latestVisibleCount)
                    .map((art, index) => (
                      <React.Fragment key={art.id}>
                        <NewsCard
                          article={art}
                          variant="horizontal-feed"
                        />
                        {index === 1 && (
                          <div className="py-3">
                            <AdSlot slot="in-feed" instanceKey="home-feed" />
                          </div>
                        )}
                      </React.Fragment>
                    ))}
                </div>

                {/* "আরও সংবাদ" Button */}
                <div className="mt-4 flex items-center justify-center">
                  {latestVisibleCount < publishedArticles.length ? (
                    <button
                      onClick={() =>
                        setLatestVisibleCount((prev) => prev + 5)
                      }
                      className="w-full sm:w-auto px-8 py-2.5 bg-[#F9FAFB] hover:bg-[#111827] text-[#111827] hover:text-white border border-[#111827] font-editorial font-bold text-sm transition-colors cursor-pointer"
                    >
                      আরও সংবাদ দেখুন ({toBengaliNumber(publishedArticles.length - latestVisibleCount)}+)
                    </button>
                  ) : (
                    <button
                      onClick={() => navigateTo({ type: 'latest' })}
                      className="px-8 py-2.5 bg-[#111827] text-white font-editorial font-bold text-sm cursor-pointer"
                    >
                      সর্বশেষ সংবাদের পূর্ণাঙ্গ পাতা →
                    </button>
                  )}
                </div>

                {/* SECTION 9 — TRENDING ("আলোচিত") */}
                <div className="mt-8">
                  <div className="flex items-center gap-2 border-b-2 border-[#111827] pb-2 mb-4">
                    <TrendingUp className="w-5 h-5 text-[#D32F2F]" />
                    <h3 className="font-editorial font-extrabold text-xl text-[#111827]">
                      আলোচিত
                    </h3>
                    <span className="text-xs text-[#6B7280] ml-2">
                      পাঠকদের আলোচনায় শীর্ষে থাকা সংবাদ
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                    {trendingArticles.map((art) => (
                      <NewsCard
                        key={art.id}
                        article={art}
                        variant="trending-compact"
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Right 4 Cols: SECTION 8 — MOST READ ("সর্বাধিক পঠিত" 01-08) + Daily Utilities (Prayer, Market, Poll) */}
              <div className="lg:col-span-4 space-y-6">
                <MostReadWidget />
                <AdSlot slot="sidebar-ad" />
                <DailyUtilitiesWidget />
              </div>
            </div>
          </section>
        );

      // =====================================================================
      // SECTION — COUNTRYWIDE ("সারাদেশ: বিভাগ, জেলা ও উপজেলার সংবাদ")
      // =====================================================================
      case 'countrywide':
        return <CountrywideHomepageSection key="countrywide" />;

      // =====================================================================
      // SECTION — WEATHER ("আবহাওয়ার খবর ও ৮ বিভাগের লাইভ পূর্বাভাস")
      // =====================================================================
      case 'weather':
        return <WeatherHomepageSection key="weather" />;

      // =====================================================================
      // SECTION 3 — NEWS CATEGORY GRID (জাতীয়, রাজনীতি, আন্তর্জাতিক + অর্থনীতি, প্রযুক্তি, বিনোদন, জীবনযাপন, ধর্ম)
      // =====================================================================
      case 'category_grid':
        return (
          <section key="category_grid" className="mb-12">
            {/* Primary 3-Column Newspaper Category Grid: জাতীয় | রাজনীতি | আন্তর্জাতিক */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-7 pb-8 border-b border-[#E5E7EB]">
              {/* জাতীয় (National) — Main story + 4 secondary stories */}
              <div className="flex flex-col">
                <SectionHeader
                  titleBn="জাতীয়"
                  onSeeMore={() =>
                    navigateTo({ type: 'category', categorySlug: 'national' })
                  }
                />
                {nationalArticles[0] && (
                  <div className="pb-4 mb-4 border-b border-[#E5E7EB]">
                    <NewsCard article={nationalArticles[0]} variant="sub-hero" />
                  </div>
                )}
                <div className="divide-y divide-[#E5E7EB]">
                  {nationalArticles.slice(1, 5).map((art) => (
                    <NewsCard
                      key={art.id}
                      article={art}
                      variant="compact-right"
                    />
                  ))}
                </div>
              </div>

              {/* রাজনীতি (Politics) — Main story + Multiple smaller stories */}
              <div className="flex flex-col lg:border-x lg:border-[#E5E7EB] lg:px-6">
                <SectionHeader
                  titleBn="রাজনীতি"
                  onSeeMore={() =>
                    navigateTo({ type: 'category', categorySlug: 'politics' })
                  }
                />
                {politicsArticles[0] && (
                  <div className="pb-4 mb-4 border-b border-[#E5E7EB]">
                    <NewsCard article={politicsArticles[0]} variant="sub-hero" />
                  </div>
                )}
                <div className="divide-y divide-[#E5E7EB]">
                  {[...politicsArticles.slice(1), ...nationalArticles.slice(2, 4)]
                    .slice(0, 4)
                    .map((art) => (
                      <NewsCard
                        key={art.id}
                        article={art}
                        variant="compact-right"
                      />
                    ))}
                </div>
              </div>

              {/* আন্তর্জাতিক (International) — Main story + related cards */}
              <div className="flex flex-col">
                <SectionHeader
                  titleBn="আন্তর্জাতিক"
                  onSeeMore={() =>
                    navigateTo({
                      type: 'category',
                      categorySlug: 'international',
                    })
                  }
                />
                {internationalArticles[0] && (
                  <div className="pb-4 mb-4 border-b border-[#E5E7EB]">
                    <NewsCard
                      article={internationalArticles[0]}
                      variant="sub-hero"
                    />
                  </div>
                )}
                <div className="divide-y divide-[#E5E7EB]">
                  {internationalArticles.slice(1, 5).map((art) => (
                    <NewsCard
                      key={art.id}
                      article={art}
                      variant="compact-right"
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Between-News-Section Ad Slot */}
            <AdSlot slot="between-section" />

            {/* Secondary 5-Column Category Strip: অর্থনীতি | চাকরি | প্রযুক্তি | বিনোদন | জীবনযাপন ও ধর্ম */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 mt-8">
              {[
                {
                  title: 'অর্থনীতি',
                  slug: 'economy',
                  items: economyArticles,
                },
                {
                  title: 'চাকরি',
                  slug: 'jobs',
                  items: jobsArticles,
                },
                {
                  title: 'প্রযুক্তি',
                  slug: 'technology',
                  items: technologyArticles,
                },
                {
                  title: 'বিনোদন',
                  slug: 'entertainment',
                  items: entertainmentArticles,
                },
                {
                  title: 'জীবনযাপন ও ধর্ম',
                  slug: 'lifestyle',
                  items: [...lifestyleArticles, ...religionArticles],
                },
              ].map((block) => (
                <div
                  key={block.slug}
                  className="bg-white border border-[#E5E7EB] p-4 rounded-[2px]"
                >
                  <div className="flex items-center justify-between border-b-2 border-[#111827] pb-2 mb-3">
                    <h3 className="font-editorial font-bold text-lg text-[#111827]">
                      {block.title}
                    </h3>
                    <button
                      onClick={() =>
                        navigateTo({
                          type: 'category',
                          categorySlug: block.slug,
                        })
                      }
                      className="text-xs font-bold text-[#D32F2F] hover:underline cursor-pointer"
                    >
                      সব খবর →
                    </button>
                  </div>
                  {block.items[0] && (
                    <div className="mb-3 pb-3 border-b border-[#E5E7EB]">
                      <NewsCard article={block.items[0]} variant="sub-hero" />
                    </div>
                  )}
                  <div className="space-y-2.5">
                    {block.items.slice(1, 3).map((art) => (
                      <div
                        key={art.id}
                        onClick={() =>
                          navigateTo({ type: 'article', articleId: art.id })
                        }
                        className="group cursor-pointer pt-1"
                      >
                        <h4 className="font-editorial font-bold text-sm text-[#111827] group-hover:text-[#D32F2F] leading-snug">
                          • {art.headline}
                        </h4>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        );

      // =====================================================================
      // SECTION 4 — SPORTS ("খেলাধুলা")
      // =====================================================================
      case 'sports': {
        const sportsPool =
          sportsTab === 'cricket'
            ? cricketArticles
            : sportsTab === 'football'
            ? footballArticles
            : [...cricketArticles, ...footballArticles];
        const featuredSports = sportsPool[0] || cricketArticles[0];
        const smallerSports = sportsPool.slice(1, 5);

        return (
          <section
            key="sports"
            className="mb-12 bg-[#0F172A] text-white border-y-2 border-[#111827] p-5 sm:p-7 rounded-[2px]"
          >
            {/* Sports Header + Live Update Indicator + Tabs */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 mb-5 border-b border-slate-700">
              <div className="flex items-center gap-3">
                <span className="w-3 h-7 bg-[#10B981] inline-block" />
                <div>
                  <div className="flex items-center gap-2.5">
                    <h2 className="font-editorial font-extrabold text-2xl sm:text-3xl text-white">
                      খেলাধুলা
                    </h2>
                    <span className="inline-flex items-center gap-1.5 bg-[#D32F2F] text-white text-[11px] font-bold px-2.5 py-0.5 uppercase tracking-wider">
                      <Radio className="w-3 h-3 animate-pulse" />
                      লাইভ আপডেট
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    ক্রিকেট, ফুটবল ও আন্তর্জাতিক ক্রীড়াঙ্গনের তাৎক্ষণিক স্কোর ও প্রতিবেদন
                  </p>
                </div>
              </div>

              {/* Tabs: ক্রিকেট | ফুটবল | অন্যান্য */}
              <div className="flex items-center gap-1.5 bg-slate-800/90 p-1 border border-slate-700 self-start md:self-auto">
                {[
                  { id: 'cricket', label: 'ক্রিকেট' },
                  { id: 'football', label: 'ফুটবল' },
                  { id: 'other', label: 'অন্যান্য' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setSportsTab(tab.id as any)}
                    className={`px-4 py-1.5 text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
                      sportsTab === tab.id
                        ? 'bg-[#10B981] text-[#0F172A]'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sports Ticker */}
            <div className="bg-slate-900 border border-slate-800 px-3.5 py-2 mb-6 flex items-center gap-3 overflow-x-auto no-scrollbar">
              <span className="text-[11px] font-bold text-[#10B981] uppercase tracking-wider shrink-0 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5" /> খেলার টিকার:
              </span>
              <div className="flex items-center gap-6 text-xs text-slate-300 whitespace-nowrap">
                {matchScores.map((m) => (
                  <span key={m.id} className="inline-flex items-center gap-2">
                    <span
                      className={`px-1.5 py-0.2 text-[10px] font-bold ${
                        m.status === 'LIVE'
                          ? 'bg-[#D32F2F] text-white'
                          : m.status === 'RESULT'
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-700 text-slate-200'
                      }`}
                    >
                      {m.statusTextBn}
                    </span>
                    <strong className="text-white">
                      {m.team1} ({m.team1Score}) বনাম {m.team2} ({m.team2Score})
                    </strong>
                    <span className="text-slate-400">— {m.summaryBn}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Match / Result Scorecards Strip */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {matchScores
                .filter((m) =>
                  sportsTab === 'other' ? true : m.sport === sportsTab
                )
                .slice(0, 3)
                .map((match) => (
                  <div
                    key={match.id}
                    className="bg-slate-900/90 border border-slate-700/80 p-4 rounded-[2px] flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2.5">
                        <span className="text-[11px] text-slate-400 font-medium truncate">
                          {match.tournament}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 shrink-0 ${
                            match.status === 'LIVE'
                              ? 'bg-[#D32F2F] text-white'
                              : match.status === 'RESULT'
                              ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {match.statusTextBn}
                        </span>
                      </div>

                      <div className="space-y-1.5 my-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-bold text-white">
                            {match.team1}
                          </span>
                          <span className="font-mono-num font-bold text-[#10B981]">
                            {match.team1Score}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-bold text-slate-200">
                            {match.team2}
                          </span>
                          <span className="font-mono-num font-semibold text-slate-300">
                            {match.team2Score}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2.5 mt-2 border-t border-slate-800 text-[11px] text-amber-300 font-medium">
                      {match.summaryBn}
                    </div>
                  </div>
                ))}
            </div>

            {/* 1 Large Featured Sports Story + 4 Smaller Sports Cards */}
            {featuredSports && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div
                  onClick={() =>
                    navigateTo({ type: 'article', articleId: featuredSports.id })
                  }
                  className="lg:col-span-7 group cursor-pointer bg-slate-900 border border-slate-800 p-4 rounded-[2px]"
                >
                  <div className="aspect-16/9 w-full overflow-hidden mb-3.5 bg-slate-800">
                    <img
                      src={featuredSports.featuredImage}
                      alt={featuredSports.headline}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <span className="text-xs font-bold text-[#10B981] uppercase">
                    {featuredSports.subcategory || featuredSports.categoryNameBn}
                  </span>
                  <h3 className="font-editorial font-bold text-xl sm:text-2xl text-white group-hover:text-[#10B981] leading-snug mt-1 mb-2 transition-colors">
                    {featuredSports.headline}
                  </h3>
                  <p className="text-sm text-slate-300 line-clamp-2 leading-relaxed">
                    {featuredSports.summary}
                  </p>
                </div>

                <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3.5">
                  {[...smallerSports, ...footballArticles].slice(0, 4).map((art) => (
                    <div
                      key={art.id}
                      onClick={() =>
                        navigateTo({ type: 'article', articleId: art.id })
                      }
                      className="group cursor-pointer bg-slate-900/70 hover:bg-slate-900 border border-slate-800 p-3 flex items-start gap-3.5 rounded-[2px] transition-colors"
                    >
                      <img
                        src={art.featuredImage}
                        alt={art.headline}
                        className="w-24 sm:w-28 aspect-16/10 object-cover shrink-0 bg-slate-800"
                      />
                      <div className="min-w-0">
                        <span className="text-[11px] font-bold text-[#10B981]">
                          {art.subcategory || art.categoryNameBn}
                        </span>
                        <h4 className="font-editorial font-bold text-sm text-white group-hover:text-[#10B981] leading-snug line-clamp-2 mt-0.5">
                          {art.headline}
                        </h4>
                        <span className="text-[11px] text-slate-400 mt-1 block">
                          {art.timeAgoBn}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        );
      }

      // =====================================================================
      // SECTION 5 — CRICKET ("ক্রিকেট")
      // =====================================================================
      case 'cricket': {
        const cricketSubTags = [
          'ALL',
          'Bangladesh Cricket',
          'International Cricket',
          'BPL',
          'IPL',
          'PSL',
          'ICC',
        ];
        const filteredCricket =
          cricketFilter === 'ALL'
            ? cricketArticles
            : cricketArticles.filter(
                (a) =>
                  a.subcategory.toLowerCase() === cricketFilter.toLowerCase()
              );
        const displayCricket =
          filteredCricket.length > 0 ? filteredCricket : cricketArticles;

        return (
          <section key="cricket" className="mb-12">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-[#111827] pb-3 mb-5">
              <div className="flex items-center gap-2.5">
                <span className="w-3 h-6 bg-[#047857] inline-block" />
                <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-[#111827]">
                  ক্রিকেট
                </h2>
              </div>

              {/* Dedicated Cricket Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                {cricketSubTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setCricketFilter(tag)}
                    className={`px-3 py-1 text-xs font-bold border whitespace-nowrap transition-colors cursor-pointer ${
                      cricketFilter === tag
                        ? 'bg-[#047857] text-white border-[#047857]'
                        : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:border-[#111827]'
                    }`}
                  >
                    {tag === 'ALL' ? 'সব ক্রিকেট' : tag}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {displayCricket.map((art) => (
                <NewsCard key={art.id} article={art} variant="vertical" />
              ))}
            </div>
          </section>
        );
      }

      // =====================================================================
      // SECTION 6 — FOOTBALL ("ফুটবল")
      // =====================================================================
      case 'football': {
        const footballSubTags = [
          'ALL',
          'Bangladesh Football',
          'International Football',
          'FIFA',
          'Champions League',
          'Premier League',
          'La Liga',
        ];
        const filteredFootball =
          footballFilter === 'ALL'
            ? footballArticles
            : footballArticles.filter(
                (a) =>
                  a.subcategory.toLowerCase() === footballFilter.toLowerCase()
              );
        const displayFootball =
          filteredFootball.length > 0 ? filteredFootball : footballArticles;

        return (
          <section key="football" className="mb-12">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b-2 border-[#111827] pb-3 mb-5">
              <div className="flex items-center gap-2.5">
                <span className="w-3 h-6 bg-[#1D4ED8] inline-block" />
                <h2 className="font-editorial font-extrabold text-xl sm:text-2xl text-[#111827]">
                  ফুটবল
                </h2>
              </div>

              {/* Dedicated Football Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                {footballSubTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setFootballFilter(tag)}
                    className={`px-3 py-1 text-xs font-bold border whitespace-nowrap transition-colors cursor-pointer ${
                      footballFilter === tag
                        ? 'bg-[#1D4ED8] text-white border-[#1D4ED8]'
                        : 'bg-[#F9FAFB] text-[#4B5563] border-[#E5E7EB] hover:border-[#111827]'
                    }`}
                  >
                    {tag === 'ALL' ? 'সব ফুটবল' : tag}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {displayFootball.map((art) => (
                <NewsCard key={art.id} article={art} variant="vertical" />
              ))}
            </div>

            <AdSlot slot="desktop-leaderboard" />
          </section>
        );
      }

      // =====================================================================
      // SECTION 7 — VIDEO NEWS ("ভিডিও গ্যালারি ও মাল্টিমিডিয়া")
      // =====================================================================
      case 'video': {
        const videoSubcategories = [
          { id: 'ALL', label: 'সব ভিডিও' },
          { id: 'বিশেষ প্রতিবেদন', label: 'বিশেষ প্রতিবেদন' },
          { id: 'মাঠের খেলা', label: 'মাঠের খেলা' },
          { id: 'সময়ের ক্যামেরা', label: 'সময়ের ক্যামেরা' },
          { id: 'টকশো', label: 'টকশো ও সংলাপ' },
        ];

        const filteredVideos =
          videoCategoryFilter === 'ALL'
            ? videoArticles
            : videoArticles.filter(
                (v) =>
                  (v.subcategory || '').toLowerCase() ===
                  videoCategoryFilter.toLowerCase()
              );
        const displayVideos =
          filteredVideos.length > 0 ? filteredVideos : videoArticles;

        const activeStageVideo =
          displayVideos.find((v) => v.id === selectedHomeVideoId) ||
          displayVideos[0];
        const playlistVideos = displayVideos;
        if (!activeStageVideo) return null;

        return (
          <section
            key="video"
            className="mb-12 bg-gradient-to-b from-[#090D16] via-[#111827] to-[#0B0F19] text-white border-y-4 border-[#D32F2F] p-5 sm:p-8 rounded-[2px] shadow-xl"
          >
            {/* Studio Header + Category Filter Bar */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 mb-6 border-b border-slate-800">
              <div className="flex items-start sm:items-center gap-3.5">
                <div className="w-11 h-11 rounded-[2px] bg-[#D32F2F] flex items-center justify-center shrink-0 shadow-lg">
                  <Film className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2.5">
                    <h2 className="font-editorial font-extrabold text-2xl sm:text-3xl text-white tracking-tight">
                      ভিডিও গ্যালারি ও মাল্টিমিডিয়া
                    </h2>
                    <span className="inline-flex items-center gap-1.5 bg-[#D32F2F]/20 text-[#FCA5A5] border border-[#D32F2F]/50 text-[11px] font-bold px-2.5 py-0.5">
                      <span className="w-2 h-2 rounded-full bg-[#D32F2F] animate-ping" />
                      HD স্টুডিও
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                    সরেজমিন ভিডিও প্রতিবেদন, খেলার হাইলাইটস, ড্রোন ফুটেজ ও বিশেষ সংলাপ
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1 bg-slate-900/90 p-1 border border-slate-800 overflow-x-auto no-scrollbar">
                  {videoSubcategories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setVideoCategoryFilter(cat.id);
                        setIsHomeVideoPlaying(false);
                      }}
                      className={`px-3 py-1.5 text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                        videoCategoryFilter === cat.id
                          ? 'bg-[#D32F2F] text-white'
                          : 'text-slate-300 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => navigateTo({ type: 'video' })}
                  className="px-3.5 py-2 bg-white/10 hover:bg-[#D32F2F] text-white text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer border border-white/15"
                >
                  <span>সব ভিডিও ({toBengaliNumber(videoArticles.length)})</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Main Cinema Stage (7 Cols) + Interactive Playlist Queue (5 Cols) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left 7 Columns: Featured Theater Player */}
              <div className="lg:col-span-7 flex flex-col justify-between bg-[#060911] border border-slate-800/90 p-4 sm:p-5 rounded-[2px]">
                <div>
                  <div className="relative aspect-16/9 w-full overflow-hidden bg-black border border-slate-800 rounded-[2px] mb-4 group">
                    <img
                      src={activeStageVideo.featuredImage}
                      alt={activeStageVideo.headline}
                      className={`w-full h-full object-cover transition-all duration-700 ${
                        isHomeVideoPlaying
                          ? 'scale-105 opacity-45'
                          : 'opacity-85 group-hover:scale-105'
                      }`}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-black/20" />

                    {/* Top Overlay Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="bg-[#D32F2F] text-white text-xs font-bold px-2.5 py-1 flex items-center gap-1.5 shadow">
                          <Play className="w-3 h-3 fill-current" />
                          {activeStageVideo.subcategory || 'ভিডিও প্রতিবেদন'}
                        </span>
                        <span className="bg-black/80 text-amber-400 border border-amber-400/30 text-[11px] font-bold px-2 py-0.5">
                          1080p HD
                        </span>
                      </div>
                      {activeStageVideo.videoDuration && (
                        <span className="bg-black/90 text-white font-mono-num text-xs font-bold px-2.5 py-1 border border-slate-700">
                          ⏱ {activeStageVideo.videoDuration}
                        </span>
                      )}
                    </div>

                    {/* Center Play / Active Broadcast Indicator */}
                    {isHomeVideoPlaying ? (
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-black/55 backdrop-blur-[2px]">
                        <div className="flex items-center gap-1.5 mb-3">
                          <span className="w-2 h-6 bg-[#D32F2F] animate-pulse" />
                          <span className="w-2 h-9 bg-amber-400 animate-pulse" />
                          <span className="w-2 h-5 bg-[#10B981] animate-pulse" />
                          <span className="w-2 h-10 bg-[#D32F2F] animate-pulse" />
                          <span className="w-2 h-7 bg-amber-400 animate-pulse" />
                        </div>
                        <span className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
                          ▶ bd7news মাল্টিমিডিয়া প্লেয়ার চলছে
                        </span>
                        <p className="font-editorial font-bold text-base sm:text-lg text-white max-w-lg line-clamp-2 mb-4">
                          {activeStageVideo.headline}
                        </p>
                        <div className="flex flex-wrap items-center justify-center gap-2.5">
                          <button
                            onClick={() => setIsHomeVideoPlaying(false)}
                            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5 border border-slate-600 cursor-pointer"
                          >
                            <Pause className="w-3.5 h-3.5" /> বিরতি দিন
                          </button>
                          <button
                            onClick={() => {
                              setIsHomeVideoPlaying(false);
                              setActiveVideoArticle(activeStageVideo);
                            }}
                            className="px-4 py-1.5 bg-[#D32F2F] hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                          >
                            <Maximize2 className="w-3.5 h-3.5" /> সিনেমা মোডে দেখুন
                          </button>
                          <button
                            onClick={() =>
                              navigateTo({
                                type: 'article',
                                articleId: activeStageVideo.id,
                              })
                            }
                            className="px-4 py-1.5 bg-white text-[#111827] hover:bg-amber-300 text-xs font-bold cursor-pointer"
                          >
                            পূর্ণ প্রতিবেদন পড়ুন →
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div
                        onClick={() => setIsHomeVideoPlaying(true)}
                        className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer"
                      >
                        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#D32F2F] hover:bg-red-600 text-white flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all border-4 border-white/25">
                          <Play className="w-8 h-8 fill-current ml-1" />
                        </div>
                        <span className="mt-2.5 bg-black/80 text-white text-xs font-bold px-3 py-1 border border-white/15">
                          ভিডিওটি প্লে করতে ক্লিক করুন
                        </span>
                      </div>
                    )}

                    {/* Bottom Progress Bar */}
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-800">
                      <div
                        className={`h-full bg-[#D32F2F] transition-all duration-500 ${
                          isHomeVideoPlaying ? 'w-2/3' : 'w-1/4'
                        }`}
                      />
                    </div>
                  </div>

                  {/* Active Video Metadata & Headline */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[#FCA5A5] font-bold">
                        {activeStageVideo.reporter}
                      </span>
                      <span>•</span>
                      <span>{activeStageVideo.timeAgoBn}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 text-slate-300">
                        <Eye className="w-3.5 h-3.5 text-[#FCA5A5]" />
                        {toBengaliNumber(activeStageVideo.views)} বার দেখা হয়েছে
                      </span>
                    </div>
                  </div>

                  <h3
                    onClick={() => setActiveVideoArticle(activeStageVideo)}
                    className="font-editorial font-extrabold text-xl sm:text-2xl text-white hover:text-[#FCA5A5] leading-snug mb-2.5 cursor-pointer transition-colors"
                  >
                    {activeStageVideo.headline}
                  </h3>
                  <p className="text-sm text-slate-300 leading-relaxed line-clamp-2 mb-4">
                    {activeStageVideo.summary}
                  </p>
                </div>

                {/* Stage Action Buttons */}
                <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsHomeVideoPlaying((p) => !p)}
                      className="px-4 py-2 bg-[#D32F2F] hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {isHomeVideoPlaying ? (
                        <>
                          <Pause className="w-3.5 h-3.5" /> প্লেয়ার থামান
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 fill-current" /> এখানেই চালান
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => {
                        setVideoModalProgress(15);
                        setIsModalVideoPlaying(true);
                        setActiveVideoArticle(activeStageVideo);
                      }}
                      className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
                    >
                      <Maximize2 className="w-3.5 h-3.5" /> বড় পর্দায় দেখুন
                    </button>
                  </div>

                  <button
                    onClick={() =>
                      navigateTo({
                        type: 'article',
                        articleId: activeStageVideo.id,
                      })
                    }
                    className="text-xs font-bold text-amber-400 hover:underline cursor-pointer"
                  >
                    বিস্তারিত সংবাদ পড়ুন →
                  </button>
                </div>
              </div>

              {/* Right 5 Columns: Interactive Video Playlist Queue */}
              <div className="lg:col-span-5 flex flex-col bg-[#060911] border border-slate-800/90 rounded-[2px] overflow-hidden">
                <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-4 bg-[#D32F2F] inline-block" />
                    <h3 className="font-editorial font-bold text-base text-white">
                      ভিডিও প্লে-লিস্ট ({toBengaliNumber(playlistVideos.length)}টি ভিডিও)
                    </h3>
                  </div>
                  <span className="text-[11px] text-amber-400 font-semibold">
                    ক্লিক করে পরিবর্তন করুন
                  </span>
                </div>

                <div className="divide-y divide-slate-800/80 max-h-[430px] overflow-y-auto">
                  {playlistVideos.map((vid, idx) => {
                    const isCurrent = vid.id === activeStageVideo.id;
                    return (
                      <div
                        key={vid.id}
                        onClick={() => {
                          setSelectedHomeVideoId(vid.id);
                          setIsHomeVideoPlaying(true);
                        }}
                        className={`p-3.5 flex items-start gap-3.5 cursor-pointer transition-colors ${
                          isCurrent
                            ? 'bg-[#D32F2F]/15 border-l-4 border-l-[#D32F2F]'
                            : 'hover:bg-slate-900/80'
                        }`}
                      >
                        <div className="text-xs font-mono-num font-bold text-slate-500 pt-1 w-5 shrink-0">
                          {isCurrent ? (
                            <span className="text-[#D32F2F] animate-pulse">▶</span>
                          ) : (
                            toBengaliNumber(idx + 1)
                          )}
                        </div>

                        <div className="relative w-32 sm:w-36 aspect-16/9 shrink-0 overflow-hidden bg-slate-900 border border-slate-700 rounded-[2px]">
                          <img
                            src={vid.featuredImage}
                            alt={vid.headline}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                isCurrent
                                  ? 'bg-[#D32F2F] text-white'
                                  : 'bg-black/75 text-white'
                              }`}
                            >
                              <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                            </div>
                          </div>
                          {vid.videoDuration && (
                            <span className="absolute bottom-1 right-1 bg-black/90 text-white font-mono-num text-[10px] font-bold px-1.5 py-0.5">
                              {vid.videoDuration}
                            </span>
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[11px] font-bold text-[#FCA5A5]">
                              {vid.subcategory || 'ভিডিও'}
                            </span>
                            {isCurrent && (
                              <span className="bg-[#D32F2F] text-white text-[10px] font-bold px-1.5 py-0.2">
                                এখন চলছে
                              </span>
                            )}
                          </div>
                          <h4
                            className={`font-editorial font-bold text-sm leading-snug line-clamp-2 ${
                              isCurrent
                                ? 'text-amber-300'
                                : 'text-white hover:text-[#FCA5A5]'
                            }`}
                          >
                            {vid.headline}
                          </h4>
                          <span className="text-[11px] text-slate-400 mt-1 block">
                            {vid.timeAgoBn} • {toBengaliNumber(vid.views)} ভিউ
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Bottom 4-Column Quick Video Reel Strip */}
            <div className="mt-6 pt-6 border-t border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5 fill-current" /> আরও জনপ্রিয় ভিডিও প্রতিবেদন
                </span>
                <button
                  onClick={() => navigateTo({ type: 'video' })}
                  className="text-xs text-slate-300 hover:text-white font-bold cursor-pointer"
                >
                  ভিডিও গ্যালারি পাতায় যান →
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {videoArticles.slice(0, 4).map((vid) => (
                  <div
                    key={vid.id}
                    onClick={() => {
                      setVideoModalProgress(12);
                      setIsModalVideoPlaying(true);
                      setActiveVideoArticle(vid);
                    }}
                    className="bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-slate-600 p-3 rounded-[2px] transition-all cursor-pointer"
                  >
                    <NewsCard article={vid} variant="video" />
                  </div>
                ))}
              </div>
            </div>
          </section>
        );
      }

      // =====================================================================
      // SECTION 10 — PHOTO GALLERY ("ছবিতে আজ — ফটো গ্যালারি")
      // =====================================================================
      case 'photo_gallery': {
        const galleryCategories = [
          'ALL',
          ...Array.from(new Set(photoGalleries.map((g) => g.categoryBn))),
        ];
        const filteredGalleries =
          homeGalleryCategory === 'ALL'
            ? photoGalleries
            : photoGalleries.filter((g) => g.categoryBn === homeGalleryCategory);
        const displayGalleries =
          filteredGalleries.length > 0 ? filteredGalleries : photoGalleries;

        const mainGallery =
          displayGalleries.find((g) => g.id === homeActiveGalleryId) ||
          displayGalleries[0];
        if (!mainGallery) return null;

        const safeSlideIndex =
          homeSlideIndex < mainGallery.photos.length ? homeSlideIndex : 0;
        const currentSlidePhoto =
          mainGallery.photos[safeSlideIndex] || mainGallery.photos[0];

        return (
          <section
            key="photo_gallery"
            className="mb-12 bg-[#FDFBF7] border-2 border-[#111827] p-5 sm:p-8 rounded-[2px]"
          >
            {/* Header + Category Filter Pills */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 mb-6 border-b-2 border-[#111827]">
              <div className="flex items-start sm:items-center gap-3.5">
                <div className="w-11 h-11 rounded-[2px] bg-[#111827] text-white flex items-center justify-center shrink-0">
                  <Camera className="w-6 h-6 text-[#D32F2F]" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2.5">
                    <h2 className="font-editorial font-extrabold text-2xl sm:text-3xl text-[#111827]">
                      ছবিতে আজ — ফটো গ্যালারি
                    </h2>
                    <span className="bg-[#D32F2F] text-white text-[11px] font-bold px-2.5 py-0.5">
                      আলোকচিত্র অ্যালবাম
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-[#4B5563] mt-0.5">
                    সংবাদের পেছনের মুহূর্ত, প্রকৃতির রূপ ও আলোকচিত্রীর চোখে বাংলাদেশ
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                  {galleryCategories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => {
                        setHomeGalleryCategory(cat);
                        setHomeSlideIndex(0);
                      }}
                      className={`px-3 py-1.5 text-xs font-bold border transition-colors cursor-pointer whitespace-nowrap ${
                        homeGalleryCategory === cat
                          ? 'bg-[#111827] text-white border-[#111827]'
                          : 'bg-white text-[#374151] border-[#D1D5DB] hover:border-[#111827]'
                      }`}
                    >
                      {cat === 'ALL' ? 'সব অ্যালবাম' : cat}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => navigateTo({ type: 'photo-gallery' })}
                  className="px-3.5 py-1.5 bg-[#D32F2F] hover:bg-[#B91C1C] text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>সব ফটো গ্যালারি</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left 7 Columns: Interactive Main Photo Story Stage with Filmstrip */}
              <div className="lg:col-span-7 bg-[#111827] text-white border border-[#111827] rounded-[2px] overflow-hidden flex flex-col justify-between">
                <div>
                  {/* Main Photo Canvas */}
                  <div className="relative aspect-16/10 bg-black overflow-hidden group">
                    <img
                      src={currentSlidePhoto?.url || mainGallery.coverImage}
                      alt={mainGallery.titleBn}
                      className="w-full h-full object-cover transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/30" />

                    {/* Top Controls Bar */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="bg-[#D32F2F] text-white text-xs font-bold px-3 py-1 flex items-center gap-1.5 shadow">
                          <Images className="w-3.5 h-3.5" />
                          <span>
                            ছবি {toBengaliNumber(safeSlideIndex + 1)} /{' '}
                            {toBengaliNumber(mainGallery.photos.length)}
                          </span>
                        </span>
                        <span className="bg-black/75 text-amber-300 text-xs font-bold px-2.5 py-1 border border-white/15">
                          {mainGallery.categoryBn}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setHomeAutoSlide((prev) => !prev)}
                          className={`px-2.5 py-1 text-[11px] font-bold border transition-colors cursor-pointer flex items-center gap-1 ${
                            homeAutoSlide
                              ? 'bg-amber-400 text-[#111827] border-amber-400'
                              : 'bg-black/75 text-white border-white/20 hover:bg-black'
                          }`}
                        >
                          {homeAutoSlide ? (
                            <>
                              <Pause className="w-3 h-3" /> স্লাইডশো চলছে
                            </>
                          ) : (
                            <>
                              <Play className="w-3 h-3 fill-current" /> অটো স্লাইডশো
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => {
                            setLightboxZoom(1);
                            setActiveGallery(mainGallery);
                            setActivePhotoIndex(safeSlideIndex);
                          }}
                          className="p-1.5 bg-black/75 hover:bg-[#D32F2F] text-white border border-white/20 transition-colors cursor-pointer"
                          title="পূর্ণ পর্দায় দেখুন"
                        >
                          <Maximize2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Left / Right Slide Arrows */}
                    {mainGallery.photos.length > 1 && (
                      <>
                        <button
                          onClick={() =>
                            setHomeSlideIndex((prev) =>
                              prev === 0
                                ? mainGallery.photos.length - 1
                                : prev - 1
                            )
                          }
                          className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/75 hover:bg-[#D32F2F] text-white flex items-center justify-center border border-white/20 transition-colors cursor-pointer"
                          aria-label="Previous photo"
                        >
                          <ChevronLeft className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() =>
                            setHomeSlideIndex((prev) =>
                              prev === mainGallery.photos.length - 1
                                ? 0
                                : prev + 1
                            )
                          }
                          className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/75 hover:bg-[#D32F2F] text-white flex items-center justify-center border border-white/20 transition-colors cursor-pointer"
                          aria-label="Next photo"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </button>
                      </>
                    )}

                    {/* Bottom Title & Caption Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5">
                      <span className="text-xs text-gray-300 block mb-1">
                        প্রকাশ: {mainGallery.dateBn}
                      </span>
                      <h3
                        onClick={() => {
                          setLightboxZoom(1);
                          setActiveGallery(mainGallery);
                          setActivePhotoIndex(safeSlideIndex);
                        }}
                        className="font-editorial font-extrabold text-xl sm:text-2xl text-white hover:text-amber-300 leading-snug cursor-pointer transition-colors"
                      >
                        {mainGallery.titleBn}
                      </h3>
                      <p className="text-xs sm:text-sm text-amber-200/95 mt-1.5 font-editorial leading-relaxed">
                        📷 {currentSlidePhoto?.captionBn}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Interactive Filmstrip Thumbnails Bar */}
                <div className="p-3.5 bg-[#0B0F19] border-t border-gray-800">
                  <div className="flex items-center justify-between text-[11px] text-gray-400 mb-2">
                    <span>এই অ্যালবামের সব ছবি (ক্লিক করে দেখুন):</span>
                    <button
                      onClick={() => {
                        setLightboxZoom(1);
                        setActiveGallery(mainGallery);
                        setActivePhotoIndex(safeSlideIndex);
                      }}
                      className="text-amber-400 hover:underline font-bold cursor-pointer flex items-center gap-1"
                    >
                      <Maximize2 className="w-3 h-3" /> লাইটবক্সে বড় করে দেখুন
                    </button>
                  </div>
                  <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                    {mainGallery.photos.map((ph, idx) => (
                      <button
                        key={idx}
                        onClick={() => setHomeSlideIndex(idx)}
                        className={`relative aspect-16/10 overflow-hidden border-2 transition-all cursor-pointer ${
                          idx === safeSlideIndex
                            ? 'border-[#D32F2F] scale-[1.02]'
                            : 'border-transparent opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={ph.url}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-0.5 right-0.5 bg-black/80 text-white text-[9px] font-bold px-1">
                          {toBengaliNumber(idx + 1)}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right 5 Columns: Curated Photo Albums Stack */}
              <div className="lg:col-span-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b-2 border-[#111827] pb-2 mb-3.5">
                    <span className="font-editorial font-bold text-base text-[#111827]">
                      নির্বাচিত ফটো অ্যালবাম ({toBengaliNumber(displayGalleries.length)})
                    </span>
                    <span className="text-xs text-[#6B7280]">
                      অ্যালবামে ক্লিক করুন
                    </span>
                  </div>

                  <div className="space-y-3">
                    {displayGalleries.map((gal) => {
                      const isSelected = gal.id === mainGallery.id;
                      return (
                        <div
                          key={gal.id}
                          onClick={() => {
                            setHomeActiveGalleryId(gal.id);
                            setHomeSlideIndex(0);
                          }}
                          className={`group cursor-pointer p-3 border rounded-[2px] flex items-center gap-3.5 transition-all ${
                            isSelected
                              ? 'bg-[#111827] text-white border-[#111827] shadow-md'
                              : 'bg-white hover:bg-[#F9FAFB] text-[#111827] border-[#E5E7EB] hover:border-[#111827]'
                          }`}
                        >
                          {/* Stacked Album Cover Preview */}
                          <div className="relative w-28 sm:w-32 aspect-16/10 shrink-0 overflow-hidden bg-gray-900 border border-gray-300">
                            <img
                              src={gal.coverImage}
                              alt={gal.titleBn}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <span className="absolute bottom-1 right-1 bg-[#D32F2F] text-white text-[10px] font-bold px-1.5 py-0.5 flex items-center gap-1 shadow">
                              <Camera className="w-2.5 h-2.5" />
                              {toBengaliNumber(gal.photos.length)}টি ছবি
                            </span>
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2 mb-0.5">
                              <span
                                className={`text-[11px] font-bold ${
                                  isSelected ? 'text-amber-400' : 'text-[#D32F2F]'
                                }`}
                              >
                                {gal.categoryBn}
                              </span>
                              <span
                                className={`text-[10px] ${
                                  isSelected ? 'text-gray-300' : 'text-[#6B7280]'
                                }`}
                              >
                                {gal.dateBn}
                              </span>
                            </div>

                            <h4
                              className={`font-editorial font-bold text-sm sm:text-[15px] leading-snug line-clamp-2 ${
                                isSelected
                                  ? 'text-white'
                                  : 'text-[#111827] group-hover:text-[#D32F2F]'
                              }`}
                            >
                              {gal.titleBn}
                            </h4>

                            <div className="mt-1.5 flex items-center justify-between">
                              <span
                                className={`text-[11px] font-semibold ${
                                  isSelected ? 'text-emerald-400' : 'text-[#4B5563]'
                                }`}
                              >
                                {isSelected ? '● এখন প্রদর্শিত হচ্ছে' : 'স্টেজে দেখুন →'}
                              </span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setLightboxZoom(1);
                                  setActiveGallery(gal);
                                  setActivePhotoIndex(0);
                                }}
                                className={`text-[11px] font-bold px-2 py-0.5 border cursor-pointer ${
                                  isSelected
                                    ? 'bg-white/10 text-white border-white/25 hover:bg-[#D32F2F]'
                                    : 'bg-[#F3F4F6] text-[#111827] border-[#D1D5DB] hover:bg-[#111827] hover:text-white'
                                }`}
                              >
                                পূর্ণ পর্দা
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Bottom CTA to Full Photo Gallery Page */}
                <button
                  onClick={() => navigateTo({ type: 'photo-gallery' })}
                  className="mt-4 w-full py-2.5 bg-[#111827] hover:bg-[#D32F2F] text-white font-editorial font-bold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>ফটো গ্যালারির পূর্ণাঙ্গ আর্কাইভ দেখুন →</span>
                </button>
              </div>
            </div>
          </section>
        );
      }

      // =====================================================================
      // SECTION 11 — OPINION ("মতামত")
      // =====================================================================
      case 'opinion':
        return (
          <section key="opinion" className="mb-12">
            <SectionHeader
              titleBn="মতামত"
              subtitleBn="বিশিষ্ট চিন্তাবিদ, অর্থনীতিবিদ ও বিশ্লেষকদের কলাম"
              onSeeMore={() =>
                navigateTo({ type: 'category', categorySlug: 'opinion' })
              }
              seeMoreLabelBn="সব মতামত"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {opinions.map((op) => (
                <div
                  key={op.id}
                  onClick={() =>
                    navigateTo({ type: 'article', articleId: op.articleId })
                  }
                  className="group cursor-pointer bg-[#F9FAFB] hover:bg-white border border-[#E5E7EB] hover:border-[#111827] p-5 rounded-[2px] flex flex-col justify-between transition-all relative"
                >
                  <Quote className="w-8 h-8 text-[#E5E7EB] absolute top-4 right-4" />
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <img
                        src={op.authorPhoto}
                        alt={op.authorName}
                        className="w-12 h-12 rounded-full object-cover border-2 border-[#D32F2F] shrink-0"
                      />
                      <div className="min-w-0">
                        <h4 className="font-editorial font-bold text-sm text-[#111827] truncate">
                          {op.authorName}
                        </h4>
                        <p className="text-[11px] text-[#6B7280] line-clamp-1">
                          {op.authorDesignation}
                        </p>
                      </div>
                    </div>

                    <h3 className="font-editorial font-bold text-base sm:text-lg text-[#111827] group-hover:text-[#D32F2F] leading-snug mb-2.5 transition-colors">
                      {op.titleBn}
                    </h3>

                    <p className="text-xs sm:text-sm text-[#4B5563] leading-relaxed line-clamp-3">
                      {op.excerptBn}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#6B7280]">
                    <span>{op.publishedAtBn}</span>
                    <span className="font-bold text-[#D32F2F] group-hover:translate-x-0.5 transition-transform">
                      পূর্ণ কলাম পড়ুন →
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        );

      // =====================================================================
      // SECTION 12 — SPECIAL REPORT ("বিশেষ প্রতিবেদন")
      // =====================================================================
      case 'special_report':
        return (
          <section key="special_report" className="mb-10">
            <SectionHeader
              titleBn="বিশেষ প্রতিবেদন"
              subtitleBn="bd7news.com অনুসন্ধানী সেলের বিশেষ ও সরেজমিন প্রতিবেদন"
              onSeeMore={() =>
                navigateTo({ type: 'category', categorySlug: 'special-report' })
              }
              seeMoreLabelBn="সব বিশেষ প্রতিবেদন"
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {specialReports.slice(0, 3).map((art) => (
                <NewsCard key={art.id} article={art} variant="overlay" />
              ))}
            </div>
          </section>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-[1320px] mx-auto px-4 py-6">
      {orderedSections.map((sec) => renderSection(sec.key))}

      {/* Google AdSense Multiplex Sponsored Content Grid at Homepage Bottom */}
      <AdSlot slot="multiplex-ad" instanceKey="homepage-multiplex" />

      {/* Interactive Fullscreen Photo Gallery Lightbox Modal */}
      {activeGallery && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-3 sm:p-6">
          <div className="max-w-5xl w-full bg-[#0B0F19] border border-gray-800 text-white p-4 sm:p-6 relative shadow-2xl">
            {/* Top Lightbox Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-4 border-b border-gray-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-[#D32F2F] text-white text-[11px] font-bold px-2.5 py-0.5">
                    {activeGallery.categoryBn}
                  </span>
                  <span className="text-xs font-bold text-amber-400">
                    ছবি {toBengaliNumber(activePhotoIndex + 1)} /{' '}
                    {toBengaliNumber(activeGallery.photos.length)}
                  </span>
                  <span className="text-xs text-gray-400">
                    • {activeGallery.dateBn}
                  </span>
                </div>
                <h3 className="font-editorial font-bold text-lg sm:text-xl text-white mt-1">
                  {activeGallery.titleBn}
                </h3>
              </div>

              {/* Lightbox Controls: Slideshow, Zoom, Download, Close */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsSlideshowPlaying((p) => !p)}
                  className={`px-3 py-1.5 text-xs font-bold border flex items-center gap-1.5 cursor-pointer ${
                    isSlideshowPlaying
                      ? 'bg-amber-400 text-[#111827] border-amber-400'
                      : 'bg-gray-900 text-gray-200 border-gray-700 hover:bg-gray-800'
                  }`}
                >
                  {isSlideshowPlaying ? (
                    <>
                      <Pause className="w-3.5 h-3.5" /> স্লাইডশো থামান
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" /> স্লাইডশো
                    </>
                  )}
                </button>
                <button
                  onClick={() =>
                    setLightboxZoom((z) => (z >= 1.75 ? 1 : +(z + 0.25).toFixed(2)))
                  }
                  className="p-1.5 bg-gray-900 hover:bg-gray-800 text-gray-200 border border-gray-700 cursor-pointer"
                  title="জুম ইন / আউট"
                >
                  {lightboxZoom > 1 ? (
                    <ZoomOut className="w-4 h-4 text-amber-400" />
                  ) : (
                    <ZoomIn className="w-4 h-4" />
                  )}
                </button>
                <a
                  href={activeGallery.photos[activePhotoIndex]?.url}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1.5 bg-gray-900 hover:bg-gray-800 text-gray-200 border border-gray-700 cursor-pointer"
                  title="ছবি ওপেন / ডাউনলোড"
                >
                  <Download className="w-4 h-4" />
                </a>
                <button
                  onClick={() => {
                    setIsSlideshowPlaying(false);
                    setLightboxZoom(1);
                    setActiveGallery(null);
                  }}
                  className="p-1.5 bg-[#D32F2F] hover:bg-red-700 text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Main Lightbox Image Stage */}
            <div className="relative aspect-16/9 bg-black overflow-hidden mb-4 border border-gray-800 flex items-center justify-center">
              <img
                src={activeGallery.photos[activePhotoIndex]?.url}
                alt={activeGallery.titleBn}
                style={{ transform: `scale(${lightboxZoom})` }}
                className="w-full h-full object-contain transition-transform duration-300"
              />
              {activeGallery.photos.length > 1 && (
                <>
                  <button
                    onClick={() =>
                      setActivePhotoIndex((prev) =>
                        prev === 0 ? activeGallery.photos.length - 1 : prev - 1
                      )
                    }
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/80 hover:bg-[#D32F2F] text-white border border-white/20 cursor-pointer"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button
                    onClick={() =>
                      setActivePhotoIndex((prev) =>
                        prev === activeGallery.photos.length - 1 ? 0 : prev + 1
                      )
                    }
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/80 hover:bg-[#D32F2F] text-white border border-white/20 cursor-pointer"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                </>
              )}
            </div>

            {/* Caption + Filmstrip Thumbnails */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <p className="text-sm sm:text-base text-amber-200 font-editorial flex-1">
                📷 {activeGallery.photos[activePhotoIndex]?.captionBn}
              </p>
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
                {activeGallery.photos.map((ph, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setLightboxZoom(1);
                      setActivePhotoIndex(idx);
                    }}
                    className={`w-16 aspect-16/10 overflow-hidden border-2 transition-all cursor-pointer shrink-0 ${
                      idx === activePhotoIndex
                        ? 'border-[#D32F2F] scale-105'
                        : 'border-gray-700 opacity-50 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={ph.url}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Cinema Video Player Modal with Side Playlist */}
      {activeVideoArticle && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-3 sm:p-6">
          <div className="max-w-5xl w-full bg-[#090D16] border border-slate-800 text-white p-4 sm:p-6 relative shadow-2xl">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <span className="bg-[#D32F2F] text-white text-xs font-bold px-2.5 py-1 flex items-center gap-1.5">
                  <Film className="w-3.5 h-3.5" /> bd7news সিনেমা থিয়েটার
                </span>
                <span className="text-xs text-amber-400 font-bold">
                  {activeVideoArticle.subcategory || 'ভিডিও প্রতিবেদন'}
                </span>
                <span className="text-xs text-slate-400 font-mono-num">
                  • {activeVideoArticle.videoDuration}
                </span>
              </div>
              <button
                onClick={() => setActiveVideoArticle(null)}
                className="p-1.5 bg-slate-800 hover:bg-[#D32F2F] text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              {/* Left 8 Cols: Video Player Stage */}
              <div className="lg:col-span-8">
                <div className="relative aspect-16/9 bg-black border border-slate-800 mb-3 overflow-hidden">
                  <img
                    src={activeVideoArticle.featuredImage}
                    alt={activeVideoArticle.headline}
                    className={`w-full h-full object-cover transition-all duration-700 ${
                      isModalVideoPlaying ? 'scale-105 opacity-45' : 'opacity-70'
                    }`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/35 to-transparent flex flex-col items-center justify-center p-6 text-center">
                    <button
                      onClick={() => setIsModalVideoPlaying((p) => !p)}
                      className="w-16 h-16 rounded-full bg-[#D32F2F] hover:bg-red-600 text-white flex items-center justify-center mb-3 shadow-2xl cursor-pointer border-4 border-white/20"
                    >
                      {isModalVideoPlaying ? (
                        <Pause className="w-7 h-7" />
                      ) : (
                        <Play className="w-7 h-7 fill-current ml-0.5" />
                      )}
                    </button>
                    <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                      {isModalVideoPlaying
                        ? '● ভিডিও সম্প্রচার চলছে (HD 1080p)'
                        : 'বিরতি দেওয়া হয়েছে'}
                    </span>
                    <p className="font-editorial font-bold text-lg sm:text-xl text-white max-w-xl leading-snug">
                      {activeVideoArticle.headline}
                    </p>
                    <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-lg line-clamp-2">
                      {activeVideoArticle.summary}
                    </p>
                  </div>

                  {/* Interactive Scrubber Bar */}
                  <div className="absolute bottom-0 left-0 right-0 bg-black/80 px-4 py-2.5 flex items-center gap-3 border-t border-slate-800">
                    <button
                      onClick={() => setIsModalVideoPlaying((p) => !p)}
                      className="text-white hover:text-[#D32F2F] cursor-pointer"
                    >
                      {isModalVideoPlaying ? (
                        <Pause className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4 fill-current" />
                      )}
                    </button>
                    <div
                      onClick={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const pct = Math.max(
                          0,
                          Math.min(
                            100,
                            Math.round(((e.clientX - rect.left) / rect.width) * 100)
                          )
                        );
                        setVideoModalProgress(pct);
                      }}
                      className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden cursor-pointer"
                    >
                      <div
                        style={{ width: `${videoModalProgress}%` }}
                        className="h-full bg-[#D32F2F]"
                      />
                    </div>
                    <span className="text-[11px] font-mono-num text-slate-300">
                      {activeVideoArticle.videoDuration || '০৫:০০'}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <div className="text-xs text-slate-400">
                    প্রতিবেদক: <strong className="text-white">{activeVideoArticle.reporter}</strong> •{' '}
                    {toBengaliNumber(activeVideoArticle.views)} ভিউ
                  </div>
                  <button
                    onClick={() => {
                      const id = activeVideoArticle.id;
                      setActiveVideoArticle(null);
                      navigateTo({ type: 'article', articleId: id });
                    }}
                    className="bg-[#D32F2F] hover:bg-red-700 text-white text-xs font-bold px-4 py-2 transition-colors cursor-pointer"
                  >
                    সম্পূর্ণ প্রতিবেদন ও বিস্তারিত পড়ুন →
                  </button>
                </div>
              </div>

              {/* Right 4 Cols: Modal Video Switcher */}
              <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 p-3 rounded-[2px] max-h-[380px] overflow-y-auto">
                <h4 className="font-editorial font-bold text-sm text-amber-400 pb-2 mb-2.5 border-b border-slate-800">
                  আরও ভিডিও দেখুন
                </h4>
                <div className="space-y-2.5">
                  {videoArticles.map((vid) => (
                    <div
                      key={vid.id}
                      onClick={() => {
                        setVideoModalProgress(10);
                        setIsModalVideoPlaying(true);
                        setActiveVideoArticle(vid);
                      }}
                      className={`p-2 flex items-start gap-2.5 cursor-pointer border transition-colors ${
                        vid.id === activeVideoArticle.id
                          ? 'bg-[#D32F2F]/20 border-[#D32F2F]'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-600'
                      }`}
                    >
                      <img
                        src={vid.featuredImage}
                        alt={vid.headline}
                        className="w-20 aspect-16/10 object-cover shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="font-editorial font-bold text-xs text-white line-clamp-2 leading-snug">
                          {vid.headline}
                        </p>
                        <span className="text-[10px] text-amber-400 mt-0.5 block">
                          ⏱ {vid.videoDuration}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
