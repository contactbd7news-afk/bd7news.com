import React, { useState } from 'react';
import { Search, Filter, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';
import { NewsCard, MostReadWidget } from './NewsCard';
import { AdSlot } from './AdSlot';

interface SearchPageProps {
  initialQuery: string;
}

export const SearchPage: React.FC<SearchPageProps> = ({ initialQuery }) => {
  const { publishedArticles, categories } = useNews();

  const [query, setQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 6;

  // Filter logic
  const filteredResults = publishedArticles.filter((art) => {
    const matchesQuery =
      !query.trim() ||
      art.headline.toLowerCase().includes(query.toLowerCase()) ||
      art.summary.toLowerCase().includes(query.toLowerCase()) ||
      art.tags.some((t) => t.toLowerCase().includes(query.toLowerCase())) ||
      art.categoryNameBn.includes(query);

    const matchesCategory =
      selectedCategory === 'ALL' || art.category === selectedCategory;

    const matchesDate =
      dateFilter === 'all'
        ? true
        : dateFilter === 'today'
        ? art.isoDate === '2026-09-26'
        : true;

    return matchesQuery && matchesCategory && matchesDate;
  });

  const totalPages = Math.max(1, Math.ceil(filteredResults.length / itemsPerPage));
  const paginatedResults = filteredResults.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1);
  };

  return (
    <div className="max-w-[1320px] mx-auto px-4 py-6">
      {/* Search Header Box */}
      <div className="bg-[#F9FAFB] border-2 border-[#111827] p-5 sm:p-6 mb-8 rounded-[2px]">
        <h1 className="font-editorial font-extrabold text-2xl sm:text-3xl text-[#111827] mb-4">
          সংবাদ অনুসন্ধান
        </h1>

        <form onSubmit={handleSearchSubmit} className="space-y-4">
          {/* Search Input & Button */}
          <div className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search className="w-5 h-5 text-[#6B7280] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="কীওয়ার্ড, সংবাদের শিরোনাম বা বিষয় লিখুন..."
                className="w-full bg-white border border-[#D1D5DB] focus:border-[#111827] outline-none pl-11 pr-4 py-3 text-sm sm:text-base text-[#111827]"
              />
            </div>
            <button
              type="submit"
              className="bg-[#D32F2F] hover:bg-[#B71C1C] text-white font-editorial font-bold text-base px-8 py-3 transition-colors cursor-pointer"
            >
              অনুসন্ধান করুন
            </button>
          </div>

          {/* Filter by Category & Filter by Date */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-[#E5E7EB]">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#111827]">
                <Filter className="w-3.5 h-3.5 text-[#D32F2F]" />
                <span>বিভাগ ফিল্টার:</span>
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs font-semibold text-[#111827] outline-none"
              >
                <option value="ALL">সকল বিভাগ</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.slug}>
                    {cat.nameBn}
                  </option>
                ))}
              </select>

              <div className="flex items-center gap-1.5 text-xs font-bold text-[#111827] ml-2">
                <Calendar className="w-3.5 h-3.5 text-[#D32F2F]" />
                <span>সময়কাল:</span>
              </div>
              <select
                value={dateFilter}
                onChange={(e) => {
                  setDateFilter(e.target.value as any);
                  setCurrentPage(1);
                }}
                className="bg-white border border-[#D1D5DB] px-3 py-1.5 text-xs font-semibold text-[#111827] outline-none"
              >
                <option value="all">সব সময়</option>
                <option value="today">আজকের সংবাদ</option>
                <option value="week">গত ৭ দিন</option>
                <option value="month">গত ৩০ দিন</option>
              </select>
            </div>

            <div className="text-xs font-semibold text-[#4B5563]">
              ফলাফল পাওয়া গেছে:{' '}
              <span className="text-[#D32F2F] font-bold">
                {toBengaliNumber(filteredResults.length)}টি সংবাদ
              </span>
            </div>
          </div>
        </form>
      </div>

      {/* Results & Sidebar Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8">
          {paginatedResults.length === 0 ? (
            <div className="bg-white border border-[#E5E7EB] p-10 text-center">
              <p className="font-editorial font-bold text-lg text-[#111827] mb-1">
                দুঃখিত, আপনার অনুসন্ধানের সাথে মিলে এমন কোনো সংবাদ পাওয়া যায়নি।
              </p>
              <p className="text-xs text-[#6B7280]">
                অন্য কোনো শব্দ বা বিভাগ নির্বাচন করে পুনরায় চেষ্টা করুন।
              </p>
            </div>
          ) : (
            <div className="bg-white border border-[#E5E7EB] px-5 rounded-[2px] divide-y divide-[#E5E7EB]">
              {paginatedResults.map((art) => (
                <NewsCard
                  key={art.id}
                  article={art}
                  variant="horizontal-feed"
                />
              ))}
            </div>
          )}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="mt-6 flex items-center justify-between bg-[#F9FAFB] border border-[#E5E7EB] p-3.5">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="inline-flex items-center gap-1 px-3.5 py-1.5 bg-white border border-[#D1D5DB] disabled:opacity-40 text-xs font-bold text-[#111827] cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" /> পূর্ববর্তী
              </button>

              <div className="flex items-center gap-1.5">
                {Array.from({ length: totalPages }).map((_, idx) => {
                  const p = idx + 1;
                  return (
                    <button
                      key={p}
                      onClick={() => setCurrentPage(p)}
                      className={`w-8 h-8 text-xs font-bold border cursor-pointer ${
                        currentPage === p
                          ? 'bg-[#D32F2F] text-white border-[#D32F2F]'
                          : 'bg-white text-[#111827] border-[#D1D5DB]'
                      }`}
                    >
                      {toBengaliNumber(p)}
                    </button>
                  );
                })}
              </div>

              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="inline-flex items-center gap-1 px-3.5 py-1.5 bg-white border border-[#D1D5DB] disabled:opacity-40 text-xs font-bold text-[#111827] cursor-pointer"
              >
                পরবর্তী <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        <aside className="lg:col-span-4 space-y-6">
          <MostReadWidget />
          <AdSlot slot="sidebar-ad" />
        </aside>
      </div>
    </div>
  );
};
