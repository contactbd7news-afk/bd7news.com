import React, { useRef, useState } from 'react';
import {
  Upload,
  Image as ImageIcon,
  Trash2,
  CheckCircle2,
  Sliders,
  Link as LinkIcon,
  Sparkles,
  RefreshCw,
  X,
  Eye,
} from 'lucide-react';
import { useNews, toBengaliNumber } from '../context/NewsContext';

// Helper to convert SVG string to Data URI safely
const svgToDataUri = (svgString: string) =>
  `data:image/svg+xml;utf8,${encodeURIComponent(svgString.trim())}`;

export const PRESET_LOGOS = [
  {
    id: 'preset-bn-editorial',
    nameBn: 'বাংলা পত্রিকা মাস্টহেড (বিডি৭নিউজ)',
    url: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 76" fill="none">
        <rect x="2" y="8" width="60" height="60" rx="4" fill="#D32F2F"/>
        <text x="32" y="49" text-anchor="middle" fill="#FFFFFF" font-family="Noto Serif Bengali, Georgia, serif" font-weight="900" font-size="34">বিডি৭</text>
        <text x="74" y="47" fill="#111827" font-family="Noto Serif Bengali, Georgia, serif" font-weight="900" font-size="38">বিডি<tspan fill="#D32F2F">৭</tspan>নিউজ</text>
        <text x="276" y="47" fill="#D32F2F" font-family="Inter, sans-serif" font-weight="800" font-size="22">.com</text>
        <rect x="75" y="56" width="40" height="3" fill="#D32F2F"/>
        <text x="122" y="61" fill="#4B5563" font-family="Noto Serif Bengali, sans-serif" font-weight="700" font-size="13">সত্য সংবাদ সবসময় • bd7news.com</text>
      </svg>
    `),
  },
  {
    id: 'preset-red-box',
    nameBn: 'আন্তর্জাতিক রেড-বক্স ব্রডকাস্ট স্টাইল',
    url: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 350 72" fill="none">
        <rect x="0" y="8" width="46" height="54" fill="#111827"/>
        <text x="23" y="46" text-anchor="middle" fill="#FFFFFF" font-family="Inter, sans-serif" font-weight="900" font-size="30">B</text>
        <rect x="50" y="8" width="46" height="54" fill="#111827"/>
        <text x="73" y="46" text-anchor="middle" fill="#FFFFFF" font-family="Inter, sans-serif" font-weight="900" font-size="30">D</text>
        <rect x="100" y="8" width="46" height="54" fill="#D32F2F"/>
        <text x="123" y="47" text-anchor="middle" fill="#FFFFFF" font-family="Inter, sans-serif" font-weight="900" font-size="34">7</text>
        <text x="158" y="44" fill="#111827" font-family="Georgia, serif" font-weight="900" font-size="34" letter-spacing="-0.5">NEWS</text>
        <text x="268" y="44" fill="#D32F2F" font-family="Inter, sans-serif" font-weight="800" font-size="20">.COM</text>
        <text x="158" y="60" fill="#4B5563" font-family="Noto Serif Bengali, sans-serif" font-weight="700" font-size="13">সত্য সংবাদ সবসময় • ২৪/৭ লাইভ</text>
      </svg>
    `),
  },
  {
    id: 'preset-modern-crest',
    nameBn: 'মডার্ন কর্পোরেট নিউজ পোর্টাল ব্যাজ',
    url: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 72" fill="none">
        <circle cx="36" cy="36" r="30" fill="#111827"/>
        <path d="M22 24H48L33 52H24L38 29H22V24Z" fill="#D32F2F"/>
        <text x="78" y="44" fill="#111827" font-family="Georgia, serif" font-weight="900" font-size="38">bd<tspan fill="#D32F2F">7</tspan>news</text>
        <rect x="250" y="20" width="56" height="26" rx="3" fill="#D32F2F"/>
        <text x="278" y="38" text-anchor="middle" fill="#FFFFFF" font-family="Inter, sans-serif" font-weight="800" font-size="16">.COM</text>
        <text x="79" y="61" fill="#374151" font-family="Noto Serif Bengali, sans-serif" font-weight="700" font-size="13">সত্য সংবাদ সবসময় | Truth in News, Always</text>
      </svg>
    `),
  },
];

// Optimize uploaded image file so it fits cleanly in localStorage while keeping PNG transparency
export function processUploadedLogoFile(
  file: File,
  maxWidth = 700,
  maxHeight = 260
): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('অনুগ্রহ করে একটি সঠিক ইমেজ ফাইল (PNG, JPG, SVG, WEBP) নির্বাচন করুন।'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('ফাইলটি পড়া সম্ভব হয়নি।'));
    reader.onload = () => {
      const result = reader.result as string;
      // If SVG or already compact (< 220KB), keep original data URL directly
      if (file.type === 'image/svg+xml' || result.length < 220 * 1024) {
        resolve(result);
        return;
      }

      // Otherwise resize smoothly on canvas while keeping PNG transparency
      const img = new Image();
      img.onerror = () => resolve(result);
      img.onload = () => {
        let { width, height } = img;
        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(result);
          return;
        }
        ctx.clearRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        // Use PNG for transparency support, or WEBP/JPEG if original was JPEG
        const outputType =
          file.type === 'image/jpeg' || file.type === 'image/jpg'
            ? 'image/jpeg'
            : 'image/png';
        const compressed = canvas.toDataURL(outputType, 0.92);
        resolve(compressed);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  });
}

export const LogoUploadManager: React.FC<{
  onSuccess?: (msg: string) => void;
  compact?: boolean;
}> = ({ onSuccess, compact = false }) => {
  const { siteSettings, updateSiteSettings } = useNews();

  const mainLogoInputRef = useRef<HTMLInputElement>(null);
  const footerLogoInputRef = useRef<HTMLInputElement>(null);
  const faviconInputRef = useRef<HTMLInputElement>(null);

  const [dragOver, setDragOver] = useState(false);
  const [urlInput, setUrlInput] = useState(
    siteSettings.logoUrl && !siteSettings.logoUrl.startsWith('data:')
      ? siteSettings.logoUrl
      : ''
  );
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const logoHeight = siteSettings.logoHeight || 52;
  const showTagline = siteSettings.showTaglineWithLogo ?? true;

  const notify = (msg: string) => {
    setErrorMessage(null);
    setStatusMessage(msg);
    if (onSuccess) onSuccess(msg);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleMainLogoFile = async (file?: File) => {
    if (!file) return;
    try {
      const dataUrl = await processUploadedLogoFile(file, 750, 260);
      updateSiteSettings({ logoUrl: dataUrl });
      notify('আপনার নতুন লোগো সফলভাবে আপলোড ও ওয়েবসাইটে যুক্ত হয়েছে!');
    } catch (err: any) {
      setErrorMessage(err?.message || 'লোগো আপলোড করতে সমস্যা হয়েছে।');
    }
  };

  const handleFooterLogoFile = async (file?: File) => {
    if (!file) return;
    try {
      const dataUrl = await processUploadedLogoFile(file, 600, 220);
      updateSiteSettings({ footerLogoUrl: dataUrl });
      notify('ফুটার লোগো সফলভাবে আপলোড হয়েছে!');
    } catch (err: any) {
      setErrorMessage(err?.message || 'ফুটার লোগো আপলোড করতে সমস্যা হয়েছে।');
    }
  };

  const handleFaviconFile = async (file?: File) => {
    if (!file) return;
    try {
      const dataUrl = await processUploadedLogoFile(file, 128, 128);
      updateSiteSettings({ faviconUrl: dataUrl });
      notify('ব্রাউজার ফেভিকন (Favicon) সফলভাবে আপডেট হয়েছে!');
    } catch (err: any) {
      setErrorMessage(err?.message || 'ফেভিকন আপলোড করতে সমস্যা হয়েছে।');
    }
  };

  return (
    <div className="bg-white border border-[#E5E7EB] p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b-2 border-[#111827] pb-3">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#D32F2F]">
            ব্র্যান্ডিং ও লোগো স্টুডিও
          </span>
          <h3 className="font-editorial font-extrabold text-xl text-[#111827]">
            ওয়েবসাইটের লোগো আপলোড ও কাস্টমাইজেশন
          </h3>
          <p className="text-xs text-[#6B7280]">
            আপনার কম্পিউটার বা মোবাইল থেকে PNG, JPG, SVG অথবা WEBP ফরম্যাটের লোগো আপলোড করুন
          </p>
        </div>

        {siteSettings.logoUrl && (
          <button
            type="button"
            onClick={() => {
              updateSiteSettings({
                logoUrl: '',
                footerLogoUrl: '',
                showTaglineWithLogo: true,
              });
              setUrlInput('');
              notify('ডিফল্ট টেক্সট লোগো পুনরুদ্ধার করা হয়েছে।');
            }}
            className="inline-flex items-center gap-1.5 bg-red-50 hover:bg-[#D32F2F] text-[#D32F2F] hover:text-white border border-red-200 px-3 py-2 text-xs font-bold transition-colors cursor-pointer self-start"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>ডিফল্ট লোগোতে ফিরুন</span>
          </button>
        )}
      </div>

      {/* Feedback Banner */}
      {statusMessage && (
        <div className="bg-emerald-50 border-l-4 border-emerald-600 p-3.5 flex items-center gap-2.5 text-xs sm:text-sm font-bold text-emerald-900">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}
      {errorMessage && (
        <div className="bg-red-50 border-l-4 border-[#D32F2F] p-3.5 flex items-center gap-2.5 text-xs sm:text-sm font-bold text-red-900">
          <X className="w-4 h-4 text-[#D32F2F] shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: Upload Dropzone + URL Input + Size Controls */}
        <div className="lg:col-span-7 space-y-5">
          {/* 1. Drag & Drop File Upload Box */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleMainLogoFile(file);
            }}
            onClick={() => mainLogoInputRef.current?.click()}
            className={`border-2 border-dashed p-6 text-center transition-all cursor-pointer ${
              dragOver
                ? 'border-[#D32F2F] bg-[#FEF2F2]'
                : 'border-[#9CA3AF] hover:border-[#111827] bg-[#F9FAFB]'
            }`}
          >
            <input
              ref={mainLogoInputRef}
              type="file"
              accept="image/png,image/jpeg,image/jpg,image/svg+xml,image/webp,image/gif"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleMainLogoFile(file);
                e.target.value = '';
              }}
              className="hidden"
            />
            <div className="w-12 h-12 mx-auto mb-3 bg-[#111827] text-white flex items-center justify-center">
              <Upload className="w-6 h-6 text-[#D32F2F]" />
            </div>
            <p className="font-editorial font-extrabold text-base text-[#111827]">
              এখানে ক্লিক করে লোগো ফাইল আপলোড করুন
            </p>
            <p className="text-xs text-[#6B7280] mt-1">
              অথবা ফাইল টেনে এনে (Drag & Drop) এখানে ছাড়ুন • PNG (স্বচ্ছ ব্যাকগ্রাউন্ড), SVG, JPG, WEBP সাপোর্টেড
            </p>
            <div className="mt-4">
              <span className="inline-flex items-center gap-1.5 bg-[#D32F2F] hover:bg-[#B71C1C] text-white font-bold text-xs px-5 py-2.5 transition-colors">
                <ImageIcon className="w-4 h-4" /> ডিভাইস থেকে লোগো নির্বাচন করুন
              </span>
            </div>
          </div>

          {/* 2. Direct Image URL Input */}
          <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4">
            <label className="block text-xs font-bold text-[#111827] mb-2 flex items-center gap-1.5">
              <LinkIcon className="w-3.5 h-3.5 text-[#D32F2F]" />
              <span>অথবা লোগো ছবির সরাসরি লিংক (Image URL) ব্যবহার করুন:</span>
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="url"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://example.com/my-logo.png"
                className="flex-1 bg-white border border-[#D1D5DB] focus:border-[#111827] px-3 py-2 text-xs outline-none"
              />
              <button
                type="button"
                onClick={() => {
                  if (!urlInput.trim()) return;
                  updateSiteSettings({ logoUrl: urlInput.trim() });
                  notify('লিংক থেকে লোগো সফলভাবে যুক্ত করা হয়েছে!');
                }}
                className="bg-[#111827] hover:bg-[#D32F2F] text-white font-bold text-xs px-4 py-2 transition-colors cursor-pointer shrink-0"
              >
                লিংক সেট করুন
              </button>
            </div>
          </div>

          {/* 3. Logo Size (Height) & Tagline Display Controls */}
          <div className="bg-[#F9FAFB] border border-[#E5E7EB] p-4 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-[#111827] flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#D32F2F]" />
                <span>হেডারে লোগোর আকার (উচ্চতা):</span>
              </label>
              <span className="text-xs font-mono-num font-extrabold bg-[#111827] text-white px-2.5 py-0.5">
                {toBengaliNumber(logoHeight)} px
              </span>
            </div>

            <input
              type="range"
              min={32}
              max={92}
              step={2}
              value={logoHeight}
              onChange={(e) =>
                updateSiteSettings({ logoHeight: Number(e.target.value) })
              }
              className="w-full accent-[#D32F2F] cursor-pointer"
            />

            <div className="flex items-center justify-between text-[11px] text-[#6B7280]">
              <span>ছোট (৩২px)</span>
              <span>মাঝারি (৫২px)</span>
              <span>বড় (৯২px)</span>
            </div>

            <div className="pt-2 border-t border-[#E5E7EB] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <label className="flex items-center gap-2 text-xs font-bold text-[#111827] cursor-pointer">
                <input
                  type="checkbox"
                  checked={showTagline}
                  onChange={(e) =>
                    updateSiteSettings({ showTaglineWithLogo: e.target.checked })
                  }
                  className="w-4 h-4 accent-[#D32F2F]"
                />
                <span>লোগোর নিচে ট্যাগলাইন ({siteSettings.taglineBn}) দেখান</span>
              </label>
            </div>
          </div>

          {/* 4. Ready-to-use Presets */}
          <div className="space-y-2.5">
            <div className="text-xs font-bold text-[#111827] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#D32F2F]" />
              <span>অথবা এক ক্লিকে রেডিমেড লোগো টেমপ্লেট বেছে নিন:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {PRESET_LOGOS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    updateSiteSettings({
                      logoUrl: preset.url,
                      showTaglineWithLogo: false,
                      logoHeight: 56,
                    });
                    notify(`"${preset.nameBn}" লোগো সেট করা হয়েছে!`);
                  }}
                  className="border border-[#E5E7EB] hover:border-[#D32F2F] bg-white p-2.5 text-left transition-all cursor-pointer group"
                >
                  <div className="h-11 flex items-center justify-center bg-[#F9FAFB] p-1 mb-1.5">
                    <img
                      src={preset.url}
                      alt={preset.nameBn}
                      className="max-h-9 w-auto object-contain"
                    />
                  </div>
                  <p className="text-[11px] font-bold text-[#111827] group-hover:text-[#D32F2F] truncate">
                    {preset.nameBn}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Live Preview + Footer Logo & Favicon */}
        <div className="lg:col-span-5 space-y-4">
          {/* Live Header Preview Box */}
          <div className="border border-[#E5E7EB] bg-[#F9FAFB] p-4">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold text-[#111827] flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-[#D32F2F]" />
                <span>লাইভ হেডার প্রিভিউ (Header Preview)</span>
              </span>
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 bg-emerald-100 text-emerald-800">
                LIVE
              </span>
            </div>

            <div className="bg-white border border-[#E5E7EB] p-5 flex flex-col items-start justify-center min-h-[115px]">
              {siteSettings.logoUrl ? (
                <div>
                  <img
                    src={siteSettings.logoUrl}
                    alt={siteSettings.siteName}
                    style={{ height: `${logoHeight}px` }}
                    className="w-auto max-w-full object-contain"
                  />
                  {showTagline && (
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="h-[2px] w-6 bg-[#D32F2F] inline-block" />
                      <p className="font-editorial font-semibold text-xs text-[#4B5563]">
                        {siteSettings.taglineBn}
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  <div className="flex items-baseline gap-1">
                    <span className="font-editorial font-extrabold text-3xl tracking-tight text-[#111827] leading-none">
                      bd<span className="text-[#D32F2F]">7</span>news
                    </span>
                    <span className="font-ui font-bold text-lg text-[#D32F2F]">
                      .com
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="h-[2px] w-6 bg-[#D32F2F] inline-block" />
                    <p className="font-editorial font-semibold text-xs text-[#4B5563]">
                      {siteSettings.taglineBn}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {siteSettings.logoUrl && (
              <div className="mt-3 flex items-center justify-between">
                <span className="text-[11px] text-emerald-700 font-semibold">
                  ✓ কাস্টম ইমেজ লোগো সক্রিয় রয়েছে
                </span>
                <button
                  type="button"
                  onClick={() => {
                    updateSiteSettings({ logoUrl: '' });
                    notify('কাস্টম লোগো সরানো হয়েছে।');
                  }}
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#D32F2F] hover:underline cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> লোগো মুছুন
                </button>
              </div>
            )}
          </div>

          {/* Optional Separate Footer Logo & Favicon */}
          {!compact && (
            <div className="border border-[#E5E7EB] bg-[#F9FAFB] p-4 space-y-4">
              <h4 className="text-xs font-bold text-[#111827] border-b border-[#E5E7EB] pb-2">
                ফুটার লোগো ও ব্রাউজার ফেভিকন (ঐচ্ছিক)
              </h4>

              {/* Footer Logo */}
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-bold text-[#111827]">
                    আলাদা ফুটার লোগো
                  </div>
                  <div className="text-[11px] text-[#6B7280]">
                    না দিলে প্রধান লোগোটিই ফুটারে প্রদর্শিত হবে
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <input
                    ref={footerLogoInputRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFooterLogoFile(file);
                      e.target.value = '';
                    }}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => footerLogoInputRef.current?.click()}
                    className="bg-white border border-[#D1D5DB] hover:border-[#111827] px-3 py-1.5 text-xs font-bold cursor-pointer"
                  >
                    আপলোড
                  </button>
                  {siteSettings.footerLogoUrl && (
                    <button
                      type="button"
                      onClick={() => updateSiteSettings({ footerLogoUrl: '' })}
                      className="p-1.5 text-[#D32F2F] border border-red-200 bg-red-50 cursor-pointer"
                      title="মুছে ফেলুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Favicon */}
              <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#E5E7EB]">
                <div className="flex items-center gap-2.5">
                  {siteSettings.faviconUrl || siteSettings.logoUrl ? (
                    <img
                      src={siteSettings.faviconUrl || siteSettings.logoUrl}
                      alt="Favicon"
                      className="w-7 h-7 object-contain border border-[#E5E7EB] bg-white p-0.5"
                    />
                  ) : null}
                  <div>
                    <div className="text-xs font-bold text-[#111827]">
                      ব্রাউজার ট্যাব আইকন (Favicon)
                    </div>
                    <div className="text-[11px] text-[#6B7280]">
                      বর্গাকার আইকন (64×64 বা 128×128 px)
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <input
                    ref={faviconInputRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFaviconFile(file);
                      e.target.value = '';
                    }}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => faviconInputRef.current?.click()}
                    className="bg-white border border-[#D1D5DB] hover:border-[#111827] px-3 py-1.5 text-xs font-bold cursor-pointer"
                  >
                    ফেভিকন আপলোড
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
