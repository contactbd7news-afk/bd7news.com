export type ArticleStatus = 'published' | 'draft' | 'scheduled';

export type AdPlacementSlot =
  | 'top-banner'
  | 'header-ad'
  | 'homepage-banner'
  | 'in-content'
  | 'in-feed'
  | 'multiplex-ad'
  | 'vignette-interstitial'
  | 'anchor-top'
  | 'side-rail'
  | 'sidebar-ad'
  | 'between-section'
  | 'sticky-bottom'
  | 'pop-under'
  | 'social-bar'
  | 'mobile-banner'
  | 'desktop-leaderboard';

export type AdType =
  | 'Banner'
  | 'Leaderboard'
  | 'Sidebar'
  | 'In-content'
  | 'In-Feed'
  | 'Multiplex'
  | 'Vignette / Interstitial'
  | 'Anchor'
  | 'Side Rail'
  | 'Sticky'
  | 'Pop-under'
  | 'Social bar';

export interface Article {
  id: string;
  slug: string;
  headline: string; // Bangla headline
  englishHeadline?: string; // English headline for EN mode or SEO
  subtitle?: string;
  summary: string;
  content: string[]; // Paragraphs
  pullQuote?: string;
  category: string; // slug e.g. 'national', 'countrywide', 'politics', 'international', 'sports', 'cricket', 'football', 'entertainment', 'economy', 'technology', 'lifestyle', 'religion', 'video', 'opinion', 'special-report'
  categoryNameBn: string;
  subcategory: string;
  division?: string; // e.g. 'ঢাকা', 'চট্টগ্রাম', 'রাজশাহী', 'খুলনা', 'বরিশাল', 'সিলেট', 'রংপুর', 'ময়মনসিংহ'
  district?: string; // e.g. 'কক্সবাজার', 'বগুড়া', 'সুনামগঞ্জ'
  upazila?: string; // e.g. 'টেকনাফ', 'শেরপুর', 'তাহিরপুর'
  featuredImage: string;
  imageCaption: string;
  imageAlt?: string;
  reporter: string;
  reporterRole?: string;
  reporterAvatar?: string;
  publishedAt: string; // Bangla display date/time
  updatedAt?: string;
  timeAgoBn: string;
  isoDate: string; // YYYY-MM-DD
  views: number;
  status: ArticleStatus;
  scheduledDate?: string;
  scheduledTime?: string;
  isBreaking: boolean;
  isFeatured: boolean;
  isHero: boolean;
  isTrending: boolean;
  mostReadRank?: number; // 1-8
  tags: string[];
  seoTitle?: string;
  metaDescription?: string;
  focusKeyword?: string;
  videoUrl?: string;
  videoDuration?: string;
  galleryImages?: { url: string; caption: string }[];
  adPlacement?: string;
}

export interface BreakingHeadline {
  id: string;
  headline: string;
  articleId?: string;
  active: boolean;
  priority: number;
  createdAtBn: string;
}

export interface CategoryConfig {
  id: string;
  slug: string;
  nameBn: string;
  nameEn: string;
  subcategories: string[];
  visibleInMenu: boolean;
  order: number;
}

export interface MatchScoreCard {
  id: string;
  sport: 'cricket' | 'football';
  tournament: string;
  subTag: string; // e.g. 'Bangladesh Cricket', 'BPL', 'IPL', 'ICC', 'Champions League', 'Premier League'
  status: 'LIVE' | 'RESULT' | 'UPCOMING';
  statusTextBn: string;
  team1: string;
  team1Code: string;
  team1Score: string;
  team2: string;
  team2Code: string;
  team2Score: string;
  summaryBn: string;
  venueBn: string;
}

export interface PhotoGalleryItem {
  id: string;
  titleBn: string;
  categoryBn: string;
  dateBn: string;
  coverImage: string;
  photos: {
    url: string;
    captionBn: string;
  }[];
}

export interface OpinionColumn {
  id: string;
  authorName: string;
  authorDesignation: string;
  authorPhoto: string;
  titleBn: string;
  excerptBn: string;
  articleId: string;
  publishedAtBn: string;
}

export interface AdItem {
  id: string;
  name: string;
  slot: AdPlacementSlot;
  adType: AdType;
  device: 'all' | 'desktop' | 'mobile';
  enabled: boolean;
  priority: number;
  startDate: string;
  endDate: string;
  adCode: string; // Supports Google AdSense / HTML / JS snippet
  sponsorBrandBn: string;
  sponsorHeadlineBn: string;
  sponsorSubtextBn: string;
  sponsorCtaBn: string;
  sponsorUrl?: string;
  sponsorBgImage?: string;
  dimensionsLabel: string;
  clicks?: number;
  impressions?: number;
}

export interface HomepageSectionConfig {
  id: string;
  key:
    | 'hero'
    | 'latest_and_most_read'
    | 'countrywide'
    | 'weather'
    | 'category_grid'
    | 'sports'
    | 'cricket'
    | 'football'
    | 'video'
    | 'photo_gallery'
    | 'opinion'
    | 'special_report';
  titleBn: string;
  enabled: boolean;
  order: number;
  storyCount: number;
}

export interface CommentItem {
  id: string;
  articleId: string;
  articleTitle: string;
  authorName: string;
  authorLocation?: string;
  content: string;
  createdAtBn: string;
  status: 'approved' | 'pending' | 'spam';
  likes: number;
}

export interface AuthorReporter {
  id: string;
  nameBn: string;
  roleBn: string;
  email: string;
  beatBn: string;
  avatar: string;
  articlesCount: number;
}

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: 'Super Admin' | 'Chief Editor' | 'News Editor' | 'Sub-Editor' | 'Reporter' | 'Ad Manager';
  status: 'active' | 'inactive';
  lastLoginBn: string;
}

export interface PushNotificationItem {
  id: string;
  titleBn: string;
  bodyBn: string;
  targetCategory: string;
  sentAtBn: string;
  subscribersReached: number;
}

export interface SiteSettings {
  siteName: string;
  taglineBn: string;
  taglineEn: string;
  logoUrl?: string;
  footerLogoUrl?: string;
  faviconUrl?: string;
  logoHeight?: number;
  showTaglineWithLogo?: boolean;
  language: 'bn' | 'en';
  breakingNewsEnabled: boolean;
  adsMasterEnabled: boolean;
  prePostVignetteEnabled?: boolean;
  editorNameBn: string;
  publisherNameBn: string;
  addressBn: string;
  phoneBn: string;
  email: string;
  facebookUrl: string;
  youtubeUrl: string;
  xUrl: string;
  instagramUrl: string;
  defaultSeoTitle: string;
  defaultMetaDescription: string;
  googleAnalyticsId: string;
  googleAdsensePublisherId: string;
}
