import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Article,
  BreakingHeadline,
  CategoryConfig,
  MatchScoreCard,
  PhotoGalleryItem,
  OpinionColumn,
  AdItem,
  AdPlacementSlot,
  HomepageSectionConfig,
  CommentItem,
  AuthorReporter,
  AdminUser,
  PushNotificationItem,
  SiteSettings,
} from '../types/news';
import {
  INITIAL_ARTICLES,
  INITIAL_BREAKING_HEADLINES,
  INITIAL_CATEGORIES,
  INITIAL_MATCH_SCORES,
  INITIAL_PHOTO_GALLERIES,
  INITIAL_OPINIONS,
  INITIAL_ADS,
  INITIAL_HOMEPAGE_SECTIONS,
  INITIAL_COMMENTS,
  INITIAL_REPORTERS,
  INITIAL_ADMIN_USERS,
  INITIAL_PUSH_NOTIFICATIONS,
  INITIAL_SITE_SETTINGS,
} from '../data/initialData';

export type ActiveView =
  | { type: 'home' }
  | { type: 'latest' }
  | { type: 'countrywide'; division?: string; district?: string; upazila?: string }
  | { type: 'weather' }
  | { type: 'epaper' }
  | { type: 'category'; categorySlug: string; subcategory?: string }
  | { type: 'article'; articleId: string }
  | { type: 'search'; query: string; category?: string; dateFilter?: string }
  | { type: 'video' }
  | { type: 'photo-gallery' }
  | { type: 'admin'; tab?: string }
  | { type: 'static-page'; pageSlug: string };

interface NewsContextType {
  // Navigation
  activeView: ActiveView;
  navigateTo: (view: ActiveView) => void;

  // Data
  articles: Article[];
  publishedArticles: Article[];
  breakingHeadlines: BreakingHeadline[];
  categories: CategoryConfig[];
  matchScores: MatchScoreCard[];
  photoGalleries: PhotoGalleryItem[];
  opinions: OpinionColumn[];
  ads: AdItem[];
  homepageSections: HomepageSectionConfig[];
  comments: CommentItem[];
  reporters: AuthorReporter[];
  adminUsers: AdminUser[];
  pushNotifications: PushNotificationItem[];
  siteSettings: SiteSettings;

  // Auth & Role
  currentAdminUser: AdminUser | null;
  loginAdmin: (email: string, role?: AdminUser['role']) => void;
  logoutAdmin: () => void;

  // Article CRUD
  addArticle: (article: Omit<Article, 'id' | 'views'>) => Article;
  updateArticle: (id: string, updates: Partial<Article>) => void;
  deleteArticle: (id: string) => void;
  setHeroArticle: (id: string) => void;
  incrementArticleView: (id: string) => void;

  // Breaking News CRUD
  toggleBreakingNewsBar: (enabled: boolean) => void;
  addBreakingHeadline: (headline: string, articleId?: string) => void;
  updateBreakingHeadline: (id: string, updates: Partial<BreakingHeadline>) => void;
  deleteBreakingHeadline: (id: string) => void;

  // Categories & Menu CRUD
  addCategory: (nameBn: string, nameEn: string, slug: string) => void;
  updateCategory: (id: string, updates: Partial<CategoryConfig>) => void;
  addSubcategory: (categoryId: string, subNameBn: string) => void;
  removeSubcategory: (categoryId: string, subNameBn: string) => void;

  // Homepage Control
  updateHomepageSection: (id: string, updates: Partial<HomepageSectionConfig>) => void;
  reorderHomepageSections: (fromIndex: number, toIndex: number) => void;
  updateMostReadRank: (articleId: string, rank?: number) => void;

  // Advertisement Manager
  toggleAdSlot: (id: string, enabled: boolean) => void;
  updateAdItem: (id: string, updates: Partial<AdItem>) => void;
  addAdItem: (ad: Omit<AdItem, 'id'>) => void;
  deleteAdItem: (id: string) => void;
  getActiveAdForSlot: (slot: AdPlacementSlot) => AdItem | undefined;
  recordAdClick: (ad: AdItem) => void;
  activeClickedAd: AdItem | null;
  closeClickedAdModal: () => void;
  dismissedAdSlots: string[];
  dismissAdSlot: (slotKey: string) => void;
  restoreAdSlot: (slotKey: string) => void;
  restoreAllDismissedAds: () => void;
  pendingArticleNavigation: string | null;
  confirmPendingArticleNavigation: () => void;
  cancelPendingArticleNavigation: () => void;
  triggerVignettePreview: () => void;

  // Comments
  addComment: (articleId: string, articleTitle: string, authorName: string, authorLocation: string, content: string) => void;
  updateCommentStatus: (id: string, status: CommentItem['status']) => void;
  deleteComment: (id: string) => void;

  // Reporters, Users, Push, Gallery
  addReporter: (rep: Omit<AuthorReporter, 'id' | 'articlesCount'>) => void;
  addAdminUser: (user: Omit<AdminUser, 'id' | 'lastLoginBn'>) => void;
  sendPushNotification: (titleBn: string, bodyBn: string, targetCategory: string) => void;
  addPhotoGallery: (gallery: Omit<PhotoGalleryItem, 'id'>) => void;

  // Site Settings & Language
  updateSiteSettings: (updates: Partial<SiteSettings>) => void;
  toggleLanguage: () => void;
  resetAllDataToDefault: () => void;
}

const NewsContext = createContext<NewsContextType | undefined>(undefined);

const STORAGE_KEYS = {
  ARTICLES: 'bd7news_articles_v5',
  BREAKING: 'bd7news_breaking_v4',
  CATEGORIES: 'bd7news_categories_v4',
  ADS: 'bd7news_ads_v6',
  HOMEPAGE_SECTIONS: 'bd7news_hp_sections_v4',
  COMMENTS: 'bd7news_comments_v4',
  REPORTERS: 'bd7news_reporters_v4',
  USERS: 'bd7news_users_v4',
  PUSH: 'bd7news_push_v4',
  GALLERIES: 'bd7news_galleries_v4',
  SETTINGS: 'bd7news_settings_v6',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export const NewsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeView, setActiveView] = useState<ActiveView>({ type: 'home' });

  const [articles, setArticles] = useState<Article[]>(() =>
    loadFromStorage(STORAGE_KEYS.ARTICLES, INITIAL_ARTICLES)
  );
  const [breakingHeadlines, setBreakingHeadlines] = useState<BreakingHeadline[]>(() =>
    loadFromStorage(STORAGE_KEYS.BREAKING, INITIAL_BREAKING_HEADLINES)
  );
  const [categories, setCategories] = useState<CategoryConfig[]>(() =>
    loadFromStorage(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES)
  );
  const [matchScores] = useState<MatchScoreCard[]>(INITIAL_MATCH_SCORES);
  const [photoGalleries, setPhotoGalleries] = useState<PhotoGalleryItem[]>(() =>
    loadFromStorage(STORAGE_KEYS.GALLERIES, INITIAL_PHOTO_GALLERIES)
  );
  const [opinions] = useState<OpinionColumn[]>(INITIAL_OPINIONS);
  const [ads, setAds] = useState<AdItem[]>(() =>
    loadFromStorage(STORAGE_KEYS.ADS, INITIAL_ADS)
  );
  const [homepageSections, setHomepageSections] = useState<HomepageSectionConfig[]>(() =>
    loadFromStorage(STORAGE_KEYS.HOMEPAGE_SECTIONS, INITIAL_HOMEPAGE_SECTIONS)
  );
  const [comments, setComments] = useState<CommentItem[]>(() =>
    loadFromStorage(STORAGE_KEYS.COMMENTS, INITIAL_COMMENTS)
  );
  const [reporters, setReporters] = useState<AuthorReporter[]>(() =>
    loadFromStorage(STORAGE_KEYS.REPORTERS, INITIAL_REPORTERS)
  );
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(() =>
    loadFromStorage(STORAGE_KEYS.USERS, INITIAL_ADMIN_USERS)
  );
  const [pushNotifications, setPushNotifications] = useState<PushNotificationItem[]>(() =>
    loadFromStorage(STORAGE_KEYS.PUSH, INITIAL_PUSH_NOTIFICATIONS)
  );
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => ({
    ...INITIAL_SITE_SETTINGS,
    ...loadFromStorage(STORAGE_KEYS.SETTINGS, INITIAL_SITE_SETTINGS),
  }));

  const [currentAdminUser, setCurrentAdminUser] = useState<AdminUser | null>(
    INITIAL_ADMIN_USERS[0]
  );

  // AdSense Interactive Click, Dismiss & Pre-Post Vignette State
  const [activeClickedAd, setActiveClickedAd] = useState<AdItem | null>(null);
  const [dismissedAdSlots, setDismissedAdSlots] = useState<string[]>([]);
  const [pendingArticleNavigation, setPendingArticleNavigation] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles));
    } catch {}
  }, [articles]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.BREAKING, JSON.stringify(breakingHeadlines));
    } catch {}
  }, [breakingHeadlines]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    } catch {}
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ADS, JSON.stringify(ads));
    } catch {}
  }, [ads]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HOMEPAGE_SECTIONS, JSON.stringify(homepageSections));
    } catch {}
  }, [homepageSections]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COMMENTS, JSON.stringify(comments));
    } catch {}
  }, [comments]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.REPORTERS, JSON.stringify(reporters));
    } catch {}
  }, [reporters]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(adminUsers));
    } catch {}
  }, [adminUsers]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PUSH, JSON.stringify(pushNotifications));
    } catch {}
  }, [pushNotifications]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.GALLERIES, JSON.stringify(photoGalleries));
    } catch {}
  }, [photoGalleries]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(siteSettings));
      const favHref = siteSettings.faviconUrl || siteSettings.logoUrl;
      if (favHref) {
        let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement | null;
        if (!link) {
          link = document.createElement('link');
          link.rel = 'icon';
          document.head.appendChild(link);
        }
        link.href = favHref;
      }
    } catch {}
  }, [siteSettings]);

  const navigateTo = (view: ActiveView) => {
    // Intercept article navigation if Pre-Post Vignette Ad is enabled and not dismissed
    if (
      view.type === 'article' &&
      activeView.type !== 'admin' &&
      siteSettings.adsMasterEnabled &&
      siteSettings.prePostVignetteEnabled !== false &&
      !dismissedAdSlots.includes('vignette-interstitial')
    ) {
      const vignetteAd = ads.find(
        (ad) => ad.slot === 'vignette-interstitial' && ad.enabled
      );
      if (vignetteAd) {
        setPendingArticleNavigation(view.articleId);
        return;
      }
    }
    setActiveView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const confirmPendingArticleNavigation = () => {
    if (pendingArticleNavigation) {
      const targetId = pendingArticleNavigation;
      setPendingArticleNavigation(null);
      setActiveView({ type: 'article', articleId: targetId });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const cancelPendingArticleNavigation = () => {
    setPendingArticleNavigation(null);
  };

  const triggerVignettePreview = () => {
    const firstArticleId = publishedArticles[0]?.id || 'art-1';
    setDismissedAdSlots((prev) => prev.filter((s) => s !== 'vignette-interstitial'));
    setPendingArticleNavigation(firstArticleId);
  };

  const publishedArticles = articles.filter((a) => a.status === 'published');

  const loginAdmin = (email: string, role?: AdminUser['role']) => {
    const found = adminUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (found) {
      setCurrentAdminUser(role ? { ...found, role } : found);
    } else {
      setCurrentAdminUser({
        id: 'usr-custom',
        name: email.split('@')[0],
        email,
        role: role || 'Super Admin',
        status: 'active',
        lastLoginBn: 'এইমাত্র',
      });
    }
  };

  const logoutAdmin = () => {
    setCurrentAdminUser(null);
    navigateTo({ type: 'home' });
  };

  const addArticle = (newArticleData: Omit<Article, 'id' | 'views'>): Article => {
    const newArticle: Article = {
      ...newArticleData,
      id: `art-${Date.now()}`,
      views: newArticleData.status === 'published' ? 120 : 0,
    };

    setArticles((prev) => {
      let updated = [...prev];
      if (newArticle.isHero) {
        updated = updated.map((a) => ({ ...a, isHero: false }));
      }
      return [newArticle, ...updated];
    });

    if (newArticle.isBreaking && newArticle.status === 'published') {
      setBreakingHeadlines((prev) => [
        {
          id: `brk-${Date.now()}`,
          headline: newArticle.headline,
          articleId: newArticle.id,
          active: true,
          priority: 1,
          createdAtBn: 'এইমাত্র',
        },
        ...prev,
      ]);
    }

    return newArticle;
  };

  const updateArticle = (id: string, updates: Partial<Article>) => {
    setArticles((prev) =>
      prev.map((art) => {
        if (updates.isHero && art.id !== id) {
          return { ...art, isHero: false };
        }
        if (art.id === id) {
          return { ...art, ...updates };
        }
        return art;
      })
    );
  };

  const deleteArticle = (id: string) => {
    setArticles((prev) => prev.filter((a) => a.id !== id));
    setBreakingHeadlines((prev) => prev.filter((b) => b.articleId !== id));
  };

  const setHeroArticle = (id: string) => {
    setArticles((prev) =>
      prev.map((a) => ({
        ...a,
        isHero: a.id === id,
        isFeatured: a.id === id ? true : a.isFeatured,
      }))
    );
  };

  const incrementArticleView = (id: string) => {
    setArticles((prev) =>
      prev.map((a) => (a.id === id ? { ...a, views: a.views + 1 } : a))
    );
  };

  const toggleBreakingNewsBar = (enabled: boolean) => {
    setSiteSettings((prev) => ({ ...prev, breakingNewsEnabled: enabled }));
  };

  const addBreakingHeadline = (headline: string, articleId?: string) => {
    setBreakingHeadlines((prev) => [
      {
        id: `brk-${Date.now()}`,
        headline,
        articleId,
        active: true,
        priority: prev.length + 1,
        createdAtBn: 'এইমাত্র',
      },
      ...prev,
    ]);
  };

  const updateBreakingHeadline = (id: string, updates: Partial<BreakingHeadline>) => {
    setBreakingHeadlines((prev) =>
      prev.map((b) => (b.id === id ? { ...b, ...updates } : b))
    );
  };

  const deleteBreakingHeadline = (id: string) => {
    setBreakingHeadlines((prev) => prev.filter((b) => b.id !== id));
  };

  const addCategory = (nameBn: string, nameEn: string, slug: string) => {
    setCategories((prev) => [
      ...prev,
      {
        id: `cat-${Date.now()}`,
        slug,
        nameBn,
        nameEn,
        subcategories: ['সাধারণ'],
        visibleInMenu: true,
        order: prev.length + 1,
      },
    ]);
  };

  const updateCategory = (id: string, updates: Partial<CategoryConfig>) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const addSubcategory = (categoryId: string, subNameBn: string) => {
    setCategories((prev) =>
      prev.map((c) =>
        c.id === categoryId && !c.subcategories.includes(subNameBn)
          ? { ...c, subcategories: [...c.subcategories, subNameBn] }
          : c
      )
    );
  };

  const removeSubcategory = (categoryId: string, subNameBn: string) => {
    setCategories((prev) =>
      prev.map((c) =>
        c.id === categoryId
          ? { ...c, subcategories: c.subcategories.filter((s) => s !== subNameBn) }
          : c
      )
    );
  };

  const updateHomepageSection = (id: string, updates: Partial<HomepageSectionConfig>) => {
    setHomepageSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updates } : s))
    );
  };

  const reorderHomepageSections = (fromIndex: number, toIndex: number) => {
    setHomepageSections((prev) => {
      const sorted = [...prev].sort((a, b) => a.order - b.order);
      const [moved] = sorted.splice(fromIndex, 1);
      sorted.splice(toIndex, 0, moved);
      return sorted.map((sec, idx) => ({ ...sec, order: idx + 1 }));
    });
  };

  const updateMostReadRank = (articleId: string, rank?: number) => {
    setArticles((prev) =>
      prev.map((a) => {
        if (rank !== undefined && a.mostReadRank === rank && a.id !== articleId) {
          return { ...a, mostReadRank: undefined };
        }
        if (a.id === articleId) {
          return { ...a, mostReadRank: rank };
        }
        return a;
      })
    );
  };

  const toggleAdSlot = (id: string, enabled: boolean) => {
    setAds((prev) => prev.map((ad) => (ad.id === id ? { ...ad, enabled } : ad)));
  };

  const updateAdItem = (id: string, updates: Partial<AdItem>) => {
    setAds((prev) => prev.map((ad) => (ad.id === id ? { ...ad, ...updates } : ad)));
  };

  const addAdItem = (adData: Omit<AdItem, 'id'>) => {
    setAds((prev) => [
      {
        ...adData,
        id: `ad-${Date.now()}`,
      },
      ...prev,
    ]);
  };

  const deleteAdItem = (id: string) => {
    setAds((prev) => prev.filter((ad) => ad.id !== id));
  };

  const getActiveAdForSlot = (slot: AdPlacementSlot): AdItem | undefined => {
    if (!siteSettings.adsMasterEnabled) return undefined;
    const matching = ads
      .filter((ad) => ad.slot === slot && ad.enabled)
      .sort((a, b) => a.priority - b.priority);
    return matching[0];
  };

  const recordAdClick = (ad: AdItem) => {
    setAds((prev) =>
      prev.map((item) =>
        item.id === ad.id
          ? {
              ...item,
              clicks: (item.clicks || 120) + 1,
              impressions: (item.impressions || 4500) + 1,
            }
          : item
      )
    );
  };

  const closeClickedAdModal = () => {
    setActiveClickedAd(null);
  };

  const dismissAdSlot = (slotKey: string) => {
    setDismissedAdSlots((prev) =>
      prev.includes(slotKey) ? prev : [...prev, slotKey]
    );
  };

  const restoreAdSlot = (slotKey: string) => {
    setDismissedAdSlots((prev) => prev.filter((s) => s !== slotKey));
  };

  const restoreAllDismissedAds = () => {
    setDismissedAdSlots([]);
  };

  const addComment = (
    articleId: string,
    articleTitle: string,
    authorName: string,
    authorLocation: string,
    content: string
  ) => {
    const newComment: CommentItem = {
      id: `cmt-${Date.now()}`,
      articleId,
      articleTitle,
      authorName,
      authorLocation: authorLocation || 'বাংলাদেশ',
      content,
      createdAtBn: 'এইমাত্র',
      status: 'approved',
      likes: 1,
    };
    setComments((prev) => [newComment, ...prev]);
  };

  const updateCommentStatus = (id: string, status: CommentItem['status']) => {
    setComments((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status } : c))
    );
  };

  const deleteComment = (id: string) => {
    setComments((prev) => prev.filter((c) => c.id !== id));
  };

  const addReporter = (rep: Omit<AuthorReporter, 'id' | 'articlesCount'>) => {
    setReporters((prev) => [
      ...prev,
      { ...rep, id: `rep-${Date.now()}`, articlesCount: 1 },
    ]);
  };

  const addAdminUser = (user: Omit<AdminUser, 'id' | 'lastLoginBn'>) => {
    setAdminUsers((prev) => [
      ...prev,
      { ...user, id: `usr-${Date.now()}`, lastLoginBn: 'নতুন যুক্ত' },
    ]);
  };

  const sendPushNotification = (titleBn: string, bodyBn: string, targetCategory: string) => {
    setPushNotifications((prev) => [
      {
        id: `push-${Date.now()}`,
        titleBn,
        bodyBn,
        targetCategory,
        sentAtBn: 'এইমাত্র পাঠানো হয়েছে',
        subscribersReached: Math.floor(120000 + Math.random() * 95000),
      },
      ...prev,
    ]);
  };

  const addPhotoGallery = (gallery: Omit<PhotoGalleryItem, 'id'>) => {
    setPhotoGalleries((prev) => [
      { ...gallery, id: `gal-${Date.now()}` },
      ...prev,
    ]);
  };

  const updateSiteSettings = (updates: Partial<SiteSettings>) => {
    setSiteSettings((prev) => ({ ...prev, ...updates }));
  };

  const toggleLanguage = () => {
    setSiteSettings((prev) => ({
      ...prev,
      language: prev.language === 'bn' ? 'en' : 'bn',
    }));
  };

  const resetAllDataToDefault = () => {
    Object.values(STORAGE_KEYS).forEach((k) => localStorage.removeItem(k));
    setArticles(INITIAL_ARTICLES);
    setBreakingHeadlines(INITIAL_BREAKING_HEADLINES);
    setCategories(INITIAL_CATEGORIES);
    setPhotoGalleries(INITIAL_PHOTO_GALLERIES);
    setAds(INITIAL_ADS);
    setHomepageSections(INITIAL_HOMEPAGE_SECTIONS);
    setComments(INITIAL_COMMENTS);
    setReporters(INITIAL_REPORTERS);
    setAdminUsers(INITIAL_ADMIN_USERS);
    setPushNotifications(INITIAL_PUSH_NOTIFICATIONS);
    setSiteSettings(INITIAL_SITE_SETTINGS);
  };

  return (
    <NewsContext.Provider
      value={{
        activeView,
        navigateTo,
        articles,
        publishedArticles,
        breakingHeadlines,
        categories,
        matchScores,
        photoGalleries,
        opinions,
        ads,
        homepageSections,
        comments,
        reporters,
        adminUsers,
        pushNotifications,
        siteSettings,
        currentAdminUser,
        loginAdmin,
        logoutAdmin,
        addArticle,
        updateArticle,
        deleteArticle,
        setHeroArticle,
        incrementArticleView,
        toggleBreakingNewsBar,
        addBreakingHeadline,
        updateBreakingHeadline,
        deleteBreakingHeadline,
        addCategory,
        updateCategory,
        addSubcategory,
        removeSubcategory,
        updateHomepageSection,
        reorderHomepageSections,
        updateMostReadRank,
        toggleAdSlot,
        updateAdItem,
        addAdItem,
        deleteAdItem,
        getActiveAdForSlot,
        recordAdClick,
        activeClickedAd,
        closeClickedAdModal,
        dismissedAdSlots,
        dismissAdSlot,
        restoreAdSlot,
        restoreAllDismissedAds,
        pendingArticleNavigation,
        confirmPendingArticleNavigation,
        cancelPendingArticleNavigation,
        triggerVignettePreview,
        addComment,
        updateCommentStatus,
        deleteComment,
        addReporter,
        addAdminUser,
        sendPushNotification,
        addPhotoGallery,
        updateSiteSettings,
        toggleLanguage,
        resetAllDataToDefault,
      }}
    >
      {children}
    </NewsContext.Provider>
  );
};

export const useNews = (): NewsContextType => {
  const ctx = useContext(NewsContext);
  if (!ctx) {
    throw new Error('useNews must be used within a NewsProvider');
  }
  return ctx;
};

export const toBengaliNumber = (num: number | string): string => {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/\d/g, (d) => bnDigits[Number(d)]);
};
