import React from 'react';
import { NewsProvider, useNews } from './context/NewsContext';
import { Header } from './components/Header';
import { BreakingTicker } from './components/BreakingTicker';
import { Homepage } from './components/Homepage';
import { ArticlePage } from './components/ArticlePage';
import { CategoryPage, MediaHubPage } from './components/CategoryPage';
import { CountrywidePage } from './components/CountrywideSection';
import { WeatherPage } from './components/WeatherSection';
import { EPaperView } from './components/EPaperView';
import { SearchPage } from './components/SearchPage';
import { AdminDashboard } from './components/AdminDashboard';
import { Footer } from './components/Footer';
import { GlobalFloatingAds } from './components/AdSlot';

const PortalRouter: React.FC = () => {
  const { activeView } = useNews();

  // Admin Dashboard has its own full-screen newsroom CMS chrome
  if (activeView.type === 'admin') {
    return <AdminDashboard initialTab={activeView.tab} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#111827]">
      <Header />
      <BreakingTicker />

      <div className="flex-1">
        {activeView.type === 'home' && <Homepage />}
        {activeView.type === 'latest' && (
          <CategoryPage categorySlug="latest" />
        )}
        {activeView.type === 'countrywide' && (
          <CountrywidePage
            key={`${activeView.division || ''}-${activeView.district || ''}-${activeView.upazila || ''}`}
            initialDivision={activeView.division}
            initialDistrict={activeView.district}
            initialUpazila={activeView.upazila}
          />
        )}
        {activeView.type === 'weather' && <WeatherPage />}
        {activeView.type === 'epaper' && <EPaperView />}
        {activeView.type === 'category' &&
          (activeView.categorySlug === 'countrywide' ? (
            <CountrywidePage
              initialDivision={
                activeView.subcategory
                  ? activeView.subcategory.replace(' বিভাগ', '')
                  : undefined
              }
            />
          ) : activeView.categorySlug === 'weather' ? (
            <WeatherPage />
          ) : (
            <CategoryPage
              key={`${activeView.categorySlug}-${activeView.subcategory || ''}`}
              categorySlug={activeView.categorySlug}
              initialSubcategory={activeView.subcategory}
            />
          ))}
        {activeView.type === 'article' && (
          <ArticlePage articleId={activeView.articleId} />
        )}
        {activeView.type === 'search' && (
          <SearchPage initialQuery={activeView.query} />
        )}
        {activeView.type === 'video' && <MediaHubPage mode="video" />}
        {activeView.type === 'photo-gallery' && (
          <MediaHubPage mode="photo-gallery" />
        )}
      </div>

      <Footer />
      <GlobalFloatingAds />
    </div>
  );
};

export default function App() {
  return (
    <NewsProvider>
      <PortalRouter />
    </NewsProvider>
  );
}
