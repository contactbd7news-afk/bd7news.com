export async function handler(event) {
  try {
    const rawText = String(event.queryStringParameters?.q || '').trim();
    if (!rawText) {
      return {
        statusCode: 400,
        body: 'Missing text parameter q',
      };
    }

    const textChunk = rawText.slice(0, 200);
    const ttsUrl = `https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=bn&client=tw-ob&q=${encodeURIComponent(
      textChunk
    )}`;

    const upstream = await fetch(ttsUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Referer: 'https://translate.google.com/',
      },
    });

    if (!upstream.ok) {
      return {
        statusCode: upstream.status,
        body: 'Upstream TTS failed',
      };
    }

    const arrayBuffer = await upstream.arrayBuffer();
    const base64Audio = Buffer.from(arrayBuffer).toString('base64');

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'audio/mpeg',
        'Cache-Control': 'public, max-age=86400',
      },
      body: base64Audio,
      isBase64Encoded: true,
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: 'TTS generation error',
    };
  }
}
